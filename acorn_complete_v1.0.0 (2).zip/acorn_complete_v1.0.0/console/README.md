# Acorn Console (Free)

## Run
```bash
python run_console.py
```

## Notes
- Free version cannot generate plates.
- Plates must pass signature/license/lineage validation (engine enforces).
- Console provides:
  - Engine connect/discovery
  - **Plate Set loading (folder-based)** - NEW
  - Single plate loading (deprecated)
  - Text interaction
  - Visualization (room-relative)
  - Diagnostics
  - Print snapshots (text/ascii/diagnostics)
- LLM Translator is included: Engine Alphabet ⇄ LLM.

## Requirements
- Python 3.10+
- tkinter (usually included with Python)
- Acorn Engine v12.19.0 running locally

## Loading Plates

### Recommended: Load Plate Set (folder-based)

Click **"📁 Load Plate Set"** and select a folder containing:
- `*.world.v1.json` - World plate
- `*.characters.v1.json` - Characters plate
- `*.learning.v1.json` - Learning plate

**IMPORTANT:** Only files ending in `.v1.json` are loaded. Legacy `.json` files are ignored.

All plates must:
- Share the same `origin_plate_set`
- Have `console_compat: "acorn_console_free"`
- Include valid integrity hashes

### Connection-Gated Loading

Plate validation happens immediately. Engine loading requires connection:

1. **Load plates before connecting**: Plates are validated and cached
2. **Connect to engine**: Cached plates auto-load after connection
3. **Load plates while connected**: Plates load immediately

This ensures no partial loads or race conditions.

### Legacy: Load Single Plate

Click **"📄 Load Plate"** to load individual files.
⚠️ Deprecated - use plate sets for proper validation.

## The `init` Command

After loading a plate set, type `init` to initialize the world display:

```
> init

════════════════════════════════════════
[system] 🌸 The Fairy Garden awakens.
════════════════════════════════════════

You find yourself at the entrance to a magical garden.
Six fairies tend to the flowers and paths.
The air shimmers with possibility.

Type 'look' to observe, or wait and watch.
```

This immediately shows:
- Room label in visualization panel
- ASCII map placeholder
- Diagnostics (world state)
- Welcome message

The `init` command provides immediate visual feedback before engine events arrive.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Top Bar                               │
│  [Engine ▼] [Refresh] [Connect] [Disconnect]                │
│  [📁 Load Plate Set] [📄 Load Plate]                        │
│  [🖨 Text] [🖨 ASCII] [🖨 Diag]                              │
├───────────────────────────┬─────────────────────────────────┤
│                           │         Visualization           │
│      Text Console         │      (Room-relative view)       │
│                           │                                 │
│   > user input            │   ┌─────────────────────┐       │
│   system response         │   │     ASCII map       │       │
│   > user input            │   │     + primitives    │       │
│                           ├─────────────────────────────────┤
│   [input field    ] [Send]│        Diagnostics              │
│                           │   Zone: GREEN                   │
│                           │   Avatar: inactive              │
│                           │   Quarantine: none              │
└───────────────────────────┴─────────────────────────────────┘
```

## Connection Modes

### Socket Mode (Production)
- Default port: 17778
- JSON line protocol (newline-delimited)
- Real-time bidirectional communication

### File Mode (Testing)
- IO bridge via filesystem
- Useful for debugging

## Engine Integration

Add `console_server.py` to your engine for console support:

```python
from console_server import start_console_server

def handle_message(message, client):
    if message["type"] == "load_plate_set":
        # Load plates
        client.send({"type": "plate_set_loaded", "success": True})

server = start_console_server(on_message=handle_message)
```

## Free Version Limitations
- NO plate generation
- NO structured export
- Print snapshots only (text files)

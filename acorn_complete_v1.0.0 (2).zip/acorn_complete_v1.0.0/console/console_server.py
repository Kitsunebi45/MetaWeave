"""Acorn Engine Console Server.

Minimal TCP server for console connections.
Drop this into your engine and call start_console_server() at startup.

Protocol:
- JSON line protocol (newline-delimited)
- Each message is a JSON object followed by newline
- Client sends commands, server responds with state/events
"""

import socket
import threading
import json
from typing import Any, Callable, Dict, Optional
from queue import Queue


# Default port
DEFAULT_PORT = 17778


class ConsoleServer:
    """TCP server for console connections.
    
    Example usage:
    ```python
    server = ConsoleServer(on_message=handle_console_message)
    server.start()
    
    # Later, to broadcast state:
    server.broadcast({"type": "state", "payload": {...}})
    ```
    """
    
    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = DEFAULT_PORT,
        on_message: Optional[Callable[[Dict[str, Any], 'ClientConnection'], None]] = None,
        on_connect: Optional[Callable[['ClientConnection'], None]] = None,
        on_disconnect: Optional[Callable[['ClientConnection'], None]] = None
    ):
        """Initialize console server.
        
        Args:
            host: Bind address (default: localhost only)
            port: Listen port
            on_message: Callback for received messages
            on_connect: Callback for new connections
            on_disconnect: Callback for disconnections
        """
        self.host = host
        self.port = port
        self.on_message = on_message
        self.on_connect = on_connect
        self.on_disconnect = on_disconnect
        
        self._server_sock: Optional[socket.socket] = None
        self._clients: list['ClientConnection'] = []
        self._clients_lock = threading.Lock()
        self._running = False
        self._accept_thread: Optional[threading.Thread] = None
    
    def start(self) -> bool:
        """Start the server.
        
        Returns:
            True if started successfully
        """
        try:
            self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_sock.bind((self.host, self.port))
            self._server_sock.listen(5)
            self._server_sock.settimeout(1.0)  # For clean shutdown
            
            self._running = True
            self._accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
            self._accept_thread.start()
            
            print(f"[engine] Console server listening on {self.host}:{self.port}")
            return True
            
        except Exception as e:
            print(f"[engine] Failed to start console server: {e}")
            return False
    
    def stop(self) -> None:
        """Stop the server."""
        self._running = False
        
        # Close all client connections
        with self._clients_lock:
            for client in self._clients:
                client.close()
            self._clients.clear()
        
        # Close server socket
        if self._server_sock:
            try:
                self._server_sock.close()
            except Exception:
                pass
            self._server_sock = None
    
    def broadcast(self, message: Dict[str, Any]) -> None:
        """Broadcast a message to all connected consoles.
        
        Args:
            message: Message dictionary to send
        """
        with self._clients_lock:
            disconnected = []
            for client in self._clients:
                if not client.send(message):
                    disconnected.append(client)
            
            # Remove disconnected clients
            for client in disconnected:
                self._remove_client(client)
    
    def send_to(self, client: 'ClientConnection', message: Dict[str, Any]) -> bool:
        """Send a message to a specific client.
        
        Args:
            client: Client to send to
            message: Message dictionary
            
        Returns:
            True if sent successfully
        """
        return client.send(message)
    
    def client_count(self) -> int:
        """Get number of connected clients."""
        with self._clients_lock:
            return len(self._clients)
    
    def _accept_loop(self) -> None:
        """Accept incoming connections."""
        while self._running:
            try:
                conn, addr = self._server_sock.accept()
                client = ClientConnection(conn, addr, self._handle_message, self._handle_disconnect)
                
                with self._clients_lock:
                    self._clients.append(client)
                
                print(f"[engine] Console connected from {addr}")
                
                if self.on_connect:
                    self.on_connect(client)
                    
            except socket.timeout:
                continue
            except Exception:
                if self._running:
                    continue
    
    def _handle_message(self, message: Dict[str, Any], client: 'ClientConnection') -> None:
        """Handle received message."""
        if self.on_message:
            self.on_message(message, client)
    
    def _handle_disconnect(self, client: 'ClientConnection') -> None:
        """Handle client disconnect."""
        self._remove_client(client)
    
    def _remove_client(self, client: 'ClientConnection') -> None:
        """Remove a client from the list."""
        with self._clients_lock:
            if client in self._clients:
                self._clients.remove(client)
                
                if self.on_disconnect:
                    self.on_disconnect(client)


class ClientConnection:
    """Represents a single console connection."""
    
    def __init__(
        self,
        sock: socket.socket,
        addr: tuple,
        on_message: Callable[[Dict[str, Any], 'ClientConnection'], None],
        on_disconnect: Callable[['ClientConnection'], None]
    ):
        self.sock = sock
        self.addr = addr
        self._on_message = on_message
        self._on_disconnect = on_disconnect
        
        self._recv_buffer = b""
        self._running = True
        
        # Configure socket
        self.sock.settimeout(0.1)
        
        # Start receive thread
        self._recv_thread = threading.Thread(target=self._recv_loop, daemon=True)
        self._recv_thread.start()
    
    def send(self, message: Dict[str, Any]) -> bool:
        """Send a message to this client.
        
        Args:
            message: Message dictionary
            
        Returns:
            True if sent successfully
        """
        if not self._running:
            return False
        
        try:
            data = json.dumps(message).encode("utf-8") + b"\n"
            self.sock.sendall(data)
            return True
        except Exception:
            self.close()
            return False
    
    def close(self) -> None:
        """Close the connection."""
        self._running = False
        try:
            self.sock.close()
        except Exception:
            pass
    
    def _recv_loop(self) -> None:
        """Receive loop for this client."""
        while self._running:
            try:
                data = self.sock.recv(4096)
                if not data:
                    # Connection closed
                    self._running = False
                    self._on_disconnect(self)
                    break
                
                self._recv_buffer += data
                self._process_buffer()
                
            except socket.timeout:
                continue
            except Exception:
                self._running = False
                self._on_disconnect(self)
                break
    
    def _process_buffer(self) -> None:
        """Process receive buffer for complete messages."""
        while b"\n" in self._recv_buffer:
            line, self._recv_buffer = self._recv_buffer.split(b"\n", 1)
            if not line:
                continue
            
            try:
                message = json.loads(line.decode("utf-8"))
                self._on_message(message, self)
            except json.JSONDecodeError:
                pass


# Convenience function for simple integration
def start_console_server(
    on_message: Optional[Callable[[Dict[str, Any], ClientConnection], None]] = None,
    port: int = DEFAULT_PORT
) -> ConsoleServer:
    """Start a console server with default settings.
    
    Args:
        on_message: Callback for received messages
        port: Listen port
        
    Returns:
        ConsoleServer instance
    """
    server = ConsoleServer(port=port, on_message=on_message)
    server.start()
    return server


# Example message handler
def example_message_handler(message: Dict[str, Any], client: ClientConnection) -> None:
    """Example message handler.
    
    Replace this with your actual message handling logic.
    """
    msg_type = message.get("type", "unknown")
    
    if msg_type == "hello":
        print(f"[engine] Console handshake: {message.get('client')} v{message.get('version')}")
        # Send acknowledgment
        client.send({
            "type": "hello_ack",
            "engine": "Acorn Engine",
            "version": "12.19.0"
        })
    
    elif msg_type == "load_plate_set":
        print(f"[engine] Loading plate set: {message.get('payload', {}).get('origin')}")
        # Your plate loading logic here
        client.send({
            "type": "plate_set_loaded",
            "success": True
        })
    
    elif msg_type == "command":
        print(f"[engine] Command: {message.get('payload')}")
    
    elif msg_type == "user_text":
        print(f"[engine] User text: {message.get('payload', {}).get('text')}")
    
    else:
        print(f"[engine] Unknown message type: {msg_type}")


if __name__ == "__main__":
    # Demo: Start server and wait
    print("Starting Acorn Engine Console Server...")
    server = start_console_server(on_message=example_message_handler)
    
    try:
        import time
        while True:
            time.sleep(1)
            if server.client_count() > 0:
                # Example: broadcast tick state
                server.broadcast({
                    "type": "tick",
                    "tick": 0,
                    "entities": []
                })
    except KeyboardInterrupt:
        print("\nShutting down...")
        server.stop()

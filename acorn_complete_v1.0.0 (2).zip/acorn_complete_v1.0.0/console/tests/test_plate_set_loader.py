"""Tests for Plate Set Loader with strict v1 versioning."""

import sys
import json
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from console.plates.plate_set_loader import (
    PlateSetError, 
    PlateSet, 
    PlateData,
    scan_plate_folder, 
    load_plate_set_from_folder,
    VALID_CONSOLE_COMPAT
)


def create_test_plate(plate_type: str, plate_id: str, origin: str = "test_demo") -> dict:
    """Create a minimal valid test plate."""
    return {
        "plate_header": {
            "plate_id": plate_id,
            "plate_type": plate_type,
            "version": "1.0.0",
            "author": "Test Author",
            "copyright": "© Test",
            "license": "Test license",
            "engine_lineage": {
                "engine_name": "Acorn Engine",
                "engine_version_min": "12.19.0",
                "console_compat": VALID_CONSOLE_COMPAT,
                "origin_plate_set": origin
            },
            "integrity": {
                "hash": "test_hash",
                "signature": "test_sig"
            }
        },
        plate_type: {"test_data": True}
    }


def write_v1_plate(tmpdir, plate_type: str, origin: str = "test_demo", **overrides) -> None:
    """Write a test plate with proper .v1.json naming."""
    plate_id = f"test.{plate_type}.v1"
    plate = create_test_plate(plate_type, plate_id, origin)
    
    # Apply any overrides to plate_header
    for key, value in overrides.items():
        if value is None and key in plate["plate_header"]:
            del plate["plate_header"][key]
        elif key.startswith("lineage_"):
            lineage_key = key[8:]  # Remove "lineage_" prefix
            if value is None and lineage_key in plate["plate_header"]["engine_lineage"]:
                del plate["plate_header"]["engine_lineage"][lineage_key]
            else:
                plate["plate_header"]["engine_lineage"][lineage_key] = value
        elif key.startswith("integrity_"):
            integrity_key = key[10:]  # Remove "integrity_" prefix
            if value is None and integrity_key in plate["plate_header"]["integrity"]:
                del plate["plate_header"]["integrity"][integrity_key]
            else:
                plate["plate_header"]["integrity"][integrity_key] = value
        else:
            plate["plate_header"][key] = value
    
    # IMPORTANT: Use .v1.json extension
    with open(Path(tmpdir) / f"{plate_type}.v1.json", "w") as f:
        json.dump(plate, f)


def write_all_v1_plates(tmpdir, origin: str = "test_demo") -> None:
    """Write complete v1 plate set."""
    for ptype in ["world", "characters", "learning"]:
        write_v1_plate(tmpdir, ptype, origin)


def test_empty_folder():
    """Test loading from empty folder."""
    with tempfile.TemporaryDirectory() as tmpdir:
        try:
            scan_plate_folder(tmpdir)
            assert False, "Should have raised PlateSetError"
        except PlateSetError as e:
            assert "No versioned plate files" in str(e)
    print("✅ test_empty_folder")


def test_folder_with_only_non_v1_files():
    """Test folder with only non-versioned .json files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create plates WITHOUT .v1.json naming (should be ignored)
        for ptype in ["world", "characters", "learning"]:
            plate = create_test_plate(ptype, f"test.{ptype}")
            with open(Path(tmpdir) / f"{ptype}.json", "w") as f:
                json.dump(plate, f)
        
        try:
            scan_plate_folder(tmpdir)
            assert False, "Should have raised PlateSetError"
        except PlateSetError as e:
            assert "No versioned plate files" in str(e)
    print("✅ test_folder_with_only_non_v1_files")


def test_missing_plates():
    """Test folder with incomplete plate set."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create only world plate
        write_v1_plate(tmpdir, "world")
        
        try:
            scan_plate_folder(tmpdir)
            assert False, "Should have raised PlateSetError"
        except PlateSetError as e:
            assert "Missing required" in str(e)
    print("✅ test_missing_plates")


def test_complete_plate_set():
    """Test folder with complete plate set."""
    with tempfile.TemporaryDirectory() as tmpdir:
        write_all_v1_plates(tmpdir)
        
        result = scan_plate_folder(tmpdir)
        
        assert isinstance(result, PlateSet)
        assert result.origin == "test_demo"
        assert result.is_complete()
        assert len(result.get_missing()) == 0
        assert result.plates["world"] is not None
        assert result.plates["characters"] is not None
        assert result.plates["learning"] is not None
    print("✅ test_complete_plate_set")


def test_plate_set_to_engine_payload():
    """Test PlateSet.to_engine_payload() method."""
    with tempfile.TemporaryDirectory() as tmpdir:
        write_all_v1_plates(tmpdir)
        
        result = scan_plate_folder(tmpdir)
        payload = result.to_engine_payload()
        
        assert "origin" in payload
        assert "world" in payload
        assert "characters" in payload
        assert "learning" in payload
        assert payload["origin"] == "test_demo"
    print("✅ test_plate_set_to_engine_payload")


def test_plate_set_get_summary():
    """Test PlateSet.get_summary() method."""
    with tempfile.TemporaryDirectory() as tmpdir:
        write_all_v1_plates(tmpdir)
        
        result = scan_plate_folder(tmpdir)
        summary = result.get_summary()
        
        assert len(summary) == 6  # origin, folder, "Plates:", world, characters, learning
        assert "test_demo" in summary[0]
    print("✅ test_plate_set_get_summary")


def test_origin_mismatch():
    """Test folder with mismatched origins."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create plates with different origins
        write_v1_plate(tmpdir, "world", origin="test_demo")
        write_v1_plate(tmpdir, "characters", origin="test_demo")
        write_v1_plate(tmpdir, "learning", origin="different_origin")
        
        try:
            scan_plate_folder(tmpdir)
            assert False, "Should have raised PlateSetError"
        except PlateSetError as e:
            assert "mismatch" in str(e).lower()
    print("✅ test_origin_mismatch")


def test_duplicate_plate_type():
    """Test folder with duplicate plate types."""
    with tempfile.TemporaryDirectory() as tmpdir:
        write_all_v1_plates(tmpdir)
        
        # Add duplicate world with different filename
        plate = create_test_plate("world", "test.world2.v1")
        with open(Path(tmpdir) / "world2.v1.json", "w") as f:
            json.dump(plate, f)
        
        try:
            scan_plate_folder(tmpdir)
            assert False, "Should have raised PlateSetError"
        except PlateSetError as e:
            assert "Duplicate" in str(e)
    print("✅ test_duplicate_plate_type")


def test_incompatible_console():
    """Test plate with wrong console_compat."""
    with tempfile.TemporaryDirectory() as tmpdir:
        write_v1_plate(tmpdir, "world")
        write_v1_plate(tmpdir, "characters", lineage_console_compat="premium_console")
        write_v1_plate(tmpdir, "learning")
        
        try:
            scan_plate_folder(tmpdir)
            assert False, "Should have raised PlateSetError"
        except PlateSetError as e:
            assert "Incompatible" in str(e)
    print("✅ test_incompatible_console")


def test_invalid_json():
    """Test folder with invalid JSON v1 file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        write_all_v1_plates(tmpdir)
        
        # Add invalid JSON with v1 naming
        with open(Path(tmpdir) / "bad.v1.json", "w") as f:
            f.write("{not valid json")
        
        try:
            scan_plate_folder(tmpdir)
            assert False, "Should have raised PlateSetError"
        except PlateSetError as e:
            assert "Invalid JSON" in str(e)
    print("✅ test_invalid_json")


def test_convenience_function_success():
    """Test load_plate_set_from_folder convenience function."""
    with tempfile.TemporaryDirectory() as tmpdir:
        write_all_v1_plates(tmpdir)
        
        ok, msg, result = load_plate_set_from_folder(tmpdir)
        
        assert ok
        assert result is not None
        assert isinstance(result, PlateSet)
        assert result.origin == "test_demo"
    print("✅ test_convenience_function_success")


def test_convenience_function_failure():
    """Test load_plate_set_from_folder with failure."""
    with tempfile.TemporaryDirectory() as tmpdir:
        ok, msg, result = load_plate_set_from_folder(tmpdir)
        
        assert not ok
        assert result is None
        assert "No versioned plate files" in msg
    print("✅ test_convenience_function_failure")


def test_legacy_files_ignored():
    """Test that non-.v1.json files are ignored (not scanned)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create complete v1 plate set
        write_all_v1_plates(tmpdir)
        
        # Add legacy non-v1 files (should be ignored)
        for ptype in ["world", "characters", "learning"]:
            plate = create_test_plate(ptype, f"legacy.{ptype}")
            # Remove origin to make it invalid
            del plate["plate_header"]["engine_lineage"]["origin_plate_set"]
            with open(Path(tmpdir) / f"{ptype}.json", "w") as f:
                json.dump(plate, f)
        
        # Add manifest (should be ignored)
        manifest = {"manifest_version": "1.0.0", "plates": []}
        with open(Path(tmpdir) / "MANIFEST.json", "w") as f:
            json.dump(manifest, f)
        
        # Should succeed - only v1 files are scanned
        result = scan_plate_folder(tmpdir)
        assert result.origin == "test_demo"
        assert result.is_complete()
    print("✅ test_legacy_files_ignored")


def test_missing_author():
    """Test plate missing author field."""
    with tempfile.TemporaryDirectory() as tmpdir:
        write_v1_plate(tmpdir, "world", author=None)
        write_v1_plate(tmpdir, "characters")
        write_v1_plate(tmpdir, "learning")
        
        try:
            scan_plate_folder(tmpdir)
            assert False, "Should have raised PlateSetError"
        except PlateSetError as e:
            assert "author" in str(e).lower()
    print("✅ test_missing_author")


def test_missing_integrity():
    """Test plate missing integrity field."""
    with tempfile.TemporaryDirectory() as tmpdir:
        write_v1_plate(tmpdir, "world")
        
        # Manually create characters plate without integrity
        plate = create_test_plate("characters", "test.characters.v1")
        del plate["plate_header"]["integrity"]
        with open(Path(tmpdir) / "characters.v1.json", "w") as f:
            json.dump(plate, f)
        
        write_v1_plate(tmpdir, "learning")
        
        try:
            scan_plate_folder(tmpdir)
            assert False, "Should have raised PlateSetError"
        except PlateSetError as e:
            assert "integrity" in str(e).lower()
    print("✅ test_missing_integrity")


def test_missing_origin_plate_set():
    """Test plate missing origin_plate_set field."""
    with tempfile.TemporaryDirectory() as tmpdir:
        write_v1_plate(tmpdir, "world")
        write_v1_plate(tmpdir, "characters", lineage_origin_plate_set=None)
        write_v1_plate(tmpdir, "learning")
        
        try:
            scan_plate_folder(tmpdir)
            assert False, "Should have raised PlateSetError"
        except PlateSetError as e:
            assert "origin_plate_set" in str(e)
    print("✅ test_missing_origin_plate_set")


def test_missing_plate_header():
    """Test v1 file missing plate_header."""
    with tempfile.TemporaryDirectory() as tmpdir:
        write_all_v1_plates(tmpdir)
        
        # Create v1 file without plate_header
        with open(Path(tmpdir) / "broken.v1.json", "w") as f:
            json.dump({"some_data": True}, f)
        
        try:
            scan_plate_folder(tmpdir)
            assert False, "Should have raised PlateSetError"
        except PlateSetError as e:
            assert "missing plate_header" in str(e).lower()
    print("✅ test_missing_plate_header")


def run_all_tests():
    """Run all plate set loader tests."""
    print("\n=== PLATE SET LOADER TESTS (v1 STRICT) ===\n")
    
    test_empty_folder()
    test_folder_with_only_non_v1_files()
    test_missing_plates()
    test_complete_plate_set()
    test_plate_set_to_engine_payload()
    test_plate_set_get_summary()
    test_origin_mismatch()
    test_duplicate_plate_type()
    test_incompatible_console()
    test_invalid_json()
    test_convenience_function_success()
    test_convenience_function_failure()
    test_legacy_files_ignored()
    test_missing_author()
    test_missing_integrity()
    test_missing_origin_plate_set()
    test_missing_plate_header()
    
    print("\n✅ All plate set loader tests passed (17/17)\n")


if __name__ == "__main__":
    run_all_tests()

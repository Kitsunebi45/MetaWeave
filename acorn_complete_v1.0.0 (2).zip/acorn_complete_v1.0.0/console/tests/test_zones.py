"""Tests for Zone Management."""

import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from console.runtime.zones import ZoneStatus, QuarantineStatus, zone_from_string


def test_zone_status_default():
    """Test default zone status."""
    status = ZoneStatus()
    
    assert status.zone == "GREEN"
    assert status.is_safe()
    assert not status.is_caution()
    assert not status.is_danger()
    print("✅ zone_status default")


def test_zone_status_set():
    """Test setting zone status."""
    status = ZoneStatus()
    
    changed = status.set_zone("YELLOW", "Warning condition")
    assert changed
    assert status.zone == "YELLOW"
    assert status.reason == "Warning condition"
    assert status.is_caution()
    
    changed = status.set_zone("RED", "Critical")
    assert changed
    assert status.is_danger()
    print("✅ zone_status set")


def test_zone_status_invalid():
    """Test setting invalid zone."""
    status = ZoneStatus()
    
    changed = status.set_zone("INVALID", "test")
    assert not changed
    assert status.zone == "GREEN"  # Unchanged
    print("✅ zone_status invalid")


def test_zone_status_to_dict():
    """Test zone status to dict."""
    status = ZoneStatus()
    status.set_zone("YELLOW", "Test reason")
    
    d = status.to_dict()
    assert d["zone"] == "YELLOW"
    assert d["reason"] == "Test reason"
    assert "last_change" in d
    print("✅ zone_status to_dict")


def test_quarantine_start():
    """Test quarantine start."""
    q = QuarantineStatus(minutes_required=60)
    
    assert not q.active
    
    q.start("room_01")
    
    assert q.active
    assert q.room_id == "room_01"
    assert q.started_epoch > 0
    print("✅ quarantine start")


def test_quarantine_end():
    """Test quarantine end."""
    q = QuarantineStatus()
    q.start("room_01")
    
    assert q.active
    
    q.end()
    
    assert not q.active
    print("✅ quarantine end")


def test_quarantine_time_remaining():
    """Test quarantine time remaining calculation."""
    q = QuarantineStatus(minutes_required=1)  # 1 minute for test
    q.start("room_01")
    
    remaining = q.time_remaining_seconds()
    
    # Should be close to 60 seconds
    assert 55 < remaining <= 60
    
    # Not complete yet
    assert not q.is_complete()
    print("✅ quarantine time_remaining")


def test_quarantine_to_dict():
    """Test quarantine to dict."""
    q = QuarantineStatus(minutes_required=60)
    q.start("room_01")
    
    d = q.to_dict()
    
    assert d["active"] is True
    assert d["room_id"] == "room_01"
    assert d["minutes_required"] == 60
    assert "time_remaining_seconds" in d
    assert "is_complete" in d
    print("✅ quarantine to_dict")


def test_zone_from_string():
    """Test zone_from_string conversion."""
    assert zone_from_string("GREEN") == "GREEN"
    assert zone_from_string("yellow") == "YELLOW"
    assert zone_from_string("RED") == "RED"
    assert zone_from_string("INVALID") == "GREEN"
    assert zone_from_string("") == "GREEN"
    assert zone_from_string(None) == "GREEN"
    print("✅ zone_from_string")


def run_all_tests():
    """Run all zone tests."""
    print("\n=== ZONE TESTS ===\n")
    
    test_zone_status_default()
    test_zone_status_set()
    test_zone_status_invalid()
    test_zone_status_to_dict()
    test_quarantine_start()
    test_quarantine_end()
    test_quarantine_time_remaining()
    test_quarantine_to_dict()
    test_zone_from_string()
    
    print("\n✅ All zone tests passed\n")


if __name__ == "__main__":
    run_all_tests()

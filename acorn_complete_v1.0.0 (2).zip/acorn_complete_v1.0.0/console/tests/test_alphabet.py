"""Tests for LLM Alphabet."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from console.llm.alphabet import (
    AlphaState, AlphaBuilder, AlphaInput, AlphaCommand,
    validate_command, VALID_COMMANDS, VALID_DIRECTIONS
)


def test_alpha_state_creation():
    """Test AlphaState creation."""
    state = AlphaState(
        room_id="room_01",
        human_present=True,
        tinkerbell_present=False,
        resource_mode="ACTIVE",
        zone="GREEN"
    )
    
    assert state.room_id == "room_01"
    assert state.human_present is True
    assert state.zone == "GREEN"
    print("✅ AlphaState creation")


def test_alpha_state_compact():
    """Test AlphaState compact representation."""
    state = AlphaState(
        room_id="r1",
        human_present=True,
        tinkerbell_present=False,
        resource_mode="ACTIVE",
        zone="GREEN"
    )
    
    compact = state.to_compact()
    assert "R:r1" in compact
    assert "H:1" in compact
    assert "T:0" in compact
    assert "ZONE:GREEN" in compact
    print("✅ AlphaState compact")


def test_alpha_builder():
    """Test AlphaBuilder."""
    builder = AlphaBuilder(builder_id="b01", state="idle")
    compact = builder.to_compact()
    
    assert "B:b01" in compact
    assert "S:idle" in compact
    print("✅ AlphaBuilder")


def test_alpha_input_to_prompt():
    """Test AlphaInput to prompt conversion."""
    state = AlphaState(
        room_id="r1",
        human_present=True,
        tinkerbell_present=False,
        resource_mode="ACTIVE",
        zone="GREEN"
    )
    
    builders = (AlphaBuilder("b1", "idle"),)
    events = ("EVT_TEST",)
    
    alpha_input = AlphaInput(
        state=state,
        builders=builders,
        events=events,
        goal="Test goal"
    )
    
    prompt = alpha_input.to_prompt()
    
    assert "R:r1" in prompt
    assert "B:b1" in prompt
    assert "EVT:EVT_TEST" in prompt
    assert "GOAL:Test goal" in prompt
    assert "OUTPUT:" in prompt
    print("✅ AlphaInput to prompt")


def test_alpha_command():
    """Test AlphaCommand."""
    cmd = AlphaCommand(kind="MOVE", arg="N")
    
    assert cmd.kind == "MOVE"
    assert cmd.arg == "N"
    assert str(cmd) == "MOVE:N"
    
    engine_fmt = cmd.to_engine_format()
    assert engine_fmt["command"] == "MOVE"
    assert engine_fmt["argument"] == "N"
    print("✅ AlphaCommand")


def test_validate_command_valid():
    """Test valid command validation."""
    valid, msg = validate_command("WAIT", None)
    assert valid
    
    valid, msg = validate_command("MOVE", "N")
    assert valid
    
    valid, msg = validate_command("SAY", "target")
    assert valid
    print("✅ validate_command valid cases")


def test_validate_command_invalid():
    """Test invalid command validation."""
    valid, msg = validate_command("INVALID", None)
    assert not valid
    
    valid, msg = validate_command("MOVE", None)
    assert not valid  # MOVE requires direction
    
    valid, msg = validate_command("MOVE", "INVALID_DIR")
    assert not valid  # Invalid direction
    print("✅ validate_command invalid cases")


def run_all_tests():
    """Run all alphabet tests."""
    print("\n=== ALPHABET TESTS ===\n")
    
    test_alpha_state_creation()
    test_alpha_state_compact()
    test_alpha_builder()
    test_alpha_input_to_prompt()
    test_alpha_command()
    test_validate_command_valid()
    test_validate_command_invalid()
    
    print("\n✅ All alphabet tests passed\n")


if __name__ == "__main__":
    run_all_tests()

"""Tests for Socket Handler and Engine Connector."""

import sys
import time
import threading
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))


def test_socket_connection():
    """Test socket connection flow."""
    from console_server import ConsoleServer, example_message_handler
    from console.engine.socket_handler import SocketHandler
    
    # Start server
    server = ConsoleServer(port=17799, on_message=example_message_handler)
    assert server.start(), "Server failed to start"
    
    time.sleep(0.5)  # Wait for server
    
    try:
        # Connect client
        client = SocketHandler()
        assert client.connect("127.0.0.1", 17799), "Client failed to connect"
        assert client.is_connected(), "Client not connected"
        
        time.sleep(0.5)  # Wait for connection to register
        
        # Receive handshake acknowledgment
        packets = client.receive()
        assert len(packets) > 0, "Should receive hello_ack"
        assert packets[0].packet_type == "hello_ack", f"Expected hello_ack, got {packets[0].packet_type}"
        
        # Disconnect
        client.disconnect()
        time.sleep(0.2)
        assert not client.is_connected(), "Client should be disconnected"
        
    finally:
        server.stop()
    
    print("✅ test_socket_connection")


def test_engine_connector():
    """Test EngineConnector with real socket."""
    from console_server import ConsoleServer, example_message_handler
    from console.engine.connector import EngineConnector
    
    # Start server
    server = ConsoleServer(port=17798, on_message=example_message_handler)
    assert server.start(), "Server failed to start"
    
    time.sleep(0.5)
    
    try:
        # Connect via connector
        connector = EngineConnector()
        ok, msg = connector.connect("test@127.0.0.1:17798")
        
        assert ok, f"Connect failed: {msg}"
        assert connector.is_connected(), "Connector not connected"
        
        time.sleep(0.3)
        
        # Send command
        ok2, msg2 = connector.send_command("test_command", {"data": "test"})
        assert ok2, f"Send failed: {msg2}"
        
        # Disconnect
        connector.disconnect()
        time.sleep(0.2)
        assert not connector.is_connected(), "Connector should be disconnected"
        
    finally:
        server.stop()
    
    print("✅ test_engine_connector")


def test_discovery_port_check():
    """Test that discovery correctly checks open ports."""
    from console_server import ConsoleServer
    from console.engine.discovery import check_port_open
    
    # No server yet - port should be closed
    assert not check_port_open("127.0.0.1", 17797), "Port should be closed"
    
    # Start server
    server = ConsoleServer(port=17797)
    assert server.start(), "Server failed to start"
    
    time.sleep(0.5)
    
    try:
        # Port should now be open
        assert check_port_open("127.0.0.1", 17797), "Port should be open"
    finally:
        server.stop()
    
    time.sleep(0.5)
    
    # Port should be closed again
    assert not check_port_open("127.0.0.1", 17797), "Port should be closed after stop"
    
    print("✅ test_discovery_port_check")


def run_all_tests():
    """Run all socket tests."""
    print("\n=== SOCKET CONNECTION TESTS ===\n")
    
    test_socket_connection()
    test_engine_connector()
    test_discovery_port_check()
    
    print("\n✅ All socket tests passed (3/3)\n")


if __name__ == "__main__":
    run_all_tests()

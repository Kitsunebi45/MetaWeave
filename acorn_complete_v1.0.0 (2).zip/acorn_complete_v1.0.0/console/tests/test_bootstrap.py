"""Tests for Console Bootstrap."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from console.runtime.bootstrap import ConsoleBootstrap, BootstrapState


def test_bootstrap_creation():
    """Test bootstrap instance creation."""
    bootstrap = ConsoleBootstrap()
    assert bootstrap.state is not None
    assert bootstrap.loaded_plate_set is None
    assert not bootstrap.is_active()
    print("✅ test_bootstrap_creation")


def test_set_plate_set():
    """Test storing plate set info."""
    bootstrap = ConsoleBootstrap()
    
    info = {"origin": "test_demo", "folder": "/test"}
    bootstrap.set_plate_set(info)
    
    assert bootstrap.loaded_plate_set is not None
    assert bootstrap.loaded_plate_set["origin"] == "test_demo"
    print("✅ test_set_plate_set")


def test_init_without_plates():
    """Test init command without plates loaded."""
    bootstrap = ConsoleBootstrap()
    
    messages = []
    bootstrap.on_message = lambda msg: messages.append(msg)
    
    result = bootstrap.handle_command("init")
    
    assert result == True  # Handled
    assert any("No plate set" in msg for msg in messages)
    print("✅ test_init_without_plates")


def test_init_fairy_garden():
    """Test init command with fairy garden plates."""
    bootstrap = ConsoleBootstrap()
    
    # Store plate info
    bootstrap.set_plate_set({"origin": "fairy_garden_demo", "folder": "/test"})
    
    # Capture callbacks
    room_updates = []
    ascii_updates = []
    diag_updates = []
    messages = []
    
    bootstrap.on_room_update = lambda r, l: room_updates.append((r, l))
    bootstrap.on_ascii_update = lambda lines: ascii_updates.append(lines)
    bootstrap.on_diagnostics_update = lambda d: diag_updates.append(d)
    bootstrap.on_message = lambda msg: messages.append(msg)
    
    # Handle init
    result = bootstrap.handle_command("init")
    
    assert result == True
    assert len(room_updates) == 1
    assert room_updates[0][1] == "Fairy Garden Entrance"
    assert len(ascii_updates) == 1
    assert len(ascii_updates[0]) > 0
    assert len(diag_updates) == 1
    assert diag_updates[0]["world"] == "fairy_garden_demo"
    assert any("awakens" in msg for msg in messages)
    assert bootstrap.is_active()
    print("✅ test_init_fairy_garden")


def test_init_generic():
    """Test init command with generic plates."""
    bootstrap = ConsoleBootstrap()
    
    # Store plate info
    bootstrap.set_plate_set({"origin": "some_other_demo", "folder": "/test"})
    
    # Capture callbacks
    room_updates = []
    diag_updates = []
    
    bootstrap.on_room_update = lambda r, l: room_updates.append((r, l))
    bootstrap.on_diagnostics_update = lambda d: diag_updates.append(d)
    bootstrap.on_message = lambda msg: None
    
    # Handle init
    result = bootstrap.handle_command("init")
    
    assert result == True
    assert len(room_updates) == 1
    assert "some_other_demo" in room_updates[0][1]
    assert diag_updates[0]["world"] == "some_other_demo"
    print("✅ test_init_generic")


def test_non_init_command():
    """Test that non-init commands are not handled."""
    bootstrap = ConsoleBootstrap()
    bootstrap.set_plate_set({"origin": "test", "folder": "/test"})
    
    assert bootstrap.handle_command("look") == False
    assert bootstrap.handle_command("help") == False
    assert bootstrap.handle_command("move north") == False
    print("✅ test_non_init_command")


def test_init_case_insensitive():
    """Test init command is case insensitive."""
    bootstrap = ConsoleBootstrap()
    bootstrap.set_plate_set({"origin": "fairy_garden", "folder": "/test"})
    bootstrap.on_message = lambda msg: None
    bootstrap.on_room_update = lambda r, l: None
    bootstrap.on_ascii_update = lambda lines: None
    bootstrap.on_diagnostics_update = lambda d: None
    
    assert bootstrap.handle_command("INIT") == True
    bootstrap.state = BootstrapState()  # Reset
    assert bootstrap.handle_command("Init") == True
    bootstrap.state = BootstrapState()  # Reset
    assert bootstrap.handle_command("  init  ") == True
    print("✅ test_init_case_insensitive")


def test_bootstrap_reset():
    """Test bootstrap state reset."""
    bootstrap = ConsoleBootstrap()
    bootstrap.set_plate_set({"origin": "test", "folder": "/test"})
    bootstrap.state.active = True
    
    bootstrap.reset()
    
    assert not bootstrap.is_active()
    assert bootstrap.loaded_plate_set is None
    print("✅ test_bootstrap_reset")


def test_bootstrap_state_dataclass():
    """Test BootstrapState dataclass."""
    state = BootstrapState()
    
    assert state.room_id == ""
    assert state.room_label == ""
    assert state.ascii_view == []
    assert state.diagnostics == {}
    assert state.messages == []
    assert state.active == False
    print("✅ test_bootstrap_state_dataclass")


def run_all_tests():
    """Run all bootstrap tests."""
    print("\n=== BOOTSTRAP TESTS ===\n")
    
    test_bootstrap_creation()
    test_set_plate_set()
    test_init_without_plates()
    test_init_fairy_garden()
    test_init_generic()
    test_non_init_command()
    test_init_case_insensitive()
    test_bootstrap_reset()
    test_bootstrap_state_dataclass()
    
    print("\n✅ All bootstrap tests passed (9/9)\n")


if __name__ == "__main__":
    run_all_tests()

"""Tests for Plate Validator."""

import sys
import json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from console.plates.validator import (
    basic_plate_screening,
    validate_plate_type,
    validate_schema_version,
    validate_engine_compat
)
from console.plates.models import PlateType


def test_basic_screening_empty():
    """Test screening rejects empty plates."""
    ok, msg = basic_plate_screening(b"")
    assert not ok
    assert "Empty" in msg
    print("✅ basic_screening empty")


def test_basic_screening_too_small():
    """Test screening rejects too-small plates."""
    ok, msg = basic_plate_screening(b"tiny")
    assert not ok
    assert "small" in msg.lower()
    print("✅ basic_screening too small")


def test_basic_screening_valid_json():
    """Test screening accepts valid JSON plate."""
    plate = {
        "plate_id": "test-001",
        "plate_type": "WORLD",
        "name": "Test",
        "version": "1.0.0"
    }
    raw = json.dumps(plate).encode("utf-8")
    
    ok, msg = basic_plate_screening(raw)
    assert ok
    print("✅ basic_screening valid JSON")


def test_basic_screening_invalid_json():
    """Test screening rejects invalid JSON."""
    raw = b"{invalid json here"
    
    ok, msg = basic_plate_screening(raw)
    assert not ok
    assert "JSON" in msg
    print("✅ basic_screening invalid JSON")


def test_basic_screening_missing_plate_id():
    """Test screening rejects JSON missing plate_id."""
    plate = {
        "plate_type": "WORLD",
        "name": "Test"
    }
    raw = json.dumps(plate).encode("utf-8")
    
    ok, msg = basic_plate_screening(raw)
    assert not ok
    assert "plate_id" in msg
    print("✅ basic_screening missing plate_id")


def test_basic_screening_png():
    """Test screening accepts PNG plates."""
    # Minimal PNG header
    png_header = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100
    
    ok, msg = basic_plate_screening(png_header)
    assert ok
    print("✅ basic_screening PNG")


def test_validate_plate_type_valid():
    """Test valid plate types."""
    ok, pt = validate_plate_type("WORLD")
    assert ok
    assert pt == PlateType.WORLD
    
    ok, pt = validate_plate_type("ENTITY")
    assert ok
    assert pt == PlateType.ENTITY
    print("✅ validate_plate_type valid")


def test_validate_plate_type_invalid():
    """Test invalid plate types."""
    ok, pt = validate_plate_type("INVALID")
    assert not ok
    assert pt == PlateType.UNKNOWN
    print("✅ validate_plate_type invalid")


def test_validate_schema_version_valid():
    """Test valid schema versions."""
    ok, msg = validate_schema_version("1.0.0")
    assert ok
    
    ok, msg = validate_schema_version("12.34.56")
    assert ok
    print("✅ validate_schema_version valid")


def test_validate_schema_version_invalid():
    """Test invalid schema versions."""
    ok, msg = validate_schema_version("")
    assert not ok
    
    ok, msg = validate_schema_version("1.0")
    assert not ok
    
    ok, msg = validate_schema_version("a.b.c")
    assert not ok
    print("✅ validate_schema_version invalid")


def test_validate_engine_compat_valid():
    """Test valid engine compatibility strings."""
    ok, msg = validate_engine_compat(">=12.0.0 <13.0.0")
    assert ok
    
    ok, msg = validate_engine_compat("12.0.0")
    assert ok
    print("✅ validate_engine_compat valid")


def test_validate_engine_compat_invalid():
    """Test invalid engine compatibility strings."""
    ok, msg = validate_engine_compat("")
    assert not ok
    
    ok, msg = validate_engine_compat("no-version-here")
    assert not ok
    print("✅ validate_engine_compat invalid")


def run_all_tests():
    """Run all validator tests."""
    print("\n=== PLATE VALIDATOR TESTS ===\n")
    
    test_basic_screening_empty()
    test_basic_screening_too_small()
    test_basic_screening_valid_json()
    test_basic_screening_invalid_json()
    test_basic_screening_missing_plate_id()
    test_basic_screening_png()
    test_validate_plate_type_valid()
    test_validate_plate_type_invalid()
    test_validate_schema_version_valid()
    test_validate_schema_version_invalid()
    test_validate_engine_compat_valid()
    test_validate_engine_compat_invalid()
    
    print("\n✅ All validator tests passed\n")


if __name__ == "__main__":
    run_all_tests()

"""Tests for LLM Translator."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from console.llm.translator import Translator, SafeTranslator
from console.llm.alphabet import AlphaCommand


def test_engine_to_alpha():
    """Test engine snapshot to alpha conversion."""
    translator = Translator()
    
    snapshot = {
        "room_id": "room_01",
        "human_present": True,
        "tinkerbell_present": False,
        "resource_mode": "ACTIVE",
        "zone": "GREEN",
        "builders": [
            {"id": "b1", "state": "idle"}
        ],
        "events": ["EVT_START"],
        "goal": "Test goal"
    }
    
    alpha = translator.engine_to_alpha(snapshot)
    
    assert alpha.state.room_id == "room_01"
    assert alpha.state.human_present is True
    assert alpha.state.zone == "GREEN"
    assert len(alpha.builders) == 1
    assert len(alpha.events) == 1
    assert alpha.goal == "Test goal"
    print("✅ engine_to_alpha")


def test_alpha_to_prompt():
    """Test alpha to prompt conversion."""
    translator = Translator()
    
    snapshot = {
        "room_id": "r1",
        "human_present": True,
        "tinkerbell_present": False,
        "resource_mode": "ACTIVE",
        "zone": "GREEN",
        "builders": [],
        "events": []
    }
    
    alpha = translator.engine_to_alpha(snapshot)
    prompt = translator.alpha_to_prompt(alpha)
    
    assert "R:r1" in prompt
    assert "OUTPUT:" in prompt
    print("✅ alpha_to_prompt")


def test_parse_llm_output_wait():
    """Test parsing WAIT command."""
    translator = Translator()
    
    ok, msg, cmd = translator.parse_llm_output("WAIT")
    assert ok
    assert cmd.kind == "WAIT"
    print("✅ parse_llm_output WAIT")


def test_parse_llm_output_move():
    """Test parsing MOVE command."""
    translator = Translator()
    
    ok, msg, cmd = translator.parse_llm_output("MOVE:N")
    assert ok
    assert cmd.kind == "MOVE"
    assert cmd.arg == "N"
    print("✅ parse_llm_output MOVE")


def test_parse_llm_output_multiline():
    """Test parsing multiline output (takes first line)."""
    translator = Translator()
    
    ok, msg, cmd = translator.parse_llm_output("WAIT\nsome other text")
    assert ok
    assert cmd.kind == "WAIT"
    print("✅ parse_llm_output multiline")


def test_parse_llm_output_invalid():
    """Test parsing invalid output."""
    translator = Translator()
    
    ok, msg, cmd = translator.parse_llm_output("")
    assert not ok
    
    ok, msg, cmd = translator.parse_llm_output("INVALID")
    assert not ok
    
    ok, msg, cmd = translator.parse_llm_output("MOVE:")
    assert not ok  # No direction
    print("✅ parse_llm_output invalid")


def test_command_to_engine():
    """Test command to engine format conversion."""
    translator = Translator()
    
    cmd = AlphaCommand(kind="MOVE", arg="N")
    engine_cmd = translator.command_to_engine(cmd)
    
    assert engine_cmd["command"] == "MOVE"
    assert engine_cmd["argument"] == "N"
    print("✅ command_to_engine")


def test_safe_translator_rate_limit():
    """Test SafeTranslator rate limiting."""
    translator = SafeTranslator(max_commands_per_minute=3)
    
    # First 3 should succeed
    for i in range(3):
        ok, msg, cmd = translator.parse_llm_output("WAIT")
        assert ok, f"Command {i+1} should succeed"
    
    # 4th should fail
    ok, msg, cmd = translator.parse_llm_output("WAIT")
    assert not ok
    assert "Rate limit" in msg
    
    # Reset and try again
    translator.reset_rate_limit()
    ok, msg, cmd = translator.parse_llm_output("WAIT")
    assert ok
    print("✅ SafeTranslator rate limit")


def run_all_tests():
    """Run all translator tests."""
    print("\n=== TRANSLATOR TESTS ===\n")
    
    test_engine_to_alpha()
    test_alpha_to_prompt()
    test_parse_llm_output_wait()
    test_parse_llm_output_move()
    test_parse_llm_output_multiline()
    test_parse_llm_output_invalid()
    test_command_to_engine()
    test_safe_translator_rate_limit()
    
    print("\n✅ All translator tests passed\n")


if __name__ == "__main__":
    run_all_tests()

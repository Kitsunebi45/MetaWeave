#!/usr/bin/env python3
"""Acorn Console - Entry Point.

Run with:
    python run_console.py
"""

from console.app import run_app

if __name__ == "__main__":
    run_app()

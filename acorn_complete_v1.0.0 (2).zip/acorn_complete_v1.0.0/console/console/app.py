"""Acorn Console Application Entry Point."""

from console.ui.main_window import MainWindow
from console.runtime.session import SessionController


def run_app() -> None:
    """Run the Acorn Console application."""
    session = SessionController()
    ui = MainWindow(session=session)
    ui.run()

"""Acorn Console Avatar Mode.

Avatar continuity mode for when human is inactive.
Avatar mode allows:
- Resource drip (minimal accumulation)
- Camera room maintenance
- Fairy planning chatter (internal)

Avatar mode MUST NOT:
- Claim identity
- Store names
- Make decisions on behalf of human
- Access protected resources
"""

from dataclasses import dataclass
import time


@dataclass
class AvatarMode:
    """Avatar mode state.
    
    Activated after period of human inactivity.
    Maintains presence without identity claims.
    """
    active: bool = False
    since_epoch: float = 0.0
    drip_resources: bool = True
    drip_rate: float = 0.1  # Resource accumulation rate (units/tick)
    
    # Safety constraints
    can_move: bool = False          # Avatar cannot move
    can_speak: bool = False         # Avatar cannot speak as human
    can_trade: bool = False         # Avatar cannot trade
    can_build: bool = False         # Avatar cannot build
    can_observe: bool = True        # Avatar can observe
    can_accumulate: bool = True     # Avatar can accumulate resources
    
    def activate(self) -> None:
        """Activate avatar mode."""
        self.active = True
        self.since_epoch = time.time()
    
    def deactivate(self) -> None:
        """Deactivate avatar mode."""
        self.active = False
    
    def time_active_seconds(self) -> float:
        """Get time avatar has been active.
        
        Returns:
            Seconds since activation, or 0 if not active
        """
        if not self.active:
            return 0.0
        return time.time() - self.since_epoch
    
    def get_permissions(self) -> dict:
        """Get current avatar permissions.
        
        Returns:
            Dictionary of allowed actions
        """
        return {
            "move": self.can_move,
            "speak": self.can_speak,
            "trade": self.can_trade,
            "build": self.can_build,
            "observe": self.can_observe,
            "accumulate": self.can_accumulate
        }
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "active": self.active,
            "since": self.since_epoch,
            "time_active_seconds": self.time_active_seconds(),
            "drip_resources": self.drip_resources,
            "drip_rate": self.drip_rate,
            "permissions": self.get_permissions()
        }
    
    def to_engine_packet(self) -> dict:
        """Create packet for engine notification.
        
        Returns:
            Dictionary suitable for engine protocol
        """
        return {
            "avatar_active": self.active,
            "drip_resources": self.drip_resources and self.active,
            "permissions": self.get_permissions() if self.active else {}
        }


class AvatarManager:
    """Manager for avatar mode transitions.
    
    Handles activation/deactivation based on user activity.
    """
    
    def __init__(self, inactivity_threshold_minutes: int = 30):
        """Initialize avatar manager.
        
        Args:
            inactivity_threshold_minutes: Minutes of inactivity before avatar activates
        """
        self.threshold_seconds = inactivity_threshold_minutes * 60
        self.avatar = AvatarMode()
        self.last_activity_epoch = time.time()
    
    def note_activity(self) -> bool:
        """Note user activity.
        
        Returns:
            True if avatar was deactivated
        """
        self.last_activity_epoch = time.time()
        
        if self.avatar.active:
            self.avatar.deactivate()
            return True
        return False
    
    def check_inactivity(self) -> bool:
        """Check if inactivity threshold reached.
        
        Returns:
            True if avatar was activated
        """
        elapsed = time.time() - self.last_activity_epoch
        
        if elapsed >= self.threshold_seconds and not self.avatar.active:
            self.avatar.activate()
            return True
        return False
    
    def get_state(self) -> AvatarMode:
        """Get current avatar state."""
        return self.avatar
    
    def set_threshold(self, minutes: int) -> None:
        """Set inactivity threshold.
        
        Args:
            minutes: New threshold in minutes
        """
        self.threshold_seconds = max(1, minutes) * 60

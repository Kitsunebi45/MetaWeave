"""Acorn Console Printing.

Print snapshot management for free version.
Free version can only print text snapshots - no structured export.
"""

from datetime import datetime
from pathlib import Path
from typing import Callable, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .session import SessionController


class PrintManager:
    """Manager for printing snapshots.
    
    Free version limitations:
    - Text files only
    - No structured JSON export
    - No replay logs
    """
    
    def __init__(
        self,
        session: Optional["SessionController"] = None,
        output_dir: Optional[Path] = None
    ):
        """Initialize print manager.
        
        Args:
            session: Session controller for notifications
            output_dir: Directory for print output
        """
        self.session = session
        self.output_dir = Path(output_dir) if output_dir else Path("prints")
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def _notify(self, message: str) -> None:
        """Send notification via session."""
        if self.session and self.session.on_text_output:
            self.session.on_text_output(message)
    
    def _write_file(self, prefix: str, content: str) -> Path:
        """Write content to file.
        
        Args:
            prefix: Filename prefix
            content: File content
            
        Returns:
            Path to created file
        """
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{prefix}_{ts}.txt"
        filepath = self.output_dir / filename
        
        filepath.write_text(content, encoding="utf-8")
        self._notify(f"[print] Saved: {filepath}")
        
        return filepath
    
    def print_text(self, text: str) -> Path:
        """Print text console contents.
        
        Args:
            text: Text to print
            
        Returns:
            Path to created file
        """
        # Add header
        header = [
            "=" * 60,
            "ACORN CONSOLE - TEXT SNAPSHOT",
            f"Timestamp: {datetime.now().isoformat()}",
            "=" * 60,
            ""
        ]
        content = "\n".join(header) + text
        
        return self._write_file("text", content)
    
    def print_ascii(self, ascii_map: str) -> Path:
        """Print ASCII visualization.
        
        Args:
            ascii_map: ASCII map content
            
        Returns:
            Path to created file
        """
        # Add header
        header = [
            "=" * 60,
            "ACORN CONSOLE - ASCII VISUALIZATION",
            f"Timestamp: {datetime.now().isoformat()}",
            "=" * 60,
            ""
        ]
        content = "\n".join(header) + ascii_map
        
        return self._write_file("ascii", content)
    
    def print_diagnostics(self, diag: dict) -> Path:
        """Print diagnostics.
        
        Args:
            diag: Diagnostics dictionary
            
        Returns:
            Path to created file
        """
        # Format diagnostics
        lines = [
            "=" * 60,
            "ACORN CONSOLE - DIAGNOSTICS",
            f"Timestamp: {datetime.now().isoformat()}",
            "=" * 60,
            ""
        ]
        
        for k, v in (diag or {}).items():
            lines.append(f"{k}: {v}")
        
        content = "\n".join(lines)
        return self._write_file("diag", content)
    
    def print_full(self, text: str, ascii_map: str, diag: dict) -> Path:
        """Print full snapshot (text + ASCII + diagnostics).
        
        Args:
            text: Text console content
            ascii_map: ASCII visualization
            diag: Diagnostics dictionary
            
        Returns:
            Path to created file
        """
        sections = []
        
        # Header
        sections.append("=" * 60)
        sections.append("ACORN CONSOLE - FULL SNAPSHOT")
        sections.append(f"Timestamp: {datetime.now().isoformat()}")
        sections.append("=" * 60)
        sections.append("")
        
        # Text section
        sections.append("-" * 40)
        sections.append("TEXT CONSOLE")
        sections.append("-" * 40)
        sections.append(text)
        sections.append("")
        
        # ASCII section
        sections.append("-" * 40)
        sections.append("ASCII VISUALIZATION")
        sections.append("-" * 40)
        sections.append(ascii_map)
        sections.append("")
        
        # Diagnostics section
        sections.append("-" * 40)
        sections.append("DIAGNOSTICS")
        sections.append("-" * 40)
        for k, v in (diag or {}).items():
            sections.append(f"{k}: {v}")
        
        content = "\n".join(sections)
        return self._write_file("full", content)

"""Acorn Console Session Controller.

Central session management for the console application.
"""

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from console.config import CONFIG
from console.engine.discovery import discover_engines
from console.engine.connector import EngineConnector
from console.plates.loader import load_plate_from_path
from console.plates.validator import basic_plate_screening
from console.plates.plate_set_loader import PlateSetError, scan_plate_folder, PlateSet
from console.llm.translator import Translator
from console.llm.llama_adapter import LlamaAdapter
from .zones import ZoneStatus, QuarantineStatus
from .avatar import AvatarMode
from .bootstrap import ConsoleBootstrap


@dataclass
class VisualState:
    """Visual state for UI rendering."""
    room_id: str = "UNKNOWN"
    minimap_ascii: str = ""
    primitives: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class SessionState:
    """Complete session state."""
    diagnostics: Dict[str, Any]
    visual: VisualState


class SessionController:
    """Central controller for console session.
    
    Manages:
    - Engine connection
    - Plate loading
    - User input handling
    - State polling
    - Avatar mode
    - Zone tracking
    """
    
    def __init__(self):
        """Initialize session controller."""
        # Engine connection
        self.connector = EngineConnector()
        
        # LLM translation layer
        self.translator = Translator()
        self.llm = LlamaAdapter()
        
        # State
        self.latest_state: Optional[SessionState] = None
        
        # Callbacks
        self.on_text_output: Optional[Callable[[str], None]] = None
        self.on_state_update: Optional[Callable[[], None]] = None
        
        # Discovery
        self._engine_list: List[str] = []
        self._last_discovery_epoch: float = 0.0
        
        # User activity tracking
        self.last_user_activity_epoch: float = time.time()
        
        # Zone and quarantine status
        self.zone_status = ZoneStatus()
        self.quarantine = QuarantineStatus(minutes_required=CONFIG.quarantine_minutes)
        
        # Avatar mode
        self.avatar = AvatarMode()
        
        # Pending plate set (cached when not connected)
        self.pending_plate_set: Optional[PlateSet] = None
        
        # Bootstrap handler for init command
        self.bootstrap = ConsoleBootstrap()
        self._wire_bootstrap_callbacks()
    
    def _wire_bootstrap_callbacks(self) -> None:
        """Wire up bootstrap callbacks to session outputs."""
        
        def ensure_state():
            """Ensure latest_state exists."""
            if self.latest_state is None:
                self.latest_state = SessionState(
                    diagnostics={},
                    visual=VisualState()
                )
        
        def on_room_update(room_id: str, label: str) -> None:
            ensure_state()
            self.latest_state.visual.room_id = label
            if self.on_state_update:
                self.on_state_update()
        
        def on_ascii_update(lines: List[str]) -> None:
            ensure_state()
            self.latest_state.visual.minimap_ascii = "\n".join(lines)
            if self.on_state_update:
                self.on_state_update()
        
        def on_diagnostics_update(diag: Dict[str, Any]) -> None:
            ensure_state()
            self.latest_state.diagnostics.update(diag)
            if self.on_state_update:
                self.on_state_update()
        
        def on_message(msg: str) -> None:
            self._emit(msg)
        
        self.bootstrap.on_room_update = on_room_update
        self.bootstrap.on_ascii_update = on_ascii_update
        self.bootstrap.on_diagnostics_update = on_diagnostics_update
        self.bootstrap.on_message = on_message
    
    # =========================================================================
    # DISCOVERY & CONNECTION
    # =========================================================================
    
    def discovery_due(self) -> bool:
        """Check if discovery refresh is due.
        
        Returns:
            True if discovery should be run
        """
        elapsed_ms = (time.time() - self._last_discovery_epoch) * 1000
        return elapsed_ms >= CONFIG.discovery_interval_ms
    
    def refresh_engine_list(self) -> List[str]:
        """Refresh the list of available engines.
        
        Returns:
            List of engine identifiers
        """
        self._engine_list = discover_engines()
        self._last_discovery_epoch = time.time()
        return list(self._engine_list)
    
    def connect(self, engine_id: str) -> tuple:
        """Connect to an engine.
        
        If a plate set was previously validated but not loaded (pending),
        it will be automatically loaded after successful connection.
        
        Args:
            engine_id: Engine identifier
            
        Returns:
            Tuple of (success, message)
        """
        ok, msg = self.connector.connect(engine_id)
        self._emit(f"[console] Connect: {msg}")
        
        # Auto-load pending plate set after successful connection
        if ok and self.pending_plate_set is not None:
            self._emit("[console] Loading pending plate set...")
            load_ok, load_msg = self._send_plate_set_to_engine(self.pending_plate_set)
            if load_ok:
                self._emit("[console] Plate set loaded successfully!")
            else:
                self._emit(f"[console] Plate set load failed: {load_msg}")
            self.pending_plate_set = None
        
        return ok, msg
    
    def disconnect(self) -> None:
        """Disconnect from current engine."""
        self.connector.disconnect()
        self._emit("[console] Disconnected")
    
    # =========================================================================
    # PLATE LOADING
    # =========================================================================
    
    def load_plate(self, path: str) -> tuple:
        """Load a single plate from file (deprecated - use load_plate_set).
        
        Args:
            path: Path to plate file
            
        Returns:
            Tuple of (success, message)
        """
        # Load from file
        ok, msg, payload = load_plate_from_path(path)
        if not ok:
            self._emit(f"[console] Plate load failed: {msg}")
            return False, msg
        
        # Basic screening (engine enforces full validation)
        ok2, msg2 = basic_plate_screening(payload.raw)
        if not ok2:
            self._emit(f"[console] Plate screening failed: {msg2}")
            return False, msg2
        
        # Send to engine
        ok3, msg3 = self.connector.load_plate(payload.raw, payload.meta)
        
        if ok3:
            self._emit(f"[console] Plate loaded: {payload.meta.get('filename', path)}")
        else:
            self._emit(f"[console] Plate load failed: {msg3}")
        
        return ok3, msg3
    
    def load_plate_set(self, folder_path: str) -> tuple:
        """Load a complete plate set from a folder.
        
        Validates that folder contains:
        - 1 world plate
        - 1 characters plate
        - 1 learning plate
        
        All must share the same origin_plate_set.
        
        If not connected to engine, caches the plate set for auto-loading
        when connection is established.
        
        Args:
            folder_path: Path to folder containing plate files
            
        Returns:
            Tuple of (success, message)
        """
        try:
            plate_set = scan_plate_folder(folder_path)
        except PlateSetError as e:
            self._emit(f"[console] Plate set error: {e}")
            return False, str(e)
        except Exception as e:
            self._emit(f"[console] Unexpected error: {e}")
            return False, str(e)
        
        # Log validation success
        self._emit("[console] Plate set validated:")
        for line in plate_set.get_summary():
            self._emit(f"  {line}")
        
        # Store plate set info in bootstrap for init command
        self.bootstrap.set_plate_set({
            "origin": plate_set.origin,
            "folder": plate_set.folder_path,
            "world_id": plate_set.plates.get("world", {}).plate_id if plate_set.plates.get("world") else None,
            "characters_id": plate_set.plates.get("characters", {}).plate_id if plate_set.plates.get("characters") else None,
            "learning_id": plate_set.plates.get("learning", {}).plate_id if plate_set.plates.get("learning") else None,
        })
        
        # Check if connected before sending to engine
        if not self.connector.is_connected():
            # Cache for auto-load after connection
            self.pending_plate_set = plate_set
            self._emit("[console] Engine not connected - plate set cached")
            self._emit("[console] Connect to engine to complete load")
            return True, "Plate set validated (pending connection)"
        
        # Send to engine atomically
        ok, msg = self._send_plate_set_to_engine(plate_set)
        
        if ok:
            self._emit("[console] Plate set loaded successfully!")
        else:
            self._emit(f"[console] Plate set load failed: {msg}")
        
        return ok, msg
    
    def _send_plate_set_to_engine(self, plate_set: PlateSet) -> tuple:
        """Send complete plate set to engine atomically.
        
        Args:
            plate_set: Validated PlateSet from loader
            
        Returns:
            Tuple of (success, message)
        """
        if not self.connector.is_connected():
            return False, "Not connected to engine"
        
        # Build payload for engine using PlateSet method
        payload = plate_set.to_engine_payload()
        
        # Send as atomic load command
        return self.connector.send_command("load_plate_set", payload)
    
    # =========================================================================
    # USER INPUT
    # =========================================================================
    
    def note_user_activity(self) -> None:
        """Note user activity (for avatar mode tracking)."""
        self.last_user_activity_epoch = time.time()
        
        if self.avatar.active:
            self.avatar.active = False
            self._emit("[console] Avatar mode off (user activity)")
    
    def handle_user_input(self, text: str) -> None:
        """Handle user input text.
        
        Args:
            text: User input
        """
        self.note_user_activity()
        
        # Check for local commands (slash prefix)
        if text.startswith("/"):
            self._handle_local_command(text[1:])
            return
        
        # Check for bootstrap commands (init, etc.)
        if self.bootstrap.handle_command(text):
            return
        
        # Send to engine
        ok, msg = self.connector.send_user_text(text)
        if not ok:
            self._emit(f"[console] Send failed: {msg}")
    
    def _handle_local_command(self, cmd: str) -> None:
        """Handle local console commands.
        
        Args:
            cmd: Command (without leading /)
        """
        parts = cmd.strip().split(maxsplit=1)
        if not parts:
            return
        
        name = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""
        
        if name == "help":
            self._emit("Available commands:")
            self._emit("  /help - Show this help")
            self._emit("  /status - Show connection status")
            self._emit("  /zone - Show zone status")
            self._emit("  /avatar - Show avatar mode status")
            self._emit("  /clear - Clear console")
        
        elif name == "status":
            connected = self.connector.is_connected()
            self._emit(f"Connected: {connected}")
            if self.connector.conn:
                self._emit(f"Engine: {self.connector.conn.engine_id}")
        
        elif name == "zone":
            self._emit(f"Zone: {self.zone_status.zone}")
            self._emit(f"Reason: {self.zone_status.reason}")
            self._emit(f"Quarantine: {self.quarantine.active}")
        
        elif name == "avatar":
            self._emit(f"Avatar mode: {self.avatar.active}")
            if self.avatar.active:
                self._emit(f"Active for: {self.avatar.time_active_seconds():.0f}s")
        
        elif name == "clear":
            # Just emit a marker - UI should handle actual clearing
            self._emit("---CLEAR---")
        
        else:
            self._emit(f"Unknown command: /{name}")
    
    # =========================================================================
    # TICK LOOP
    # =========================================================================
    
    def tick(self) -> None:
        """Tick the session (called periodically by UI).
        
        NOTE: Console operates in REACTIVE mode with Engine v12.19.0.
        We only receive messages, we don't poll or request state.
        The bootstrap provides visual feedback until engine events arrive.
        """
        now = time.time()
        
        # Check for inactivity → avatar mode (local tracking only)
        inactivity_seconds = CONFIG.inactivity_minutes * 60
        if (now - self.last_user_activity_epoch) >= inactivity_seconds:
            if not self.avatar.active:
                self.avatar.active = True
                self.avatar.since_epoch = now
                self._emit("[console] Avatar mode on (inactivity)")
        
        # Check for any pending messages from engine (receive-only)
        if self.connector.is_connected():
            snap = self.connector.poll_state()
            if snap:
                self._apply_engine_snapshot(snap)
        
        # NOTE: Do NOT send avatar_presence - engine v12.19.0 doesn't support it
        # Avatar mode is tracked locally for future engine integration
    
    # =========================================================================
    # DIAGNOSTICS
    # =========================================================================
    
    def get_diagnostics_snapshot(self) -> Dict[str, Any]:
        """Get current diagnostics snapshot.
        
        Returns:
            Diagnostics dictionary
        """
        base = {
            "connected": self.connector.is_connected(),
            "zone": self.zone_status.zone,
            "zone_reason": self.zone_status.reason,
            "quarantine_active": self.quarantine.active,
            "quarantine_room": self.quarantine.room_id,
            "avatar_mode": self.avatar.active,
            "last_user_activity": int(self.last_user_activity_epoch),
        }
        
        if self.latest_state:
            base.update(self.latest_state.diagnostics)
        
        return base
    
    # =========================================================================
    # INTERNAL
    # =========================================================================
    
    def _apply_engine_snapshot(self, snap: Dict[str, Any]) -> None:
        """Apply engine snapshot to session state.
        
        Handles both legacy snapshot format and new engine state format.
        
        Args:
            snap: Engine snapshot dictionary
        """
        # Check message type
        msg_type = snap.get("type", "")
        
        if msg_type == "state":
            # New engine state format
            self._apply_engine_state(snap)
            return
        
        if msg_type == "event":
            # Engine event - display in console
            event = snap.get("event", "unknown")
            if event == "entity_moved":
                name = snap.get("name", "Entity")
                to_room = snap.get("to", "somewhere")
                self._emit(f"[world] {name} moved to {to_room}")
            elif event == "simulation_started":
                self._emit("[world] ✨ Simulation has begun!")
            elif event == "avatar_activated":
                room_name = snap.get("room_name", "unknown")
                self._emit(f"[avatar] 🎭 Avatar mode ACTIVATED")
                self._emit(f"[avatar] You are in: {room_name}")
                self._emit("[avatar] Try: look, n/s/e/w, say <text>")
            elif event == "avatar_moved":
                from_name = snap.get("from_name", "somewhere")
                to_name = snap.get("to_name", "somewhere")
                self._emit(f"[avatar] 🚶 Moved from {from_name} to {to_name}")
            elif event == "room_description":
                desc = snap.get("description", "")
                if desc:
                    for line in desc.split("\n"):
                        self._emit(line)
            elif event == "avatar_speech":
                text = snap.get("text", "")
                room_name = snap.get("room_name", "here")
                self._emit(f"[avatar] You say: \"{text}\"")
            elif event == "npc_response":
                response = snap.get("response", "")
                if response:
                    self._emit(f"[world] {response}")
            return
        
        if msg_type == "command_result":
            # Response to a command we sent
            command = snap.get("command", "")
            message = snap.get("message", "")
            success = snap.get("success", True)
            
            if message:
                prefix = "✓" if success else "✗"
                self._emit(f"[{prefix}] {message}")
            
            # Handle look command result
            if command == "look" and "description" in snap:
                for line in snap["description"].split("\n"):
                    self._emit(line)
            return
        
        # Legacy format
        diag = snap.get("diagnostics", {})
        visual_raw = snap.get("visual", {})
        
        # Update zone status
        zone = diag.get("zone")
        if zone in ("GREEN", "YELLOW", "RED"):
            self.zone_status.zone = zone
            self.zone_status.reason = diag.get("zone_reason", "")
        
        # Update quarantine status
        self.quarantine.active = bool(diag.get("quarantine_active", False))
        if diag.get("quarantine_room"):
            self.quarantine.room_id = diag.get("quarantine_room")
        
        # Build visual state
        visual = VisualState(
            room_id=visual_raw.get("room_id", diag.get("room_id", "UNKNOWN")),
            minimap_ascii=visual_raw.get("minimap_ascii", ""),
            primitives=visual_raw.get("primitives", [])
        )
        
        # Update session state
        self.latest_state = SessionState(diagnostics=diag, visual=visual)
        
        # Notify UI
        if self.on_state_update:
            self.on_state_update()
    
    def _apply_engine_state(self, state: Dict[str, Any]) -> None:
        """Apply engine state message to session.
        
        Args:
            state: Engine state dictionary
        """
        # Extract diagnostics from engine state
        diag = {
            "world": state.get("world", "unknown"),
            "mode": state.get("mode", "unknown"),
            "tick": state.get("tick", 0),
            "rooms": state.get("rooms", 0),
            "connected": True,
        }
        
        # Add entity counts
        entities = state.get("entities", {})
        if isinstance(entities, dict):
            diag["fairies"] = entities.get("fairies", 0)
            diag["goblins"] = entities.get("goblins", 0)
            diag["total_entities"] = entities.get("total", 0)
        
        # Add avatar info
        avatar = state.get("avatar", {})
        if isinstance(avatar, dict):
            diag["avatar_active"] = avatar.get("active", False)
            diag["avatar_room"] = avatar.get("room_name", "")
        
        # Build visual state
        avatar_room_name = avatar.get("room_name", "") if isinstance(avatar, dict) else ""
        
        if self.bootstrap.is_active():
            # Use bootstrap visuals but update with real avatar location
            visual = VisualState(
                room_id=avatar_room_name or self.bootstrap.state.room_label,
                minimap_ascii="\n".join(self.bootstrap.state.ascii_view),
                primitives=[]
            )
        else:
            visual = VisualState(
                room_id=avatar_room_name or state.get("world", "UNKNOWN"),
                minimap_ascii="",
                primitives=[]
            )
        
        # Update session state with engine data
        if self.latest_state:
            # Merge with existing state
            self.latest_state.diagnostics.update(diag)
        else:
            self.latest_state = SessionState(diagnostics=diag, visual=visual)
        
        # Notify UI
        if self.on_state_update:
            self.on_state_update()
    
    def _emit(self, msg: str) -> None:
        """Emit text to console output.
        
        Args:
            msg: Message to emit
        """
        if self.on_text_output:
            self.on_text_output(msg)

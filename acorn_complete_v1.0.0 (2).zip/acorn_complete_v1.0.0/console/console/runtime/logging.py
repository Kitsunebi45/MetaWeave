"""Acorn Console Logging.

Logging utilities for console events.
"""

from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
import json


class ConsoleLogger:
    """Simple logger for console events.
    
    Note: Free version does NOT support replay logs.
    This logger is for local debugging only.
    """
    
    def __init__(self, log_dir: Optional[Path] = None, enabled: bool = True):
        """Initialize logger.
        
        Args:
            log_dir: Directory for log files (None = no file logging)
            enabled: Whether logging is enabled
        """
        self.log_dir = Path(log_dir) if log_dir else None
        self.enabled = enabled
        self._log_file = None
        self._buffer = []
        
        if self.log_dir:
            self.log_dir.mkdir(parents=True, exist_ok=True)
    
    def _timestamp(self) -> str:
        """Get current timestamp."""
        return datetime.now(timezone.utc).isoformat()
    
    def log(self, level: str, message: str, data: Optional[dict] = None) -> None:
        """Log a message.
        
        Args:
            level: Log level (INFO, WARN, ERROR, DEBUG)
            message: Log message
            data: Optional structured data
        """
        if not self.enabled:
            return
        
        entry = {
            "timestamp": self._timestamp(),
            "level": level,
            "message": message
        }
        
        if data:
            entry["data"] = data
        
        self._buffer.append(entry)
        
        # Keep buffer bounded
        if len(self._buffer) > 1000:
            self._buffer = self._buffer[-500:]
    
    def info(self, message: str, data: Optional[dict] = None) -> None:
        """Log info message."""
        self.log("INFO", message, data)
    
    def warn(self, message: str, data: Optional[dict] = None) -> None:
        """Log warning message."""
        self.log("WARN", message, data)
    
    def error(self, message: str, data: Optional[dict] = None) -> None:
        """Log error message."""
        self.log("ERROR", message, data)
    
    def debug(self, message: str, data: Optional[dict] = None) -> None:
        """Log debug message."""
        self.log("DEBUG", message, data)
    
    def get_recent(self, count: int = 50) -> list:
        """Get recent log entries.
        
        Args:
            count: Number of entries to return
            
        Returns:
            List of recent log entries
        """
        return self._buffer[-count:]
    
    def flush_to_file(self) -> Optional[Path]:
        """Flush buffer to file.
        
        Returns:
            Path to log file, or None if no log_dir
        """
        if not self.log_dir or not self._buffer:
            return None
        
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = self.log_dir / f"console_{ts}.log"
        
        with open(filepath, "w", encoding="utf-8") as f:
            for entry in self._buffer:
                f.write(json.dumps(entry) + "\n")
        
        return filepath
    
    def clear(self) -> None:
        """Clear the log buffer."""
        self._buffer.clear()

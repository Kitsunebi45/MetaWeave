"""Acorn Console Zone Management.

Zone status tracking for safety boundaries.
"""

from dataclasses import dataclass
from typing import Literal
import time


# Zone types
Zone = Literal["GREEN", "YELLOW", "RED"]


@dataclass
class ZoneStatus:
    """Current zone status."""
    zone: Zone = "GREEN"
    reason: str = ""
    last_change_epoch: float = 0.0
    
    def set_zone(self, zone: Zone, reason: str = "") -> bool:
        """Set the current zone.
        
        Args:
            zone: New zone value
            reason: Reason for zone change
            
        Returns:
            True if zone changed
        """
        if zone not in ("GREEN", "YELLOW", "RED"):
            return False
        
        changed = zone != self.zone
        self.zone = zone
        self.reason = reason
        self.last_change_epoch = time.time()
        return changed
    
    def is_safe(self) -> bool:
        """Check if current zone is safe (GREEN)."""
        return self.zone == "GREEN"
    
    def is_caution(self) -> bool:
        """Check if current zone requires caution (YELLOW)."""
        return self.zone == "YELLOW"
    
    def is_danger(self) -> bool:
        """Check if current zone is dangerous (RED)."""
        return self.zone == "RED"
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "zone": self.zone,
            "reason": self.reason,
            "last_change": self.last_change_epoch
        }


@dataclass
class QuarantineStatus:
    """Quarantine status for trust boundaries."""
    active: bool = False
    room_id: str = ""
    started_epoch: float = 0.0
    minutes_required: int = 60  # 1 hour default
    
    def start(self, room_id: str) -> None:
        """Start quarantine.
        
        Args:
            room_id: Room where quarantine started
        """
        self.active = True
        self.room_id = room_id
        self.started_epoch = time.time()
    
    def end(self) -> None:
        """End quarantine."""
        self.active = False
    
    def time_remaining_seconds(self) -> float:
        """Get remaining quarantine time in seconds.
        
        Returns:
            Seconds remaining, or 0 if not active or complete
        """
        if not self.active:
            return 0.0
        
        elapsed = time.time() - self.started_epoch
        required = self.minutes_required * 60
        remaining = required - elapsed
        
        return max(0.0, remaining)
    
    def is_complete(self) -> bool:
        """Check if quarantine period is complete.
        
        Returns:
            True if quarantine is complete
        """
        if not self.active:
            return True
        return self.time_remaining_seconds() <= 0
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "active": self.active,
            "room_id": self.room_id,
            "started": self.started_epoch,
            "minutes_required": self.minutes_required,
            "time_remaining_seconds": self.time_remaining_seconds(),
            "is_complete": self.is_complete()
        }


def zone_from_string(s: str) -> Zone:
    """Convert string to Zone.
    
    Args:
        s: Zone string
        
    Returns:
        Zone value (defaults to GREEN if invalid)
    """
    s = (s or "").upper()
    if s in ("GREEN", "YELLOW", "RED"):
        return s
    return "GREEN"

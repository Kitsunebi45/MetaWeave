"""Acorn Console Snapshots.

Snapshot management for state capture.
Note: Free version only supports print snapshots, not structured export.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
import json


@dataclass
class Snapshot:
    """A state snapshot."""
    snapshot_id: str
    timestamp: str
    snapshot_type: str  # "text", "ascii", "diagnostics", "full"
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "snapshot_id": self.snapshot_id,
            "timestamp": self.timestamp,
            "type": self.snapshot_type,
            "content": self.content,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "Snapshot":
        """Create from dictionary."""
        return cls(
            snapshot_id=data.get("snapshot_id", ""),
            timestamp=data.get("timestamp", ""),
            snapshot_type=data.get("type", "unknown"),
            content=data.get("content", ""),
            metadata=data.get("metadata", {})
        )


class SnapshotManager:
    """Manager for state snapshots.
    
    Free version limitations:
    - No structured export
    - No JSON export
    - Print to text files only
    """
    
    def __init__(self, output_dir: Optional[Path] = None):
        """Initialize snapshot manager.
        
        Args:
            output_dir: Directory for snapshot output
        """
        self.output_dir = Path(output_dir) if output_dir else Path("snapshots")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self._history: List[Snapshot] = []
        self._counter = 0
    
    def _next_id(self) -> str:
        """Get next snapshot ID."""
        self._counter += 1
        return f"snap_{self._counter:06d}"
    
    def _timestamp(self) -> str:
        """Get current timestamp."""
        return datetime.now(timezone.utc).isoformat()
    
    def capture_text(self, content: str, metadata: Optional[dict] = None) -> Snapshot:
        """Capture a text snapshot.
        
        Args:
            content: Text content
            metadata: Optional metadata
            
        Returns:
            Created snapshot
        """
        snap = Snapshot(
            snapshot_id=self._next_id(),
            timestamp=self._timestamp(),
            snapshot_type="text",
            content=content,
            metadata=metadata or {}
        )
        self._history.append(snap)
        return snap
    
    def capture_ascii(self, content: str, metadata: Optional[dict] = None) -> Snapshot:
        """Capture an ASCII art snapshot.
        
        Args:
            content: ASCII content
            metadata: Optional metadata
            
        Returns:
            Created snapshot
        """
        snap = Snapshot(
            snapshot_id=self._next_id(),
            timestamp=self._timestamp(),
            snapshot_type="ascii",
            content=content,
            metadata=metadata or {}
        )
        self._history.append(snap)
        return snap
    
    def capture_diagnostics(self, diag: dict, metadata: Optional[dict] = None) -> Snapshot:
        """Capture a diagnostics snapshot.
        
        Args:
            diag: Diagnostics dictionary
            metadata: Optional metadata
            
        Returns:
            Created snapshot
        """
        # Convert to text (free version)
        lines = [f"{k}: {v}" for k, v in diag.items()]
        content = "\n".join(lines)
        
        snap = Snapshot(
            snapshot_id=self._next_id(),
            timestamp=self._timestamp(),
            snapshot_type="diagnostics",
            content=content,
            metadata=metadata or {}
        )
        self._history.append(snap)
        return snap
    
    def save_snapshot(self, snap: Snapshot) -> Path:
        """Save snapshot to file.
        
        Args:
            snap: Snapshot to save
            
        Returns:
            Path to saved file
        """
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{snap.snapshot_type}_{ts}_{snap.snapshot_id}.txt"
        filepath = self.output_dir / filename
        
        filepath.write_text(snap.content, encoding="utf-8")
        return filepath
    
    def get_history(self, count: int = 10) -> List[Snapshot]:
        """Get recent snapshot history.
        
        Args:
            count: Number of snapshots to return
            
        Returns:
            List of recent snapshots
        """
        return self._history[-count:]
    
    def clear_history(self) -> None:
        """Clear snapshot history."""
        self._history.clear()

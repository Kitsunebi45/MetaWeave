"""Console Bootstrap Handler.

Handles the `init` command to display initial world state.
This is PRESENTATION ONLY - no simulation logic.

The bootstrap provides visual feedback immediately after plate load,
before the engine starts emitting events. This makes the console
feel alive and responsive.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class BootstrapState:
    """State produced by bootstrap initialization."""
    
    # Room display
    room_id: str = ""
    room_label: str = ""
    
    # ASCII view (list of lines)
    ascii_view: List[str] = field(default_factory=list)
    
    # Diagnostics
    diagnostics: Dict[str, Any] = field(default_factory=dict)
    
    # Console messages
    messages: List[str] = field(default_factory=list)
    
    # Active flag
    active: bool = False


class ConsoleBootstrap:
    """Handles console bootstrap/init flow.
    
    This provides immediate visual feedback when plate sets are loaded,
    before the engine begins emitting events.
    """
    
    def __init__(self):
        self.state = BootstrapState()
        self.loaded_plate_set: Optional[Dict[str, Any]] = None
        
        # Callbacks for UI updates
        self.on_room_update: Optional[Callable[[str, str], None]] = None
        self.on_ascii_update: Optional[Callable[[List[str]], None]] = None
        self.on_diagnostics_update: Optional[Callable[[Dict[str, Any]], None]] = None
        self.on_message: Optional[Callable[[str], None]] = None
    
    def set_plate_set(self, plate_set_info: Dict[str, Any]) -> None:
        """Store loaded plate set info for bootstrap.
        
        Args:
            plate_set_info: Plate set metadata (origin, plate IDs, etc.)
        """
        self.loaded_plate_set = plate_set_info
    
    def handle_command(self, cmd: str) -> bool:
        """Check if command is a bootstrap command and handle it.
        
        Args:
            cmd: User command text
            
        Returns:
            True if handled (don't forward to engine), False otherwise
        """
        cmd_lower = cmd.strip().lower()
        
        if cmd_lower == "init":
            self._bootstrap_world()
            return True
        
        return False
    
    def _bootstrap_world(self) -> None:
        """Initialize world display from loaded plates.
        
        This sets up visual state based on plate metadata.
        PLACEHOLDER VALUES - marked clearly in code.
        """
        if not self.loaded_plate_set:
            self._emit("[system] No plate set loaded. Load plates first.")
            return
        
        origin = self.loaded_plate_set.get("origin", "unknown")
        
        # Determine which bootstrap to use based on origin
        if "fairy_garden" in origin.lower():
            self._bootstrap_fairy_garden()
        else:
            self._bootstrap_generic(origin)
        
        self.state.active = True
    
    def _bootstrap_fairy_garden(self) -> None:
        """Bootstrap the Fairy Garden demo world.
        
        PLACEHOLDER VALUES - these are for initial display only.
        Real values come from engine events once connected.
        """
        # ROOM
        self.state.room_id = "fairy_garden_entrance"
        self.state.room_label = "Fairy Garden Entrance"
        
        if self.on_room_update:
            self.on_room_update(self.state.room_id, self.state.room_label)
        
        # ASCII VIEW (STATIC PLACEHOLDER)
        # These are display placeholders until engine provides real data
        self.state.ascii_view = [
            "╔═══════════════════════════════════════╗",
            "║       🌸 FAIRY GARDEN 🌸              ║",
            "╠═══════════════════════════════════════╣",
            "║                                       ║",
            "║   [ 🧚 ]───[   ]───[   ]───[ 👺 ]    ║",
            "║     │       │       │       │        ║",
            "║   [   ]   [   ]   [ * ]   [   ]      ║",
            "║     │       │       │       │        ║",
            "║   [   ]───[   ]───[   ]───[   ]      ║",
            "║                                       ║",
            "║   🧚 = Fairy   👺 = Goblin   * = You  ║",
            "║                                       ║",
            "╚═══════════════════════════════════════╝",
        ]
        
        if self.on_ascii_update:
            self.on_ascii_update(self.state.ascii_view)
        
        # DIAGNOSTICS (PLACEHOLDER VALUES)
        # These values are for display only until engine provides real data
        self.state.diagnostics = {
            "world": "fairy_garden_demo",
            "state": "initialized",
            "fairies": 6,          # PLACEHOLDER - from plate data
            "goblins": 0,          # PLACEHOLDER
            "rooms": 250,          # PLACEHOLDER - from plate data
            "mode": "observer",
            "tick": 0,
        }
        
        if self.on_diagnostics_update:
            self.on_diagnostics_update(self.state.diagnostics)
        
        # CONSOLE MESSAGES
        messages = [
            "",
            "════════════════════════════════════════",
            "[system] 🌸 The Fairy Garden awakens.",
            "════════════════════════════════════════",
            "",
            "You find yourself at the entrance to a magical garden.",
            "Six fairies tend to the flowers and paths.",
            "The air shimmers with possibility.",
            "",
            "Type 'look' to observe, or wait and watch.",
            "",
        ]
        
        self.state.messages = messages
        for msg in messages:
            self._emit(msg)
    
    def _bootstrap_generic(self, origin: str) -> None:
        """Bootstrap a generic world.
        
        Used when plate set origin doesn't match known demos.
        """
        # ROOM
        self.state.room_id = "start"
        self.state.room_label = f"World: {origin}"
        
        if self.on_room_update:
            self.on_room_update(self.state.room_id, self.state.room_label)
        
        # ASCII VIEW (GENERIC)
        self.state.ascii_view = [
            "╔═══════════════════════════════════╗",
            f"║  World: {origin[:25]:<25} ║",
            "╠═══════════════════════════════════╣",
            "║                                   ║",
            "║         [   ]───[   ]             ║",
            "║           │       │               ║",
            "║         [ * ]───[   ]             ║",
            "║                                   ║",
            "║         * = You                   ║",
            "║                                   ║",
            "╚═══════════════════════════════════╝",
        ]
        
        if self.on_ascii_update:
            self.on_ascii_update(self.state.ascii_view)
        
        # DIAGNOSTICS
        self.state.diagnostics = {
            "world": origin,
            "state": "initialized",
            "mode": "observer",
            "tick": 0,
        }
        
        if self.on_diagnostics_update:
            self.on_diagnostics_update(self.state.diagnostics)
        
        # MESSAGE
        self._emit(f"[system] World '{origin}' initialized.")
        self._emit("Type 'look' to observe.")
    
    def _emit(self, message: str) -> None:
        """Emit a message to console."""
        if self.on_message:
            self.on_message(message)
    
    def get_state(self) -> BootstrapState:
        """Get current bootstrap state."""
        return self.state
    
    def is_active(self) -> bool:
        """Check if bootstrap is active."""
        return self.state.active
    
    def reset(self) -> None:
        """Reset bootstrap state."""
        self.state = BootstrapState()
        self.loaded_plate_set = None

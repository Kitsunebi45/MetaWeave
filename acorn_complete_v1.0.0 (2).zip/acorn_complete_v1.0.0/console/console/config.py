"""Acorn Console Configuration."""

from dataclasses import dataclass


@dataclass(frozen=True)
class ConsoleConfig:
    """Console configuration (immutable)."""
    
    # Engine discovery
    discovery_enabled: bool = True
    discovery_interval_ms: int = 3000
    
    # Default engine connection
    default_engine_host: str = "127.0.0.1"
    default_engine_port: int = 7777
    
    # Inactivity → avatar continuity
    inactivity_minutes: int = 30
    quarantine_minutes: int = 60  # 1 hour
    
    # UI tick
    ui_refresh_ms: int = 250
    
    # Free version feature flags
    allow_plate_generation: bool = False
    allow_structured_export: bool = False
    allow_replay_logs: bool = False
    
    # IO Bridge paths (for file-based communication with engine)
    io_bridge_inbox: str = "./runtime/io/inbox"
    io_bridge_outbox: str = "./runtime/io/outbox"


CONFIG = ConsoleConfig()

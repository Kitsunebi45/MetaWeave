"""Acorn Console LLM Alphabet.

The Engine Alphabet - a minimal, structured language for LLM-engine communication.
Boring on purpose. Safe by construction.
"""

from dataclasses import dataclass, field
from typing import List, Literal, Optional


# Core type definitions
BuilderState = Literal["idle", "mull", "prop", "build"]
Zone = Literal["GREEN", "YELLOW", "RED"]
ResourceMode = Literal["ACTIVE", "DORMANT"]
CommandKind = Literal["MOVE", "SAY", "PROPOSE", "COMMIT", "WAIT", "ASK"]


@dataclass(frozen=True)
class AlphaState:
    """Structured state for LLM consumption.
    
    Represents the current room/environment state in a
    minimal, predictable format.
    """
    room_id: str
    human_present: bool
    tinkerbell_present: bool  # Fairy/agent presence
    resource_mode: ResourceMode
    zone: Zone
    
    def to_compact(self) -> str:
        """Convert to compact text representation."""
        return (
            f"R:{self.room_id} "
            f"H:{1 if self.human_present else 0} "
            f"T:{1 if self.tinkerbell_present else 0} "
            f"MODE:{self.resource_mode} "
            f"ZONE:{self.zone}"
        )


@dataclass(frozen=True)
class AlphaBuilder:
    """A builder entity in the environment."""
    builder_id: str
    state: BuilderState
    
    def to_compact(self) -> str:
        """Convert to compact text representation."""
        return f"B:{self.builder_id} S:{self.state}"


@dataclass(frozen=True)
class AlphaInput:
    """Complete input structure for LLM.
    
    Contains state, builders, events, and optional goal.
    This is what the LLM sees after translation.
    """
    state: AlphaState
    builders: tuple  # Tuple of AlphaBuilder
    events: tuple    # Tuple of event tags (strings)
    goal: Optional[str] = None
    
    def to_prompt(self) -> str:
        """Convert to prompt format for LLM."""
        lines = [self.state.to_compact()]
        
        for b in self.builders:
            lines.append(b.to_compact())
        
        for e in self.events:
            lines.append(f"EVT:{e}")
        
        if self.goal:
            lines.append(f"GOAL:{self.goal}")
        
        lines.append("")
        lines.append("OUTPUT: one command only from {MOVE:<dir>, SAY:<target>, PROPOSE:<id>, COMMIT:<id>, ASK:<id>, WAIT}")
        
        return "\n".join(lines)


@dataclass(frozen=True)
class AlphaCommand:
    """A validated command from LLM output.
    
    Commands are from a small, finite set:
    - MOVE: Move in a direction
    - SAY: Communicate with target
    - PROPOSE: Propose an action/plan
    - COMMIT: Commit to a proposal
    - WAIT: Do nothing this turn
    - ASK: Ask a question
    """
    kind: CommandKind
    arg: Optional[str] = None
    
    def to_engine_format(self) -> dict:
        """Convert to engine command format."""
        return {
            "command": self.kind,
            "argument": self.arg
        }
    
    def __str__(self) -> str:
        if self.arg:
            return f"{self.kind}:{self.arg}"
        return self.kind


# Command validation
VALID_COMMANDS = {"MOVE", "SAY", "PROPOSE", "COMMIT", "WAIT", "ASK"}

VALID_DIRECTIONS = {"N", "S", "E", "W", "NE", "NW", "SE", "SW", "UP", "DOWN"}


def validate_command(kind: str, arg: Optional[str]) -> tuple:
    """Validate a command.
    
    Args:
        kind: Command type
        arg: Command argument
        
    Returns:
        Tuple of (valid, message)
    """
    kind = kind.upper()
    
    if kind not in VALID_COMMANDS:
        return False, f"Unknown command: {kind}"
    
    if kind == "MOVE":
        if not arg:
            return False, "MOVE requires direction"
        if arg.upper() not in VALID_DIRECTIONS:
            return False, f"Invalid direction: {arg}"
    
    elif kind == "SAY":
        if not arg:
            return False, "SAY requires target"
    
    elif kind == "PROPOSE":
        if not arg:
            return False, "PROPOSE requires proposal ID"
    
    elif kind == "COMMIT":
        if not arg:
            return False, "COMMIT requires proposal ID"
    
    elif kind == "ASK":
        if not arg:
            return False, "ASK requires question ID or target"
    
    # WAIT needs no argument
    
    return True, "OK"

"""Acorn Console LLM Translator.

Bidirectional translation between engine snapshots and LLM alphabet.
This is the choke point for all LLM communication.
"""

from typing import Any, Dict, List, Optional, Tuple

from .alphabet import (
    AlphaState, AlphaBuilder, AlphaInput, AlphaCommand,
    validate_command, VALID_COMMANDS
)


class Translator:
    """Engine ↔ LLM choke point.
    
    - Converts engine snapshot → AlphaInput
    - Validates LLM output → AlphaCommand
    
    All LLM communication MUST go through this translator.
    No raw engine state leaks to LLM.
    No unvalidated LLM output goes to engine.
    """
    
    def engine_to_alpha(self, engine_snapshot: Dict[str, Any]) -> AlphaInput:
        """Convert engine snapshot to AlphaInput.
        
        Args:
            engine_snapshot: Raw engine state dictionary
            
        Returns:
            AlphaInput for LLM consumption
        """
        # Extract state information with safe defaults
        room_id = engine_snapshot.get("room_id", "UNKNOWN")
        zone = engine_snapshot.get("zone", "GREEN")
        
        # Validate zone
        if zone not in ("GREEN", "YELLOW", "RED"):
            zone = "GREEN"
        
        # Create state
        state = AlphaState(
            room_id=room_id,
            human_present=bool(engine_snapshot.get("human_present", True)),
            tinkerbell_present=bool(engine_snapshot.get("tinkerbell_present", False)),
            resource_mode=engine_snapshot.get("resource_mode", "ACTIVE"),
            zone=zone
        )
        
        # Extract builders
        builders = []
        for b in engine_snapshot.get("builders", []):
            builder_id = b.get("id", b.get("builder_id", "00"))
            builder_state = b.get("state", "idle")
            if builder_state not in ("idle", "mull", "prop", "build"):
                builder_state = "idle"
            builders.append(AlphaBuilder(
                builder_id=str(builder_id),
                state=builder_state
            ))
        
        # Extract events
        events = []
        for e in engine_snapshot.get("events", []):
            if isinstance(e, str):
                events.append(e)
            elif isinstance(e, dict):
                events.append(e.get("tag", str(e)))
        
        # Extract goal
        goal = engine_snapshot.get("goal")
        
        return AlphaInput(
            state=state,
            builders=tuple(builders),
            events=tuple(events),
            goal=goal
        )
    
    def alpha_to_prompt(self, alpha: AlphaInput) -> str:
        """Convert AlphaInput to prompt string.
        
        Args:
            alpha: AlphaInput structure
            
        Returns:
            Prompt string for LLM
        """
        return alpha.to_prompt()
    
    def parse_llm_output(self, text: str) -> Tuple[bool, str, Optional[AlphaCommand]]:
        """Parse and validate LLM output.
        
        Args:
            text: Raw LLM output text
            
        Returns:
            Tuple of (ok, message, command or None)
        """
        t = (text or "").strip()
        
        if not t:
            return False, "Empty output", None
        
        # Take only first line if multiline
        if "\n" in t:
            t = t.split("\n")[0].strip()
        
        # Normalize
        t = t.upper()
        
        # Handle simple WAIT
        if t == "WAIT":
            return True, "OK", AlphaCommand(kind="WAIT")
        
        # Parse COMMAND:ARG format
        if ":" in t:
            parts = t.split(":", 1)
            kind = parts[0].strip()
            arg = parts[1].strip() if len(parts) > 1 else None
            
            # Validate
            valid, msg = validate_command(kind, arg)
            if not valid:
                return False, msg, None
            
            return True, "OK", AlphaCommand(kind=kind, arg=arg)
        
        # Check if it's a bare command (no arg)
        if t in VALID_COMMANDS:
            valid, msg = validate_command(t, None)
            if valid:
                return True, "OK", AlphaCommand(kind=t)
            return False, msg, None
        
        return False, f"Invalid command format: {text}", None
    
    def command_to_engine(self, cmd: AlphaCommand) -> Dict[str, Any]:
        """Convert AlphaCommand to engine command format.
        
        Args:
            cmd: Validated AlphaCommand
            
        Returns:
            Engine command dictionary
        """
        return cmd.to_engine_format()


class SafeTranslator(Translator):
    """Translator with additional safety checks.
    
    Adds logging and rate limiting capabilities.
    """
    
    def __init__(self, max_commands_per_minute: int = 60):
        super().__init__()
        self._command_count = 0
        self._max_commands = max_commands_per_minute
        self._command_history: List[str] = []
    
    def parse_llm_output(self, text: str) -> Tuple[bool, str, Optional[AlphaCommand]]:
        """Parse with additional safety checks."""
        # Rate limiting
        if self._command_count >= self._max_commands:
            return False, "Rate limit exceeded", None
        
        ok, msg, cmd = super().parse_llm_output(text)
        
        if ok and cmd:
            self._command_count += 1
            self._command_history.append(str(cmd))
            
            # Keep history bounded
            if len(self._command_history) > 100:
                self._command_history = self._command_history[-100:]
        
        return ok, msg, cmd
    
    def reset_rate_limit(self) -> None:
        """Reset the rate limit counter."""
        self._command_count = 0
    
    def get_command_history(self) -> List[str]:
        """Get recent command history."""
        return list(self._command_history)

"""Acorn Console LLM Adapter Base.

Abstract base class for LLM adapters.
"""

from abc import ABC, abstractmethod
from typing import Tuple, Optional


class LLMAdapter(ABC):
    """Abstract base class for LLM adapters.
    
    Implement this to connect different LLM backends.
    """
    
    @abstractmethod
    def generate(self, prompt: str) -> Tuple[bool, str]:
        """Generate a response from the LLM.
        
        Args:
            prompt: Input prompt
            
        Returns:
            Tuple of (success, output_text)
        """
        raise NotImplementedError
    
    @abstractmethod
    def is_available(self) -> bool:
        """Check if the LLM backend is available.
        
        Returns:
            True if the backend is ready
        """
        raise NotImplementedError
    
    def get_model_info(self) -> dict:
        """Get information about the model.
        
        Returns:
            Dictionary with model information
        """
        return {
            "name": "unknown",
            "version": "unknown",
            "available": self.is_available()
        }


class NullAdapter(LLMAdapter):
    """Null adapter that does nothing.
    
    Useful for testing or when no LLM is available.
    """
    
    def generate(self, prompt: str) -> Tuple[bool, str]:
        """Always returns WAIT."""
        return True, "WAIT"
    
    def is_available(self) -> bool:
        """Always available."""
        return True
    
    def get_model_info(self) -> dict:
        return {
            "name": "null",
            "version": "1.0.0",
            "available": True,
            "description": "Null adapter (always returns WAIT)"
        }

"""Acorn Console Llama Adapter.

Adapter for local Llama models.
"""

from typing import Tuple, Optional
import os

from .adapter_base import LLMAdapter


class LlamaAdapter(LLMAdapter):
    """Adapter for local Llama models.
    
    Supports:
    - llama.cpp server (HTTP API)
    - llama-cpp-python binding
    - Ollama API
    """
    
    def __init__(
        self,
        mode: str = "http",
        host: str = "127.0.0.1",
        port: int = 8080,
        model_path: Optional[str] = None
    ):
        """Initialize Llama adapter.
        
        Args:
            mode: "http" for llama.cpp server, "binding" for direct, "ollama" for Ollama
            host: Server host for HTTP mode
            port: Server port for HTTP mode
            model_path: Path to model for binding mode
        """
        self.mode = mode
        self.host = host
        self.port = port
        self.model_path = model_path
        
        self._model = None
        self._available = False
        
        # Try to initialize
        self._init_backend()
    
    def _init_backend(self) -> None:
        """Initialize the backend."""
        if self.mode == "http":
            # Just check if server is available
            self._available = self._check_http_server()
        
        elif self.mode == "binding":
            # Try to load model via llama-cpp-python
            try:
                from llama_cpp import Llama
                if self.model_path and os.path.exists(self.model_path):
                    self._model = Llama(model_path=self.model_path)
                    self._available = True
            except ImportError:
                self._available = False
        
        elif self.mode == "ollama":
            # Check Ollama availability
            self._available = self._check_ollama()
    
    def _check_http_server(self) -> bool:
        """Check if llama.cpp HTTP server is available."""
        try:
            import urllib.request
            url = f"http://{self.host}:{self.port}/health"
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=2) as resp:
                return resp.status == 200
        except Exception:
            return False
    
    def _check_ollama(self) -> bool:
        """Check if Ollama is available."""
        try:
            import urllib.request
            url = f"http://{self.host}:11434/api/tags"
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=2) as resp:
                return resp.status == 200
        except Exception:
            return False
    
    def generate(self, prompt: str) -> Tuple[bool, str]:
        """Generate response from Llama model.
        
        Args:
            prompt: Input prompt
            
        Returns:
            Tuple of (success, output_text)
        """
        if not self._available:
            # Fallback: return WAIT
            return True, "WAIT"
        
        try:
            if self.mode == "http":
                return self._generate_http(prompt)
            elif self.mode == "binding":
                return self._generate_binding(prompt)
            elif self.mode == "ollama":
                return self._generate_ollama(prompt)
        except Exception as e:
            return False, f"Generation error: {e}"
        
        return True, "WAIT"
    
    def _generate_http(self, prompt: str) -> Tuple[bool, str]:
        """Generate via llama.cpp HTTP API."""
        import urllib.request
        import json
        
        url = f"http://{self.host}:{self.port}/completion"
        data = json.dumps({
            "prompt": prompt,
            "n_predict": 32,
            "temperature": 0.1,
            "stop": ["\n", "OUTPUT:"]
        }).encode("utf-8")
        
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            content = result.get("content", "WAIT").strip()
            return True, content
    
    def _generate_binding(self, prompt: str) -> Tuple[bool, str]:
        """Generate via llama-cpp-python binding."""
        if not self._model:
            return True, "WAIT"
        
        output = self._model(
            prompt,
            max_tokens=32,
            temperature=0.1,
            stop=["\n"]
        )
        
        content = output.get("choices", [{}])[0].get("text", "WAIT").strip()
        return True, content
    
    def _generate_ollama(self, prompt: str) -> Tuple[bool, str]:
        """Generate via Ollama API."""
        import urllib.request
        import json
        
        url = f"http://{self.host}:11434/api/generate"
        data = json.dumps({
            "model": "llama3.2",  # or configured model
            "prompt": prompt,
            "stream": False,
            "options": {
                "num_predict": 32,
                "temperature": 0.1
            }
        }).encode("utf-8")
        
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            content = result.get("response", "WAIT").strip()
            return True, content
    
    def is_available(self) -> bool:
        """Check if Llama backend is available."""
        return self._available
    
    def get_model_info(self) -> dict:
        """Get model information."""
        return {
            "name": "llama",
            "mode": self.mode,
            "host": self.host,
            "port": self.port,
            "model_path": self.model_path,
            "available": self._available
        }

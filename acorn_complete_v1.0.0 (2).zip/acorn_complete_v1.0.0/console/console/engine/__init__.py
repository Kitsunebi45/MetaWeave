"""Acorn Console Engine Module.

Handles engine discovery, connection, and communication.
"""

from .discovery import discover_engines
from .connector import EngineConnector, EngineConnectionInfo
from .protocol import EngineProtocol
from .socket_handler import SocketHandler, SocketConfig, DEFAULT_PORT
from .models import EngineSnapshot, EngineCommand

__all__ = [
    'discover_engines',
    'EngineConnector',
    'EngineConnectionInfo',
    'EngineProtocol',
    'SocketHandler',
    'SocketConfig',
    'DEFAULT_PORT',
    'EngineSnapshot',
    'EngineCommand'
]

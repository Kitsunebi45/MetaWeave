"""Acorn Console Engine Protocol.

Handles encoding/decoding of messages to/from the engine.
Supports both file-based IO bridge and socket protocols.
"""

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class Packet:
    """A packet for engine communication."""
    packet_id: str
    packet_type: str
    timestamp: str
    payload: Dict[str, Any]
    
    def to_json(self) -> str:
        """Serialize to JSON."""
        return json.dumps({
            "packet_id": self.packet_id,
            "type": self.packet_type,
            "timestamp": self.timestamp,
            "payload": self.payload
        }, indent=2)
    
    @classmethod
    def from_json(cls, data: str) -> "Packet":
        """Deserialize from JSON."""
        d = json.loads(data)
        return cls(
            packet_id=d.get("packet_id", ""),
            packet_type=d.get("type", ""),
            timestamp=d.get("timestamp", ""),
            payload=d.get("payload", {})
        )


class EngineProtocol:
    """Protocol handler for engine communication."""
    
    # Packet types
    TYPE_USER_TEXT = "user_text"
    TYPE_COMMAND = "command"
    TYPE_PLATE_LOAD = "plate_load"
    TYPE_STATE_REQUEST = "state_request"
    TYPE_STATE_RESPONSE = "state_response"
    TYPE_AVATAR_PRESENCE = "avatar_presence"
    TYPE_ERROR = "error"
    TYPE_ACK = "ack"
    
    @staticmethod
    def create_packet(packet_type: str, payload: Dict[str, Any]) -> Packet:
        """Create a new packet."""
        return Packet(
            packet_id=str(uuid.uuid4()),
            packet_type=packet_type,
            timestamp=datetime.now(timezone.utc).isoformat(),
            payload=payload
        )
    
    @classmethod
    def create_user_text_packet(cls, text: str) -> Packet:
        """Create packet for user text input."""
        return cls.create_packet(cls.TYPE_USER_TEXT, {
            "text": text
        })
    
    @classmethod
    def create_command_packet(cls, command: str, args: Dict[str, Any] = None) -> Packet:
        """Create packet for engine command."""
        return cls.create_packet(cls.TYPE_COMMAND, {
            "command": command,
            "args": args or {}
        })
    
    @classmethod
    def create_plate_load_packet(cls, plate_data: bytes, meta: Dict[str, Any]) -> Packet:
        """Create packet for plate loading."""
        import base64
        return cls.create_packet(cls.TYPE_PLATE_LOAD, {
            "data_b64": base64.b64encode(plate_data).decode("ascii"),
            "meta": meta
        })
    
    @classmethod
    def create_state_request_packet(cls) -> Packet:
        """Create packet to request engine state."""
        return cls.create_packet(cls.TYPE_STATE_REQUEST, {})
    
    @classmethod
    def create_avatar_presence_packet(cls, active: bool, drip_resources: bool = True) -> Packet:
        """Create packet for avatar mode presence."""
        return cls.create_packet(cls.TYPE_AVATAR_PRESENCE, {
            "active": active,
            "drip_resources": drip_resources
        })


class FileProtocolHandler:
    """Handler for file-based IO bridge protocol."""
    
    def __init__(self, io_path: Path):
        """Initialize with IO bridge path.
        
        Args:
            io_path: Path to IO bridge directory containing inbox/ and outbox/
        """
        self.io_path = Path(io_path)
        self.inbox = self.io_path / "inbox"
        self.outbox = self.io_path / "outbox"
        
        # Ensure directories exist
        self.inbox.mkdir(parents=True, exist_ok=True)
        self.outbox.mkdir(parents=True, exist_ok=True)
        
        # Track processed packets to avoid re-reading
        self._processed: set = set()
    
    def send(self, packet: Packet) -> bool:
        """Send packet to engine via inbox.
        
        Args:
            packet: Packet to send
            
        Returns:
            True if written successfully
        """
        try:
            filename = f"{packet.timestamp.replace(':', '-')}_{packet.packet_id[:8]}.json"
            filepath = self.inbox / filename
            filepath.write_text(packet.to_json(), encoding="utf-8")
            return True
        except Exception:
            return False
    
    def receive(self) -> List[Packet]:
        """Receive packets from engine via outbox.
        
        Returns:
            List of new packets
        """
        packets = []
        
        try:
            for filepath in sorted(self.outbox.glob("*.json")):
                if filepath.name in self._processed:
                    continue
                
                try:
                    content = filepath.read_text(encoding="utf-8")
                    packet = Packet.from_json(content)
                    packets.append(packet)
                    self._processed.add(filepath.name)
                    
                    # Optionally delete processed file
                    # filepath.unlink()
                except Exception:
                    continue
        except Exception:
            pass
        
        return packets
    
    def clear_processed(self) -> None:
        """Clear the processed packets set."""
        self._processed.clear()

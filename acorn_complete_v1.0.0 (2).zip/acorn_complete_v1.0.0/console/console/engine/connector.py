"""Acorn Console Engine Connector.

Manages connection to Acorn Engine instances.
Supports both file-based IO bridge and real TCP sockets.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from .discovery import parse_engine_id
from .protocol import EngineProtocol, FileProtocolHandler, Packet
from .socket_handler import SocketHandler, SocketConfig
from .models import EngineSnapshot


@dataclass
class EngineConnectionInfo:
    """Information about an engine connection."""
    engine_id: str
    mode: str  # "file" or "socket"
    host: str = ""
    port: int = 0
    path: str = ""


class EngineConnector:
    """Connector for communicating with Acorn Engine.
    
    Supports two modes:
    - file: File-based IO bridge (for testing/debugging)
    - socket: Real TCP socket connection (production)
    """
    
    def __init__(self):
        self.conn: Optional[EngineConnectionInfo] = None
        self._file_handler: Optional[FileProtocolHandler] = None
        self._socket_handler: Optional[SocketHandler] = None
        self._latest_snapshot: Optional[EngineSnapshot] = None
    
    def connect(self, engine_id: str) -> Tuple[bool, str]:
        """Connect to an engine.
        
        Args:
            engine_id: Engine identifier (e.g., "local-engine@127.0.0.1:17778" or "local@/path/to/io")
            
        Returns:
            Tuple of (success, message)
        """
        try:
            parsed = parse_engine_id(engine_id)
            mode = parsed["mode"]
            
            if mode == "file":
                # File-based IO bridge
                io_path = Path(parsed["path"])
                if not io_path.exists():
                    return False, f"IO path not found: {io_path}"
                
                self._file_handler = FileProtocolHandler(io_path)
                self.conn = EngineConnectionInfo(
                    engine_id=engine_id,
                    mode="file",
                    path=str(io_path)
                )
                return True, "Connected via file IO bridge"
            
            elif mode == "socket":
                # Real TCP socket connection
                host = parsed["host"]
                port = parsed["port"]
                
                self._socket_handler = SocketHandler(SocketConfig(
                    host=host,
                    port=port
                ))
                
                if self._socket_handler.connect(host, port):
                    self.conn = EngineConnectionInfo(
                        engine_id=engine_id,
                        mode="socket",
                        host=host,
                        port=port
                    )
                    return True, f"Connected to {host}:{port}"
                else:
                    self._socket_handler = None
                    return False, f"Failed to connect to {host}:{port}"
            
            else:
                return False, f"Unknown connection mode: {mode}"
            
        except Exception as e:
            self.conn = None
            self._file_handler = None
            self._socket_handler = None
            return False, f"Connection failed: {e}"
    
    def disconnect(self) -> None:
        """Disconnect from the engine."""
        if self._socket_handler:
            self._socket_handler.disconnect()
            self._socket_handler = None
        
        self.conn = None
        self._file_handler = None
        self._latest_snapshot = None
    
    def is_connected(self) -> bool:
        """Check if connected to an engine."""
        if self.conn is None:
            return False
        
        if self.conn.mode == "socket" and self._socket_handler:
            return self._socket_handler.is_connected()
        
        return self.conn is not None
    
    def send_user_text(self, text: str) -> Tuple[bool, str]:
        """Send user text input to engine.
        
        Args:
            text: User input text
            
        Returns:
            Tuple of (success, message)
        """
        if not self.conn:
            return False, "Not connected"
        
        packet = EngineProtocol.create_user_text_packet(text)
        return self._send_packet(packet)
    
    def send_command(self, command: str, args: Dict[str, Any] = None) -> Tuple[bool, str]:
        """Send a command to the engine.
        
        Args:
            command: Command string
            args: Command arguments
            
        Returns:
            Tuple of (success, message)
        """
        if not self.conn:
            return False, "Not connected"
        
        packet = EngineProtocol.create_command_packet(command, args)
        return self._send_packet(packet)
    
    def load_plate(self, plate_bytes: bytes, meta: Dict[str, Any]) -> Tuple[bool, str]:
        """Load a plate into the engine.
        
        Args:
            plate_bytes: Raw plate data
            meta: Plate metadata
            
        Returns:
            Tuple of (success, message)
        """
        if not self.conn:
            return False, "Not connected"
        
        packet = EngineProtocol.create_plate_load_packet(plate_bytes, meta)
        return self._send_packet(packet)
    
    def send_avatar_presence(self, active: bool) -> Tuple[bool, str]:
        """Send avatar presence notification.
        
        Args:
            active: Whether avatar mode is active
            
        Returns:
            Tuple of (success, message)
        """
        if not self.conn:
            return False, "Not connected"
        
        packet = EngineProtocol.create_avatar_presence_packet(active)
        return self._send_packet(packet)
    
    def poll_state(self) -> Optional[Dict[str, Any]]:
        """Poll for any pending state from engine.
        
        NOTE: This is RECEIVE-ONLY. Does not send state_request.
        Console operates in reactive mode - only processes messages
        that the engine sends unprompted.
        
        Returns:
            State dictionary or None if no new state
        """
        if not self.conn:
            return None
        
        # RECEIVE ONLY - check for any pending packets from engine
        packets = self._receive_packets()
        
        state = None
        for packet in packets:
            # Return the full packet data including type
            state = {
                "type": packet.packet_type,
                **packet.payload
            }
        
        return state
    
    def _send_packet(self, packet: Packet) -> Tuple[bool, str]:
        """Send a packet to the engine."""
        if self.conn.mode == "file" and self._file_handler:
            if self._file_handler.send(packet):
                return True, "Sent"
            return False, "Failed to write packet"
        
        elif self.conn.mode == "socket" and self._socket_handler:
            if self._socket_handler.send(packet):
                return True, "Sent"
            return False, "Failed to send packet"
        
        return False, "Unknown connection mode"
    
    def _receive_packets(self) -> list:
        """Receive packets from the engine."""
        if self.conn.mode == "file" and self._file_handler:
            return self._file_handler.receive()
        
        elif self.conn.mode == "socket" and self._socket_handler:
            return self._socket_handler.receive()
        
        return []

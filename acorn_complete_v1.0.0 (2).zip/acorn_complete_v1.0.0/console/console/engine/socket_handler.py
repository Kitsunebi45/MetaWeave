"""Acorn Console Socket Handler.

Real TCP socket connection to Acorn Engine.
JSON line protocol (newline-delimited JSON).
"""

import json
import socket
import threading
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional
from queue import Queue, Empty

from .protocol import Packet, EngineProtocol


# Default engine port
DEFAULT_PORT = 17778


@dataclass
class SocketConfig:
    """Socket connection configuration."""
    host: str = "127.0.0.1"
    port: int = DEFAULT_PORT
    timeout_connect: float = 2.0
    timeout_recv: float = 0.1
    buffer_size: int = 4096


class SocketHandler:
    """Handles TCP socket connection to Acorn Engine.
    
    Protocol:
    - JSON line protocol (newline-delimited)
    - Each message is a JSON object followed by newline
    - Messages are Packet objects serialized to JSON
    """
    
    def __init__(self, config: Optional[SocketConfig] = None):
        self.config = config or SocketConfig()
        self.sock: Optional[socket.socket] = None
        self._connected = False
        self._recv_buffer = b""
        
        # Receive queue for async messages
        self._recv_queue: Queue[Dict[str, Any]] = Queue()
        
        # Receive thread
        self._recv_thread: Optional[threading.Thread] = None
        self._running = False
        
        # Callbacks
        self.on_message: Optional[Callable[[Dict[str, Any]], None]] = None
        self.on_disconnect: Optional[Callable[[], None]] = None
    
    def connect(self, host: str = None, port: int = None) -> bool:
        """Connect to engine.
        
        Args:
            host: Override host (default from config)
            port: Override port (default from config)
            
        Returns:
            True if connected successfully
        """
        host = host or self.config.host
        port = port or self.config.port
        
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(self.config.timeout_connect)
            self.sock.connect((host, port))
            self.sock.settimeout(self.config.timeout_recv)
            
            self._connected = True
            self._recv_buffer = b""
            
            # Send handshake
            self._send_handshake()
            
            # Start receive thread
            self._running = True
            self._recv_thread = threading.Thread(target=self._recv_loop, daemon=True)
            self._recv_thread.start()
            
            return True
            
        except socket.timeout:
            self._cleanup()
            return False
        except ConnectionRefusedError:
            self._cleanup()
            return False
        except Exception:
            self._cleanup()
            return False
    
    def disconnect(self) -> None:
        """Disconnect from engine."""
        self._running = False
        self._cleanup()
    
    def is_connected(self) -> bool:
        """Check if connected."""
        return self._connected
    
    def send(self, packet: Packet) -> bool:
        """Send a packet to the engine.
        
        Args:
            packet: Packet to send
            
        Returns:
            True if sent successfully
        """
        if not self._connected or not self.sock:
            return False
        
        try:
            message = {
                "packet_id": packet.packet_id,
                "type": packet.packet_type,
                "payload": packet.payload,
                "timestamp": packet.timestamp
            }
            data = json.dumps(message).encode("utf-8") + b"\n"
            self.sock.sendall(data)
            return True
        except Exception:
            self._handle_disconnect()
            return False
    
    def send_raw(self, message: Dict[str, Any]) -> bool:
        """Send a raw message dictionary.
        
        Args:
            message: Message dictionary
            
        Returns:
            True if sent successfully
        """
        if not self._connected or not self.sock:
            return False
        
        try:
            data = json.dumps(message).encode("utf-8") + b"\n"
            self.sock.sendall(data)
            return True
        except Exception:
            self._handle_disconnect()
            return False
    
    def receive(self) -> List[Packet]:
        """Receive any pending packets (non-blocking).
        
        Returns:
            List of received packets
        """
        packets = []
        while True:
            try:
                msg = self._recv_queue.get_nowait()
                
                # If message has explicit "payload" field, use it
                # Otherwise, treat the whole message (minus type/id/timestamp) as payload
                if "payload" in msg:
                    payload = msg.get("payload", {})
                else:
                    # Engine sends flat messages - preserve all data
                    payload = {k: v for k, v in msg.items() 
                               if k not in ("type", "packet_id", "timestamp")}
                
                packet = Packet(
                    packet_id=msg.get("packet_id", ""),
                    packet_type=msg.get("type", "unknown"),
                    timestamp=msg.get("timestamp", ""),
                    payload=payload
                )
                packets.append(packet)
            except Empty:
                break
        return packets
    
    def _send_handshake(self) -> None:
        """Send initial handshake to engine."""
        handshake = {
            "type": "hello",
            "client": "acorn_console",
            "version": "0.1.0",
            "protocol": "json_line_v1"
        }
        self.send_raw(handshake)
    
    def _recv_loop(self) -> None:
        """Background receive loop."""
        while self._running and self._connected:
            try:
                data = self.sock.recv(self.config.buffer_size)
                if not data:
                    # Connection closed
                    self._handle_disconnect()
                    break
                
                self._recv_buffer += data
                self._process_buffer()
                
            except socket.timeout:
                # Normal timeout, continue
                continue
            except Exception:
                self._handle_disconnect()
                break
    
    def _process_buffer(self) -> None:
        """Process receive buffer for complete messages."""
        while b"\n" in self._recv_buffer:
            line, self._recv_buffer = self._recv_buffer.split(b"\n", 1)
            if not line:
                continue
            
            try:
                message = json.loads(line.decode("utf-8"))
                self._recv_queue.put(message)
                
                if self.on_message:
                    self.on_message(message)
                    
            except json.JSONDecodeError:
                # Invalid JSON, skip
                pass
    
    def _handle_disconnect(self) -> None:
        """Handle unexpected disconnect."""
        was_connected = self._connected
        self._cleanup()
        
        if was_connected and self.on_disconnect:
            self.on_disconnect()
    
    def _cleanup(self) -> None:
        """Clean up connection resources."""
        self._connected = False
        self._running = False
        
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
            self.sock = None
        
        self._recv_buffer = b""

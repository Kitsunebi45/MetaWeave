"""Acorn Console Engine Events.

Event types and handlers for engine communication.
"""

from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional
from enum import Enum


class EventType(Enum):
    """Types of events from the engine."""
    
    # Connection events
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    CONNECTION_ERROR = "connection_error"
    
    # State events
    STATE_UPDATE = "state_update"
    TICK = "tick"
    
    # Zone events
    ZONE_CHANGE = "zone_change"
    QUARANTINE_START = "quarantine_start"
    QUARANTINE_END = "quarantine_end"
    
    # Scenario events
    SCENARIO_START = "scenario_start"
    SCENARIO_STOP = "scenario_stop"
    
    # Learning events
    TEACHING_APPLIED = "teaching_applied"
    SKILL_CHANGED = "skill_changed"
    
    # Entity events
    ENTITY_MOVED = "entity_moved"
    ENTITY_ACTION = "entity_action"
    
    # System events
    ENGINE_ERROR = "engine_error"
    PLATE_LOADED = "plate_loaded"
    PLATE_ERROR = "plate_error"


@dataclass
class EngineEvent:
    """An event from the engine."""
    event_type: EventType
    data: Dict[str, Any]
    timestamp: str = ""
    
    @classmethod
    def from_packet(cls, packet) -> Optional["EngineEvent"]:
        """Create event from a packet payload."""
        payload = packet.payload
        event_type_str = payload.get("event_type")
        
        if not event_type_str:
            return None
        
        try:
            event_type = EventType(event_type_str)
        except ValueError:
            return None
        
        return cls(
            event_type=event_type,
            data=payload.get("data", {}),
            timestamp=packet.timestamp
        )


class EventDispatcher:
    """Dispatches events to registered handlers."""
    
    def __init__(self):
        self._handlers: Dict[EventType, List[Callable[[EngineEvent], None]]] = {}
    
    def register(self, event_type: EventType, handler: Callable[[EngineEvent], None]) -> None:
        """Register a handler for an event type.
        
        Args:
            event_type: Type of event to handle
            handler: Callback function
        """
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)
    
    def unregister(self, event_type: EventType, handler: Callable[[EngineEvent], None]) -> None:
        """Unregister a handler.
        
        Args:
            event_type: Type of event
            handler: Callback function to remove
        """
        if event_type in self._handlers:
            try:
                self._handlers[event_type].remove(handler)
            except ValueError:
                pass
    
    def dispatch(self, event: EngineEvent) -> None:
        """Dispatch an event to all registered handlers.
        
        Args:
            event: Event to dispatch
        """
        handlers = self._handlers.get(event.event_type, [])
        for handler in handlers:
            try:
                handler(event)
            except Exception:
                # Log but don't propagate handler errors
                pass
    
    def clear(self) -> None:
        """Clear all handlers."""
        self._handlers.clear()

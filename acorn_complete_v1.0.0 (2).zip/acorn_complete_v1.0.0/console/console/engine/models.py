"""Acorn Console Engine Models.

Data structures for engine communication.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Literal


Zone = Literal["GREEN", "YELLOW", "RED"]


@dataclass
class EngineSnapshot:
    """Snapshot of engine state received from polling."""
    
    # Core state
    tick: int = 0
    running: bool = False
    scenario_id: Optional[str] = None
    
    # World state
    room_id: str = "UNKNOWN"
    regions: List[str] = field(default_factory=list)
    
    # Zone status
    zone: Zone = "GREEN"
    zone_reason: str = ""
    
    # Quarantine
    quarantine_active: bool = False
    quarantine_room: str = ""
    
    # Learning summary
    entities: List[str] = field(default_factory=list)
    learning_summary: Dict[str, Any] = field(default_factory=dict)
    
    # Visual data
    minimap_ascii: str = ""
    primitives: List[Dict[str, Any]] = field(default_factory=list)
    
    # Raw diagnostics
    diagnostics: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EngineSnapshot":
        """Create snapshot from dictionary."""
        diag = data.get("diagnostics", {})
        visual = data.get("visual", {})
        
        return cls(
            tick=diag.get("tick", 0),
            running=diag.get("running", False),
            scenario_id=diag.get("scenario_id"),
            room_id=visual.get("room_id", diag.get("room_id", "UNKNOWN")),
            regions=diag.get("regions", []),
            zone=diag.get("zone", "GREEN"),
            zone_reason=diag.get("zone_reason", ""),
            quarantine_active=diag.get("quarantine_active", False),
            quarantine_room=diag.get("quarantine_room", ""),
            entities=diag.get("entities", []),
            learning_summary=diag.get("learning_summary", {}),
            minimap_ascii=visual.get("minimap_ascii", ""),
            primitives=visual.get("primitives", []),
            diagnostics=diag
        )


@dataclass
class EngineCommand:
    """Command to send to engine."""
    
    command_type: str  # "text", "teach", "scenario", etc.
    payload: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "type": self.command_type,
            "payload": self.payload
        }

"""Acorn Console Engine Discovery.

Discovers running Acorn Engine instances via:
- Local IO bridge directory scanning
- Known localhost ports (listed without connection test)
- Environment variables

NOTE: We do NOT test ports by connecting - that would interfere
with the persistent console connection and cause connect/disconnect spam.
"""

from pathlib import Path
from typing import List
import os


# Default engine port
DEFAULT_ENGINE_PORT = 17778


def discover_engines() -> List[str]:
    """Discover available Acorn Engine instances.
    
    NOTE: This does NOT test connectivity by opening sockets.
    Port testing would cause connection spam and interfere
    with the persistent console connection.
    
    Returns:
        List of engine identifiers in format "name@host:port" or "name@path"
    """
    engines = []
    
    # Method 1: Check for local IO bridge directories
    io_paths = [
        Path("./runtime/io"),
        Path("../acorn-engine/runtime/io"),
        Path.home() / ".acorn" / "runtime" / "io",
    ]
    
    for io_path in io_paths:
        if io_path.exists() and (io_path / "inbox").exists():
            engine_id = f"local-file@{io_path}"
            if engine_id not in engines:
                engines.append(engine_id)
    
    # Method 2: Check for engine identity file
    identity_paths = [
        Path("./engine_data/engine.uuid"),
        Path("../acorn-engine/engine_data/engine.uuid"),
    ]
    
    for id_path in identity_paths:
        if id_path.exists():
            try:
                uuid = id_path.read_text().strip()
                parent = id_path.parent.parent
                io_dir = parent / "runtime" / "io"
                if io_dir.exists():
                    engine_id = f"local-{uuid[:8]}@{io_dir}"
                    if engine_id not in engines:
                        engines.append(engine_id)
            except Exception:
                pass
    
    # Method 3: Add default localhost port (always available as option)
    # We do NOT test connectivity - user clicks Connect to test
    default_id = f"acorn-engine@127.0.0.1:{DEFAULT_ENGINE_PORT}"
    if default_id not in engines:
        engines.append(default_id)
    
    # Method 4: Check environment variable
    env_engine = os.environ.get("ACORN_ENGINE_ADDRESS")
    if env_engine and env_engine not in engines:
        engines.append(env_engine)
    
    return engines


def parse_engine_id(engine_id: str) -> dict:
    """Parse engine identifier into components.
    
    Args:
        engine_id: Format "name@host:port" or "name@path"
        
    Returns:
        Dictionary with 'name', 'host', 'port', 'path' as applicable
    """
    result = {"name": "", "host": "", "port": 0, "path": "", "mode": "unknown"}
    
    if "@" not in engine_id:
        result["name"] = engine_id
        return result
    
    name, addr = engine_id.split("@", 1)
    result["name"] = name
    
    # Check if it's a path (contains / or \)
    if "/" in addr or "\\" in addr:
        result["path"] = addr
        result["mode"] = "file"
    elif ":" in addr:
        host, port_str = addr.rsplit(":", 1)
        result["host"] = host
        try:
            result["port"] = int(port_str)
            result["mode"] = "socket"
        except ValueError:
            result["path"] = addr
            result["mode"] = "file"
    else:
        result["host"] = addr
        result["mode"] = "socket"
    
    return result

"""Acorn Console Main Window."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from console.config import CONFIG
from console.runtime.session import SessionController
from console.runtime.printing import PrintManager
from console.ui.widgets import TextConsole, DiagnosticsPanel, VisualizationPanel, TopBar
from console.ui.styles import apply_styles


class MainWindow:
    """Main console window with text, visualization, and diagnostics panels."""
    
    def __init__(self, session: SessionController):
        self.session = session
        self.root = tk.Tk()
        self.root.title("Acorn Console (Free)")
        self.root.geometry("1200x800")
        
        # Apply styles
        apply_styles(self.root)
        
        self.print_mgr = PrintManager(session=self.session)
        
        # Top bar
        self.top = TopBar(
            master=self.root,
            on_connect=self._on_connect,
            on_disconnect=self._on_disconnect,
            on_refresh_engines=self._on_refresh_engines,
            on_load_plate=self._on_load_plate,
            on_load_plate_set=self._on_load_plate_set,
            on_print_text=self._on_print_text,
            on_print_ascii=self._on_print_ascii,
            on_print_diag=self._on_print_diag,
        )
        self.top.pack(side=tk.TOP, fill=tk.X)
        
        # Body: left text; right split vis+diag
        self.body = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        self.body.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        self.text_console = TextConsole(
            master=self.body,
            on_send_command=self._on_send_command,
            on_user_activity=self._on_user_activity
        )
        self.body.add(self.text_console, weight=3)
        
        self.right = ttk.PanedWindow(self.body, orient=tk.VERTICAL)
        self.body.add(self.right, weight=2)
        
        self.vis_panel = VisualizationPanel(master=self.right)
        self.right.add(self.vis_panel, weight=3)
        
        self.diag_panel = DiagnosticsPanel(master=self.right)
        self.right.add(self.diag_panel, weight=2)
        
        # Periodic UI refresh
        self._schedule_refresh()
        
        # Wire session callbacks
        self.session.on_text_output = self.text_console.append_system
        self.session.on_state_update = self._on_state_update
        
        # Initial welcome message
        self.text_console.append_system("═" * 50)
        self.text_console.append_system("  Acorn Console (Free) v0.1.0")
        self.text_console.append_system("  Connected to Acorn Engine v12.19.0")
        self.text_console.append_system("═" * 50)
        self.text_console.append_system("")
        self.text_console.append_system("Click 'Refresh Engines' to discover running engines.")
        self.text_console.append_system("Or connect manually to localhost.")
        self.text_console.append_system("")
    
    def run(self) -> None:
        """Run the main event loop."""
        self.root.mainloop()
    
    # ---------- Top bar handlers ----------
    
    def _on_refresh_engines(self) -> None:
        """Refresh the list of available engines."""
        engines = self.session.refresh_engine_list()
        self.top.set_engines(engines)
    
    def _on_connect(self, engine_id: str) -> None:
        """Connect to the selected engine."""
        ok, msg = self.session.connect(engine_id)
        if not ok:
            messagebox.showerror("Connect Failed", msg)
    
    def _on_disconnect(self) -> None:
        """Disconnect from the current engine."""
        self.session.disconnect()
    
    def _on_load_plate(self) -> None:
        """Open file dialog to load a single plate (deprecated)."""
        path = filedialog.askopenfilename(
            title="Load Plate (Single File - Deprecated)",
            filetypes=[
                ("Plate files", "*.json *.plate *.acorn *.png"),
                ("JSON files", "*.json"),
                ("All files", "*.*")
            ]
        )
        if not path:
            return
        ok, msg = self.session.load_plate(path)
        if not ok:
            messagebox.showerror("Plate Load Failed", msg)
    
    def _on_load_plate_set(self) -> None:
        """Open folder dialog to load a complete plate set."""
        folder = filedialog.askdirectory(
            title="Select Plate Set Folder"
        )
        if not folder:
            return
        ok, msg = self.session.load_plate_set(folder)
        if not ok:
            messagebox.showerror("Plate Set Error", msg)
    
    # ---------- Print handlers ----------
    
    def _on_print_text(self) -> None:
        """Print text console contents to file."""
        self.print_mgr.print_text(self.text_console.get_full_text())
    
    def _on_print_ascii(self) -> None:
        """Print ASCII visualization to file."""
        self.print_mgr.print_ascii(self.vis_panel.get_ascii_snapshot())
    
    def _on_print_diag(self) -> None:
        """Print diagnostics to file."""
        self.print_mgr.print_diagnostics(self.session.get_diagnostics_snapshot())
    
    # ---------- Text/commands ----------
    
    def _on_send_command(self, text: str) -> None:
        """Handle user command input."""
        self.session.handle_user_input(text)
    
    def _on_user_activity(self) -> None:
        """Note user activity (for avatar mode tracking)."""
        self.session.note_user_activity()
    
    # ---------- UI refresh ----------
    
    def _schedule_refresh(self) -> None:
        """Schedule periodic UI refresh."""
        self.session.tick()  # drives timers, inactivity, etc.
        self._refresh_panels()
        self.root.after(CONFIG.ui_refresh_ms, self._schedule_refresh)
    
    def _refresh_panels(self) -> None:
        """Update diagnostics/vis from latest session state."""
        state = self.session.latest_state
        if state:
            self.diag_panel.update(state.diagnostics)
            self.vis_panel.update(state.visual)
        
        # Update engine list periodically - BUT NOT when connected
        # Discovery should only run when we need to find an engine
        if CONFIG.discovery_enabled and not self.session.connector.is_connected():
            if self.session.discovery_due():
                engines = self.session.refresh_engine_list()
                self.top.set_engines(engines)
    
    def _on_state_update(self) -> None:
        """Called when session receives new engine state."""
        # Could trigger immediate UI update if needed
        pass

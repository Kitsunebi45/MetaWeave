"""Acorn Console UI Widgets."""

import tkinter as tk
from tkinter import ttk
from typing import Callable, List, Optional, Any


class TopBar(ttk.Frame):
    """Top bar with engine controls, plate loading, and print buttons."""
    
    def __init__(
        self,
        master,
        on_connect: Callable[[str], None],
        on_disconnect: Callable[[], None],
        on_refresh_engines: Callable[[], None],
        on_load_plate: Callable[[], None],
        on_load_plate_set: Callable[[], None],
        on_print_text: Callable[[], None],
        on_print_ascii: Callable[[], None],
        on_print_diag: Callable[[], None],
    ):
        super().__init__(master)
        self.on_connect = on_connect
        self.on_disconnect = on_disconnect
        self.on_refresh_engines = on_refresh_engines
        self.on_load_plate = on_load_plate
        self.on_load_plate_set = on_load_plate_set
        self.on_print_text = on_print_text
        self.on_print_ascii = on_print_ascii
        self.on_print_diag = on_print_diag
        
        # Engine selection
        ttk.Label(self, text="Engine:").pack(side=tk.LEFT, padx=(6, 2), pady=6)
        
        self.engine_var = tk.StringVar(value="")
        self.engine_combo = ttk.Combobox(
            self, 
            textvariable=self.engine_var, 
            values=[], 
            width=40, 
            state="readonly"
        )
        self.engine_combo.pack(side=tk.LEFT, padx=2, pady=6)
        
        ttk.Button(self, text="⟳ Refresh", command=self.on_refresh_engines).pack(side=tk.LEFT, padx=4)
        ttk.Button(self, text="Connect", command=self._connect).pack(side=tk.LEFT, padx=2)
        ttk.Button(self, text="Disconnect", command=self.on_disconnect).pack(side=tk.LEFT, padx=2)
        
        # Separator
        ttk.Separator(self, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8, pady=4)
        
        # Plate loading - Primary: Plate Set, Secondary: Single Plate
        ttk.Button(self, text="📁 Load Plate Set", command=self.on_load_plate_set).pack(side=tk.LEFT, padx=4)
        ttk.Button(self, text="📄 Load Plate", command=self.on_load_plate).pack(side=tk.LEFT, padx=2)
        
        # Separator
        ttk.Separator(self, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8, pady=4)
        
        # Print buttons
        ttk.Button(self, text="🖨 Text", command=self.on_print_text).pack(side=tk.LEFT, padx=2)
        ttk.Button(self, text="🖨 ASCII", command=self.on_print_ascii).pack(side=tk.LEFT, padx=2)
        ttk.Button(self, text="🖨 Diag", command=self.on_print_diag).pack(side=tk.LEFT, padx=2)
        
        # Status indicator (right side)
        self.status_var = tk.StringVar(value="● Disconnected")
        self.status_label = ttk.Label(self, textvariable=self.status_var, foreground="gray")
        self.status_label.pack(side=tk.RIGHT, padx=10)
    
    def _connect(self) -> None:
        """Handle connect button click."""
        engine_id = self.engine_var.get().strip()
        if engine_id:
            self.on_connect(engine_id)
    
    def set_engines(self, engines: List[str]) -> None:
        """Update the engine dropdown list."""
        self.engine_combo["values"] = engines
        if engines and not self.engine_var.get():
            self.engine_var.set(engines[0])
    
    def set_connected(self, connected: bool, engine_id: str = "") -> None:
        """Update connection status display."""
        if connected:
            self.status_var.set(f"● Connected: {engine_id}")
            self.status_label.configure(foreground="green")
        else:
            self.status_var.set("● Disconnected")
            self.status_label.configure(foreground="gray")


class TextConsole(ttk.Frame):
    """Text console for user input and system output."""
    
    def __init__(
        self, 
        master, 
        on_send_command: Callable[[str], None], 
        on_user_activity: Callable[[], None]
    ):
        super().__init__(master)
        self.on_send_command = on_send_command
        self.on_user_activity = on_user_activity
        
        # Text display area
        self.text = tk.Text(
            self, 
            wrap=tk.WORD, 
            font=("Consolas", 10),
            background="#1e1e1e",
            foreground="#d4d4d4",
            insertbackground="white"
        )
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self.text.yview)
        self.text.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.text.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        # Input area
        bottom = ttk.Frame(self)
        bottom.pack(side=tk.BOTTOM, fill=tk.X)
        
        ttk.Label(bottom, text=">").pack(side=tk.LEFT, padx=(6, 2), pady=6)
        
        self.entry = ttk.Entry(bottom, font=("Consolas", 10))
        self.entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2, pady=6)
        self.entry.bind("<Return>", self._send)
        self.entry.bind("<Key>", lambda e: self.on_user_activity())
        
        ttk.Button(bottom, text="Send", command=self._send_btn).pack(side=tk.LEFT, padx=6, pady=6)
        
        # Text tags for coloring
        self.text.tag_configure("user", foreground="#569cd6")
        self.text.tag_configure("system", foreground="#d4d4d4")
        self.text.tag_configure("error", foreground="#f14c4c")
        self.text.tag_configure("success", foreground="#89d185")
    
    def _send_btn(self) -> None:
        """Handle send button click."""
        self._send(None)
    
    def _send(self, event) -> None:
        """Handle send action."""
        raw = self.entry.get().strip()
        if not raw:
            return
        self.entry.delete(0, tk.END)
        self.append_user(raw)
        self.on_send_command(raw)
        self.on_user_activity()
    
    def append_user(self, msg: str) -> None:
        """Append user input to the console."""
        self.text.insert(tk.END, f"\n> {msg}\n", "user")
        self.text.see(tk.END)
    
    def append_system(self, msg: str) -> None:
        """Append system output to the console."""
        self.text.insert(tk.END, f"{msg}\n", "system")
        self.text.see(tk.END)
    
    def append_error(self, msg: str) -> None:
        """Append error message to the console."""
        self.text.insert(tk.END, f"[ERROR] {msg}\n", "error")
        self.text.see(tk.END)
    
    def append_success(self, msg: str) -> None:
        """Append success message to the console."""
        self.text.insert(tk.END, f"[OK] {msg}\n", "success")
        self.text.see(tk.END)
    
    def get_full_text(self) -> str:
        """Get all text from the console."""
        return self.text.get("1.0", tk.END)


class VisualizationPanel(ttk.Frame):
    """Visualization panel with canvas and ASCII overlay."""
    
    def __init__(self, master):
        super().__init__(master)
        
        # Canvas for graphical primitives
        self.canvas = tk.Canvas(
            self, 
            background="#0a0a0a",
            highlightthickness=0
        )
        self.canvas.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        # Room label
        self.room_var = tk.StringVar(value="Room: (none)")
        room_label = ttk.Label(self, textvariable=self.room_var, font=("Consolas", 9))
        room_label.pack(side=tk.TOP, fill=tk.X, padx=4, pady=2)
        
        # ASCII map overlay
        self.ascii_text = tk.Text(
            self, 
            height=10, 
            wrap=tk.NONE,
            font=("Consolas", 8),
            background="#0f0f0f",
            foreground="#4ec9b0"
        )
        self.ascii_text.pack(side=tk.BOTTOM, fill=tk.X)
        
        self._last_ascii = ""
    
    def update(self, visual: Any) -> None:
        """Update visualization from visual state.
        
        Args:
            visual: VisualState with room_id, minimap_ascii, primitives
        """
        self.canvas.delete("all")
        
        # Update room label
        room_id = getattr(visual, "room_id", "UNKNOWN") if visual else "UNKNOWN"
        self.room_var.set(f"Room: {room_id}")
        
        # Draw primitives
        primitives = getattr(visual, "primitives", []) if visual else []
        for prim in (primitives or []):
            self._draw_primitive(prim)
        
        # Update ASCII map
        ascii_map = getattr(visual, "minimap_ascii", "") if visual else ""
        self._last_ascii = ascii_map or ""
        self.ascii_text.delete("1.0", tk.END)
        self.ascii_text.insert(tk.END, self._last_ascii)
    
    def _draw_primitive(self, prim: dict) -> None:
        """Draw a single primitive on the canvas."""
        t = prim.get("type")
        
        if t == "circle":
            x, y, r = prim.get("x", 0), prim.get("y", 0), prim.get("r", 5)
            color = prim.get("color", "white")
            self.canvas.create_oval(x-r, y-r, x+r, y+r, outline=color)
        
        elif t == "filled_circle":
            x, y, r = prim.get("x", 0), prim.get("y", 0), prim.get("r", 5)
            color = prim.get("color", "white")
            self.canvas.create_oval(x-r, y-r, x+r, y+r, fill=color, outline=color)
        
        elif t == "line":
            x1, y1 = prim.get("x1", 0), prim.get("y1", 0)
            x2, y2 = prim.get("x2", 0), prim.get("y2", 0)
            color = prim.get("color", "white")
            self.canvas.create_line(x1, y1, x2, y2, fill=color)
        
        elif t == "rect":
            x1, y1 = prim.get("x1", 0), prim.get("y1", 0)
            x2, y2 = prim.get("x2", 0), prim.get("y2", 0)
            color = prim.get("color", "white")
            self.canvas.create_rectangle(x1, y1, x2, y2, outline=color)
        
        elif t == "text":
            x, y = prim.get("x", 0), prim.get("y", 0)
            text = prim.get("text", "")
            color = prim.get("color", "white")
            self.canvas.create_text(x, y, text=text, fill=color, anchor=tk.NW)
    
    def get_ascii_snapshot(self) -> str:
        """Get current ASCII map."""
        return self._last_ascii


class DiagnosticsPanel(ttk.Frame):
    """Diagnostics panel showing engine state."""
    
    def __init__(self, master):
        super().__init__(master)
        
        # Header
        header = ttk.Label(self, text="Diagnostics", font=("", 10, "bold"))
        header.pack(side=tk.TOP, fill=tk.X, padx=4, pady=4)
        
        # Text display
        self.text = tk.Text(
            self, 
            wrap=tk.WORD,
            font=("Consolas", 9),
            background="#1a1a1a",
            foreground="#9cdcfe"
        )
        self.text.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        # Zone indicator
        self.zone_frame = ttk.Frame(self)
        self.zone_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=4, pady=4)
        
        self.zone_var = tk.StringVar(value="Zone: GREEN")
        self.zone_label = ttk.Label(self.zone_frame, textvariable=self.zone_var)
        self.zone_label.pack(side=tk.LEFT)
        
        self.avatar_var = tk.StringVar(value="Avatar: inactive")
        self.avatar_label = ttk.Label(self.zone_frame, textvariable=self.avatar_var)
        self.avatar_label.pack(side=tk.RIGHT)
    
    def update(self, diag: dict) -> None:
        """Update diagnostics display.
        
        Args:
            diag: Dictionary of diagnostic values
        """
        self.text.delete("1.0", tk.END)
        
        for k, v in (diag or {}).items():
            self.text.insert(tk.END, f"{k}: {v}\n")
        
        # Update zone indicator
        zone = diag.get("zone", "GREEN") if diag else "GREEN"
        self.zone_var.set(f"Zone: {zone}")
        
        # Update avatar indicator
        avatar_active = diag.get("avatar_mode", False) if diag else False
        self.avatar_var.set(f"Avatar: {'ACTIVE' if avatar_active else 'inactive'}")

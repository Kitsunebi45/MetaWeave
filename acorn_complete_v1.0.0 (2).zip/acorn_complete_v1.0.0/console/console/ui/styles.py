"""Acorn Console UI Styles."""

import tkinter as tk
from tkinter import ttk


def apply_styles(root: tk.Tk) -> None:
    """Apply consistent styling to the application."""
    
    style = ttk.Style()
    
    # Use clam theme as base (works well cross-platform)
    style.theme_use("clam")
    
    # Colors
    bg_dark = "#1e1e1e"
    bg_medium = "#252526"
    fg_light = "#d4d4d4"
    accent = "#569cd6"
    
    # Configure frame styles
    style.configure("TFrame", background=bg_medium)
    style.configure("TLabel", background=bg_medium, foreground=fg_light)
    style.configure("TButton", padding=4)
    
    # Configure entry
    style.configure("TEntry", fieldbackground=bg_dark, foreground=fg_light)
    
    # Configure combobox
    style.configure("TCombobox", fieldbackground=bg_dark, foreground=fg_light)
    
    # Configure paned window
    style.configure("TPanedwindow", background=bg_medium)
    
    # Root window background
    root.configure(background=bg_medium)

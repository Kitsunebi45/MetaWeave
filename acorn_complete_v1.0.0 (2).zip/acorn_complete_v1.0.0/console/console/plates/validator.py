"""Acorn Console Plate Validator.

Basic screening validation only - engine enforces full signature/license/lineage validation.
"""

from typing import Tuple
import json

from .models import PlateInfo, PlateType


# Minimum sizes for plate types
MIN_PLATE_SIZE = 16  # bytes
MAX_PLATE_SIZE = 100 * 1024 * 1024  # 100 MB


def basic_plate_screening(raw: bytes) -> Tuple[bool, str]:
    """Perform basic screening on plate data.
    
    This is NOT full validation - the engine enforces real
    signature, license, and lineage validation.
    
    Args:
        raw: Raw plate bytes
        
    Returns:
        Tuple of (ok, message)
    """
    if not raw:
        return False, "Empty plate"
    
    if len(raw) < MIN_PLATE_SIZE:
        return False, f"Plate too small ({len(raw)} bytes)"
    
    if len(raw) > MAX_PLATE_SIZE:
        return False, f"Plate too large ({len(raw)} bytes)"
    
    # Check for obviously malformed data
    # JSON plates should start with '{'
    # PNG plates should start with PNG signature
    # Binary plates have their own format
    
    if raw.startswith(b"{"):
        # JSON plate - check basic structure
        try:
            data = json.loads(raw.decode("utf-8"))
            if not isinstance(data, dict):
                return False, "Invalid plate structure (not an object)"
            
            # Check for required fields
            if "plate_id" not in data:
                return False, "Missing plate_id"
            if "plate_type" not in data:
                return False, "Missing plate_type"
                
        except json.JSONDecodeError as e:
            return False, f"Invalid JSON: {e}"
        except UnicodeDecodeError as e:
            return False, f"Invalid encoding: {e}"
    
    elif raw.startswith(b"\x89PNG\r\n\x1a\n"):
        # PNG plate - basic PNG validation
        if len(raw) < 100:
            return False, "PNG too small to be valid"
    
    # If we get here, basic screening passes
    return True, "OK"


def validate_plate_type(plate_type_str: str) -> Tuple[bool, PlateType]:
    """Validate a plate type string.
    
    Args:
        plate_type_str: Plate type string
        
    Returns:
        Tuple of (valid, PlateType)
    """
    try:
        return True, PlateType(plate_type_str)
    except ValueError:
        return False, PlateType.UNKNOWN


def validate_schema_version(version: str) -> Tuple[bool, str]:
    """Validate schema version format.
    
    Args:
        version: Schema version string (e.g., "1.0.0")
        
    Returns:
        Tuple of (valid, message)
    """
    if not version:
        return False, "Missing schema version"
    
    parts = version.split(".")
    if len(parts) != 3:
        return False, f"Invalid version format: {version}"
    
    try:
        for part in parts:
            int(part)
    except ValueError:
        return False, f"Invalid version numbers: {version}"
    
    return True, "OK"


def validate_engine_compat(compat: str) -> Tuple[bool, str]:
    """Validate engine compatibility string.
    
    Args:
        compat: Engine compatibility string (e.g., ">=12.0.0 <13.0.0")
        
    Returns:
        Tuple of (valid, message)
    """
    if not compat:
        return False, "Missing engine compatibility"
    
    # Basic format check - should contain version-like strings
    if not any(c.isdigit() for c in compat):
        return False, f"Invalid compatibility format: {compat}"
    
    return True, "OK"

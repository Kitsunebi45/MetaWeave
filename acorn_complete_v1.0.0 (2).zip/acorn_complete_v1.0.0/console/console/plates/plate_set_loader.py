"""Acorn Console Plate Set Loader.

Loads complete plate sets from folders rather than individual files.
Validates completeness and origin consistency before engine handoff.

This is the ONLY supported way to load plates in the free console.
Single-file loading is deprecated.
"""

import os
import json
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List
from dataclasses import dataclass, field


class PlateSetError(Exception):
    """Error during plate set loading or validation."""
    pass


# Required plate types for a complete set
REQUIRED_PLATE_TYPES = {"world", "characters", "learning"}

# Valid console compatibility string
VALID_CONSOLE_COMPAT = "acorn_console_free"


@dataclass
class PlateData:
    """Loaded plate data with metadata."""
    path: str
    plate_id: str
    plate_type: str
    version: str
    data: Dict[str, Any]


@dataclass
class PlateSet:
    """Complete plate set ready for engine loading."""
    origin: str
    folder_path: str
    plates: Dict[str, PlateData] = field(default_factory=dict)
    
    def is_complete(self) -> bool:
        """Check if all required plates are present."""
        return set(self.plates.keys()) == REQUIRED_PLATE_TYPES
    
    def get_missing(self) -> List[str]:
        """Get list of missing plate types."""
        return list(REQUIRED_PLATE_TYPES - set(self.plates.keys()))
    
    def to_engine_payload(self) -> Dict[str, Any]:
        """Convert to engine load payload for atomic loading."""
        return {
            "origin": self.origin,
            "world": self.plates["world"].data,
            "characters": self.plates["characters"].data,
            "learning": self.plates["learning"].data
        }
    
    def get_summary(self) -> List[str]:
        """Get human-readable summary of loaded plates."""
        lines = [
            f"Origin: {self.origin}",
            f"Folder: {self.folder_path}",
            "Plates:"
        ]
        for ptype in ["world", "characters", "learning"]:
            pdata = self.plates[ptype]
            lines.append(f"  - {ptype}: {pdata.plate_id} v{pdata.version}")
        return lines


def validate_plate_header(data: Dict[str, Any], filename: str) -> Tuple[str, str, str, str]:
    """Validate plate header and extract key fields.
    
    Args:
        data: Parsed plate JSON
        filename: Original filename for error messages
        
    Returns:
        Tuple of (plate_id, plate_type, version, origin_plate_set)
        
    Raises:
        PlateSetError: If validation fails
    """
    header = data.get("plate_header")
    if not header:
        raise PlateSetError(f"Missing plate_header in {filename}")
    
    # Required header fields
    plate_id = header.get("plate_id")
    if not plate_id:
        raise PlateSetError(f"Missing plate_id in {filename}")
    
    plate_type = header.get("plate_type")
    if not plate_type:
        raise PlateSetError(f"Missing plate_type in {filename}")
    
    if plate_type not in REQUIRED_PLATE_TYPES:
        raise PlateSetError(f"Invalid plate_type '{plate_type}' in {filename}")
    
    version = header.get("version", "0.0.0")
    
    # Author/copyright validation (must be present)
    if not header.get("author"):
        raise PlateSetError(f"Missing author in {filename}")
    
    if not header.get("copyright"):
        raise PlateSetError(f"Missing copyright in {filename}")
    
    if not header.get("license"):
        raise PlateSetError(f"Missing license in {filename}")
    
    # Engine lineage validation
    lineage = header.get("engine_lineage")
    if not lineage:
        raise PlateSetError(f"Missing engine_lineage in {filename}")
    
    if lineage.get("engine_name") != "Acorn Engine":
        raise PlateSetError(f"Invalid engine_name in {filename}")
    
    if lineage.get("console_compat") != VALID_CONSOLE_COMPAT:
        raise PlateSetError(
            f"Incompatible console_compat '{lineage.get('console_compat')}' in {filename}. "
            f"Expected: {VALID_CONSOLE_COMPAT}"
        )
    
    origin = lineage.get("origin_plate_set")
    if not origin:
        raise PlateSetError(f"Missing origin_plate_set in {filename}")
    
    # Integrity check (hash/signature must exist)
    integrity = header.get("integrity")
    if not integrity:
        raise PlateSetError(f"Missing integrity in {filename}")
    
    if not integrity.get("hash"):
        raise PlateSetError(f"Missing integrity.hash in {filename}")
    
    if not integrity.get("signature"):
        raise PlateSetError(f"Missing integrity.signature in {filename}")
    
    return plate_id, plate_type, version, origin


def scan_plate_folder(folder_path: str) -> PlateSet:
    """Scan a folder for a complete plate set.
    
    IMPORTANT: Only loads versioned plates (*.v1.json) to prevent
    legacy/incomplete files from interfering.
    
    Args:
        folder_path: Path to folder containing plate JSON files
        
    Returns:
        PlateSet with all loaded plates
        
    Raises:
        PlateSetError: If folder is invalid or plates fail validation
    """
    folder = Path(folder_path)
    
    if not folder.exists():
        raise PlateSetError(f"Folder not found: {folder_path}")
    
    if not folder.is_dir():
        raise PlateSetError(f"Not a directory: {folder_path}")
    
    # STRICT: Only load versioned plates (*.v1.json)
    # This prevents legacy/incomplete files from interfering
    json_files = list(folder.glob("*.v1.json"))
    
    if not json_files:
        # Friendly error message
        raise PlateSetError(
            f"No versioned plate files (*.v1.json) found in {folder_path}. "
            f"Plates must use versioned naming (e.g., fairy_garden.world.v1.json)"
        )
    
    # Track origin for consistency check
    plate_set = PlateSet(origin="", folder_path=str(folder))
    
    for json_path in json_files:
        filename = json_path.name
        
        # Load JSON
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            raise PlateSetError(f"Invalid JSON in {filename}: {e}")
        except Exception as e:
            raise PlateSetError(f"Cannot read {filename}: {e}")
        
        # Versioned plates MUST have plate_header
        if "plate_header" not in data:
            raise PlateSetError(
                f"Versioned plate {filename} is missing plate_header. "
                f"This file may be corrupted or incomplete."
            )
        
        # Validate header
        plate_id, plate_type, version, origin = validate_plate_header(data, filename)
        
        # Check for duplicate plate types
        if plate_type in plate_set.plates:
            existing = plate_set.plates[plate_type].plate_id
            raise PlateSetError(
                f"Duplicate {plate_type} plate: {plate_id} conflicts with {existing}"
            )
        
        # Check origin consistency
        if not plate_set.origin:
            plate_set.origin = origin
        elif plate_set.origin != origin:
            raise PlateSetError(
                f"Origin mismatch: {origin} != {plate_set.origin} in {filename}"
            )
        
        # Store plate
        plate_set.plates[plate_type] = PlateData(
            path=str(json_path),
            plate_id=plate_id,
            plate_type=plate_type,
            version=version,
            data=data
        )
    
    # Check completeness
    if not plate_set.is_complete():
        missing = plate_set.get_missing()
        raise PlateSetError(f"Missing required plate(s): {', '.join(missing)}")
    
    return plate_set


def load_plate_set_from_folder(folder_path: str) -> Tuple[bool, str, Optional[PlateSet]]:
    """Load and validate a complete plate set from a folder.
    
    Args:
        folder_path: Path to folder containing plates
        
    Returns:
        Tuple of (success, message, plate_set or None)
    """
    try:
        plate_set = scan_plate_folder(folder_path)
        return True, "Plate set loaded successfully", plate_set
    except PlateSetError as e:
        return False, str(e), None
    except Exception as e:
        return False, f"Unexpected error: {e}", None

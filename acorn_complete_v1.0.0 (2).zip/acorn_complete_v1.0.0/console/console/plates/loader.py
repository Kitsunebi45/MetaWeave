"""Acorn Console Plate Loader.

Loads plates from various file formats.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
import json

from .models import PlateInfo, PlateType


@dataclass
class PlatePayload:
    """Loaded plate payload."""
    raw: bytes
    meta: Dict[str, Any]
    info: Optional[PlateInfo] = None


def detect_plate_format(path: Path, content: bytes) -> str:
    """Detect the format of a plate file.
    
    Args:
        path: File path
        content: File content
        
    Returns:
        Format string: "json", "png", "binary", or "unknown"
    """
    suffix = path.suffix.lower()
    
    # Check by extension
    if suffix in (".json", ".plate"):
        return "json"
    elif suffix == ".png":
        return "png"
    elif suffix == ".acorn":
        # Acorn files could be JSON or binary
        if content.startswith(b"{"):
            return "json"
        return "binary"
    
    # Check by content
    if content.startswith(b"{"):
        return "json"
    elif content.startswith(b"\x89PNG"):
        return "png"
    
    return "unknown"


def extract_plate_info_from_json(data: Dict[str, Any]) -> PlateInfo:
    """Extract plate info from JSON data.
    
    Args:
        data: Parsed JSON data
        
    Returns:
        PlateInfo object
    """
    info = PlateInfo.from_dict(data)
    info.is_valid_structure = bool(info.plate_id and info.plate_type != PlateType.UNKNOWN)
    if info.is_valid_structure:
        info.validation_message = "OK"
    else:
        info.validation_message = "Missing required fields"
    return info


def extract_plate_info_from_png(content: bytes) -> PlateInfo:
    """Extract plate info from PNG (GHMP format).
    
    PNG plates may have metadata in tEXt/iTXt chunks.
    
    Args:
        content: PNG file content
        
    Returns:
        PlateInfo object (may be minimal if no metadata found)
    """
    info = PlateInfo()
    info.is_valid_structure = True  # PNG existence = valid for now
    info.validation_message = "PNG plate (metadata extraction not implemented)"
    
    # TODO: Implement PNG chunk parsing for GHMP metadata
    # For now, return minimal info
    
    return info


def load_plate_from_path(path: str) -> Tuple[bool, str, Optional[PlatePayload]]:
    """Load a plate from a file path.
    
    Args:
        path: Path to plate file
        
    Returns:
        Tuple of (success, message, payload)
    """
    p = Path(path)
    
    if not p.exists():
        return False, f"File not found: {path}", None
    
    if not p.is_file():
        return False, f"Not a file: {path}", None
    
    try:
        raw = p.read_bytes()
    except Exception as e:
        return False, f"Failed to read file: {e}", None
    
    # Detect format
    fmt = detect_plate_format(p, raw)
    
    # Extract info based on format
    info = None
    if fmt == "json":
        try:
            data = json.loads(raw.decode("utf-8"))
            info = extract_plate_info_from_json(data)
        except json.JSONDecodeError as e:
            return False, f"Invalid JSON: {e}", None
        except UnicodeDecodeError as e:
            return False, f"Invalid encoding: {e}", None
    elif fmt == "png":
        info = extract_plate_info_from_png(raw)
    elif fmt == "binary":
        info = PlateInfo()
        info.validation_message = "Binary plate format"
    else:
        info = PlateInfo()
        info.validation_message = "Unknown format"
    
    meta = {
        "path": str(p.absolute()),
        "filename": p.name,
        "format": fmt,
        "size": len(raw)
    }
    
    return True, "Loaded", PlatePayload(raw=raw, meta=meta, info=info)

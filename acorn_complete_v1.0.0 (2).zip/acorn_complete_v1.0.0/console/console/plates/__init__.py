"""Acorn Console Plates Module.

Handles plate loading and validation (screening only - engine enforces full validation).
"""

from .loader import load_plate_from_path, PlatePayload
from .validator import basic_plate_screening
from .models import PlateInfo, PlateType
from .plate_set_loader import (
    PlateSetError, 
    PlateSet, 
    PlateData,
    scan_plate_folder, 
    load_plate_set_from_folder
)

__all__ = [
    'load_plate_from_path',
    'PlatePayload',
    'basic_plate_screening',
    'PlateInfo',
    'PlateType',
    'PlateSetError',
    'PlateSet',
    'PlateData',
    'scan_plate_folder',
    'load_plate_set_from_folder'
]

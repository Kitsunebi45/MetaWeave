"""Acorn Console Plate Models."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional
from enum import Enum


class PlateType(Enum):
    """Types of plates."""
    WORLD = "WORLD"
    ENTITY = "ENTITY"
    RULE = "RULE"
    SCENARIO = "SCENARIO"
    UNKNOWN = "UNKNOWN"


@dataclass
class PlateInfo:
    """Information about a plate (extracted from header)."""
    
    # Identity
    plate_id: str = ""
    plate_type: PlateType = PlateType.UNKNOWN
    name: str = ""
    version: str = ""
    
    # Compatibility
    schema_version: str = ""
    engine_compat: str = ""
    
    # Metadata
    resonance_key: str = ""
    created_at: str = ""
    tags: List[str] = field(default_factory=list)
    
    # Source
    author: str = ""
    source_path: str = ""
    
    # Validation status (console-side screening)
    is_valid_structure: bool = False
    validation_message: str = ""
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PlateInfo":
        """Create PlateInfo from plate header dictionary."""
        plate_type_str = data.get("plate_type", "UNKNOWN")
        try:
            plate_type = PlateType(plate_type_str)
        except ValueError:
            plate_type = PlateType.UNKNOWN
        
        source = data.get("source", {})
        
        return cls(
            plate_id=data.get("plate_id", ""),
            plate_type=plate_type,
            name=data.get("name", ""),
            version=data.get("version", ""),
            schema_version=data.get("schema_version", ""),
            engine_compat=data.get("engine_compat", ""),
            resonance_key=data.get("resonance_key", ""),
            created_at=data.get("created_at", ""),
            tags=data.get("tags", []),
            author=source.get("author", ""),
            source_path=source.get("source_path", "")
        )
    
    def summary(self) -> str:
        """Get a summary string."""
        return f"{self.plate_type.value}: {self.name} v{self.version} ({self.plate_id})"

"""Acorn Console - Free Version.

A desktop interface for interacting with Acorn/Spore Engine v12.
"""

__version__ = "0.1.0"

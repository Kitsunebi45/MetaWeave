# Acorn Engine v12.19.0

A deterministic simulation engine with immutable configuration plates, bounded learning, runtime persistence, read-only visualization, and curriculum-based teaching.

---

## What This System Is

Acorn Engine is a **deterministic simulation engine** designed for:

- Reproducible world simulation
- Modular configuration via "plates"
- Explicit teaching and bounded learning
- Full state persistence and restoration

Key properties:
- **Immutable plates**: Configuration cannot be modified at runtime
- **Deterministic execution**: Same inputs always produce same outputs
- **Bounded learning**: Skills are constrained by explicit envelopes
- **Offline operation**: No network dependencies

---

## What This System Is NOT

- ❌ Not a game (it's an engine for building simulations)
- ❌ Not networked (runs entirely offline)
- ❌ Not a GUI application (text-based interface only)
- ❌ Not self-modifying (no autonomous goal creation)
- ❌ Not a general AI (bounded, explicit learning only)

---

## Installation

### Requirements

- Python 3.10 or later
- No external dependencies required (stdlib only)

### Setup

```bash
# Create virtual environment (recommended)
python -m venv venv

# Activate (Linux/macOS)
source venv/bin/activate

# Activate (Windows)
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

---

## Running the Engine

### Interactive Mode (REPL + Console Socket)

```bash
python main.py
```

This starts:
1. Console socket server on **port 17778**
2. Interactive REPL interface

Type `help` for available commands.

### Socket Server Only (for console testing)

```bash
python socket_server.py
```

This starts ONLY the socket server. Useful for testing console connections without the REPL.

### Verify Socket is Running

```bash
# Windows
netstat -an | find "17778"

# Linux/Mac
netstat -tln | grep 17778
```

You should see:
```
TCP    127.0.0.1:17778    LISTENING
```

---

## Console Connection

The engine listens for console connections on **127.0.0.1:17778**.

Protocol: JSON line (newline-delimited JSON over TCP)

### Message Flow

```
Console                          Engine
   │                                │
   │──── TCP connect ───────────────│
   │                                │
   │──── {"type":"hello",...}\n ───►│
   │                                │
   │◄─── {"type":"hello_ack"}\n ────│
   │                                │
   │──── {"type":"command",...}\n ─►│
   │                                │
```

### Example Session

```
> show status
{"success": true, "command": "show_status", "data": {"tick": 0, "running": false}}

> start scenario example_scenario
{"success": true, "command": "start_scenario", "data": {"started": true}}

> teach entity explorer_1 navigation 0.1 reason "training"
{"success": true, "command": "teach_entity", "data": {"new_value": 0.1}}

> save
{"success": true, "command": "save", "data": {"saved": true}}

> quit
Goodbye.
```

---

## Verifying Integrity

### Run Tests

```bash
# Run Phase 13-16 tests
python tests/test_phase13_wired.py
python tests/test_phase14_save.py
python tests/test_phase15_learning.py
python tests/test_phase16_interface.py
```

### Verify Checksums

Compare `CHECKSUMS.sha256` in the verification bundle against your files:

```bash
sha256sum -c CHECKSUMS.sha256
```

---

## Project Structure

```
acorn-engine/
├── engine/              # Core engine code
│   ├── plates/          # Phase 13 - Plate system
│   ├── save/            # Phase 14 - Persistence
│   ├── learning/        # Phase 15 - Learning system
│   └── interface/       # Phase 16 - Interface layer
├── plates/
│   └── examples/        # Example plate files
├── tests/               # Acceptance tests
├── docs/                # Documentation
├── main.py              # Entry point
├── requirements.txt     # Dependencies
├── VERSION.txt          # Version string
└── BUILD_MANIFEST.json  # Build metadata
```

---

## Known Limitations

1. **Cold-load only**: Plates cannot be hot-reloaded
2. **Single-threaded**: No concurrent execution
3. **Text-only interface**: No GUI
4. **History cap**: 100 entries per entity maximum
5. **Offline only**: No network features

---

## Documentation

See `docs/` for detailed documentation:

- `PHASE13.md` - Plate Contract System
- `PHASE14.md` - Runtime State Persistence
- `PHASE15.md` - Bounded Learning & Teaching
- `PHASE16.md` - Interface Layer
- `PHASE18.md` - Observation & Visualization
- `PHASE19.md` - Curriculum & Teaching Tooling
- `RELEASE_NOTES.md` - Full release notes

---

## License

This software is provided for evaluation and development purposes.

---

## Security Model

This engine assumes a **trusted user model**:

- User is trusted
- Engine enforces invariants
- No authentication or permissions system
- No sandboxing or encryption
- No telemetry

---

## Version

```
12.19.0
```

Phases included: 13, 14, 15, 16, 18, 19

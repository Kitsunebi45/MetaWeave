#!/usr/bin/env python3
"""Standalone Console Socket Server.

Run this to start ONLY the socket server (no engine REPL).
Useful for testing console connections.

Usage:
    python socket_server.py
    
Then in another terminal:
    python run_console.py
"""

import sys
import time
from pathlib import Path

# Add engine to path
sys.path.insert(0, str(Path(__file__).parent))

from engine.console_socket import start_console_server, get_console_server


def main():
    print("=" * 60)
    print("Acorn Engine Socket Server (Standalone)")
    print("=" * 60)
    print()
    
    # Start socket server
    server = start_console_server()
    
    if not server:
        print("ERROR: Failed to start socket server!")
        return 1
    
    print()
    print("Socket server is running.")
    print("Connect with console: acorn-engine@127.0.0.1:17778")
    print()
    print("Press Ctrl+C to stop.")
    print("-" * 60)
    
    try:
        while True:
            time.sleep(1)
            count = server.client_count()
            if count > 0:
                print(f"[server] {count} console(s) connected")
    except KeyboardInterrupt:
        print("\nShutting down...")
        server.stop()
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

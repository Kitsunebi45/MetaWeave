"""Phase 14 × Engine V12 — Save/Load Acceptance Tests

Tests:
1. Save/Load Identity — Boot → save → load, runtime state identical
2. Plate Stack Mismatch — Load save with different plate stack, expect hard failure
3. Determinism — Save → load → run, compare with uninterrupted run
4. Plate Immutability — Assert plates unchanged after load
"""

import sys
import os
import tempfile
from pathlib import Path
from datetime import datetime, timezone

# Ensure we're testing the actual v12 engine
ENGINE_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ENGINE_ROOT))

# Import from real v12 engine
from engine.phase13_boot import validate_plate_stack, ENGINE_VERSION
from engine.save import (
    SaveManager,
    RuntimeState,
    SaveEnvelope,
    SaveSchemaError,
    SaveCompatError,
    create_runtime_state
)


# =============================================================================
# TEST FIXTURES
# =============================================================================

def make_world_plate():
    """Create valid WORLD plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "world-001",
        "plate_type": "WORLD",
        "name": "Test World",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "world.test.v0",
        "created_at": "2026-01-23T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/world.json"},
        "content": {
            "world_id": "test_world",
            "topology": {"mode": "graph"},
            "regions": [
                {"region_id": "r0", "name": "Spawn"},
                {"region_id": "r1", "name": "Zone A"}
            ],
            "connections": [{"from": "r0", "to": "r1"}],
            "constraints": {"max_entities": 100}
        }
    }


def make_entity_plate():
    """Create valid ENTITY plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "entity-001",
        "plate_type": "ENTITY",
        "name": "Test Entities",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "entities.test.v0",
        "created_at": "2026-01-23T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/entities.json"},
        "content": {
            "entity_templates": [
                {
                    "template_id": "basic_entity",
                    "name": "Basic Entity",
                    "traits": {"speed": 1.0},
                    "capabilities": ["move", "observe"]
                }
            ]
        }
    }


def get_test_config():
    """Get resolved config for test plates."""
    return validate_plate_stack([make_world_plate(), make_entity_plate()])


def get_test_state(counter=42, health=100, last_tick=1000):
    """Create test runtime state."""
    return create_runtime_state(
        world_state={"counter": counter, "flags": {"started": True}},
        entities={
            "e1": {"health": health, "position": {"x": 10, "y": 20}},
            "e2": {"health": 50, "position": {"x": 30, "y": 40}}
        },
        systems={
            "rule_engine": {"last_tick": last_tick, "events_fired": 5}
        }
    )


# =============================================================================
# TEST EXECUTION
# =============================================================================

class TestResult:
    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.message = ""
        self.error = None
    
    def __str__(self):
        status = "✅ PASS" if self.passed else "❌ FAIL"
        result = f"{status} | Test {self.name}: {self.message}"
        if self.error:
            result += f"\n         Error: {self.error}"
        return result


def run_test_1_save_load_identity() -> TestResult:
    """Test 1: Save/Load Identity — runtime state must be identical."""
    result = TestResult("1 - Save/Load Identity")
    
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "test_save.json"
            
            # Get plate config
            config = get_test_config()
            
            # Create save manager
            save_mgr = SaveManager.from_resolved_config(config)
            
            # Create state
            original_state = get_test_state(counter=42, health=100, last_tick=1000)
            original_tick = 1000
            
            # Save
            saved_envelope = save_mgr.save_state(
                path=save_path,
                tick=original_tick,
                state=original_state,
                metadata={"name": "Test Save"}
            )
            
            # Verify file exists
            assert save_path.exists(), "Save file not created"
            
            # Load
            loaded_envelope = save_mgr.load_state(save_path)
            
            # Verify identity
            assert loaded_envelope.tick == original_tick, "Tick mismatch"
            assert loaded_envelope.state.world_state == original_state.world_state, "world_state mismatch"
            assert loaded_envelope.state.entities == original_state.entities, "entities mismatch"
            assert loaded_envelope.state.systems == original_state.systems, "systems mismatch"
            assert loaded_envelope.plate_stack_hash == config.checksum, "plate_stack_hash mismatch"
            
            result.passed = True
            result.message = "Runtime state identical after save/load"
            
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_2_plate_stack_mismatch() -> TestResult:
    """Test 2: Plate Stack Mismatch — expect hard failure."""
    result = TestResult("2 - Plate Stack Mismatch")
    
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "test_save.json"
            
            # Get config A
            config_a = get_test_config()
            
            # Save with config A
            save_mgr_a = SaveManager.from_resolved_config(config_a)
            state = get_test_state()
            save_mgr_a.save_state(save_path, tick=100, state=state)
            
            # Create different plate stack (config B)
            # Different plate = different hash
            different_world = make_world_plate()
            different_world["plate_id"] = "world-002"
            different_world["resonance_key"] = "world.test.v2"
            different_world["content"]["world_id"] = "different_world"
            
            config_b = validate_plate_stack([different_world, make_entity_plate()])
            
            # Verify hashes are different
            assert config_a.checksum != config_b.checksum, "Test setup error: hashes should differ"
            
            # Try to load with config B
            save_mgr_b = SaveManager.from_resolved_config(config_b)
            
            try:
                save_mgr_b.load_state(save_path)
                result.message = "Should have failed but didn't"
                result.error = "No exception raised for plate stack mismatch"
            except SaveCompatError as e:
                if "plate_stack_hash" in str(e).lower() or "mismatch" in str(e).lower():
                    result.passed = True
                    result.message = "Hard failure on plate stack mismatch (SAVE_COMPAT_ERROR)"
                else:
                    result.error = str(e)
            
    except Exception as e:
        result.message = "Unexpected error"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_3_determinism() -> TestResult:
    """Test 3: Determinism — save/load produces identical checksums."""
    result = TestResult("3 - Determinism")
    
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path_1 = Path(tmpdir) / "save_1.json"
            save_path_2 = Path(tmpdir) / "save_2.json"
            
            config = get_test_config()
            save_mgr = SaveManager.from_resolved_config(config)
            
            # Same state, different saves
            state = get_test_state(counter=42, health=100, last_tick=1000)
            
            envelope_1 = save_mgr.save_state(save_path_1, tick=1000, state=state)
            envelope_2 = save_mgr.save_state(save_path_2, tick=1000, state=state)
            
            # Load both
            loaded_1 = save_mgr.load_state(save_path_1)
            loaded_2 = save_mgr.load_state(save_path_2)
            
            # Verify state is identical
            assert loaded_1.state.world_state == loaded_2.state.world_state
            assert loaded_1.state.entities == loaded_2.state.entities
            assert loaded_1.state.systems == loaded_2.state.systems
            assert loaded_1.tick == loaded_2.tick
            assert loaded_1.plate_stack_hash == loaded_2.plate_stack_hash
            
            result.passed = True
            result.message = "Deterministic save/load verified"
            
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_4_plate_immutability() -> TestResult:
    """Test 4: Plate Immutability — plates unchanged after load."""
    result = TestResult("4 - Plate Immutability")
    
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "test_save.json"
            
            # Get config and capture original values
            config = get_test_config()
            original_checksum = config.checksum
            original_world_id = config.world_config.world_id
            original_template_ids = set(config.entity_templates.keys())
            
            # Save and load
            save_mgr = SaveManager.from_resolved_config(config)
            state = get_test_state()
            save_mgr.save_state(save_path, tick=100, state=state)
            loaded = save_mgr.load_state(save_path)
            
            # Verify plates unchanged
            # (We compare against the saved plate_stack_hash)
            assert loaded.plate_stack_hash == original_checksum, "Plate hash changed"
            
            # Verify config objects are still frozen
            try:
                config.checksum = "tampered"
                result.error = "Config mutation allowed"
                return result
            except AttributeError:
                pass  # Expected - frozen
            
            # Verify ResolvedConfig values unchanged
            config_after = get_test_config()
            assert config_after.checksum == original_checksum, "Config checksum changed"
            assert config_after.world_config.world_id == original_world_id, "World ID changed"
            assert set(config_after.entity_templates.keys()) == original_template_ids, "Templates changed"
            
            result.passed = True
            result.message = "Plates remain immutable after save/load"
            
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_5_engine_version_mismatch() -> TestResult:
    """Test 5: Engine Version Mismatch — expect hard failure."""
    result = TestResult("5 - Engine Version Mismatch")
    
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "test_save.json"
            
            config = get_test_config()
            
            # Save with current version (12.0.0)
            save_mgr = SaveManager.from_resolved_config(config)
            state = get_test_state()
            save_mgr.save_state(save_path, tick=100, state=state)
            
            # Create manager with different version
            save_mgr_future = SaveManager(
                plate_stack_hash=config.checksum,
                engine_version="13.0.0"  # Different!
            )
            
            try:
                save_mgr_future.load_state(save_path)
                result.message = "Should have failed"
                result.error = "No exception for version mismatch"
            except SaveCompatError as e:
                if "engine_version" in str(e).lower() or "mismatch" in str(e).lower():
                    result.passed = True
                    result.message = "Hard failure on engine version mismatch"
                else:
                    result.error = str(e)
            
    except Exception as e:
        result.message = "Unexpected error"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_6_corrupt_json() -> TestResult:
    """Test 6: Corrupt Save JSON — expect hard failure."""
    result = TestResult("6 - Corrupt Save JSON")
    
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "corrupt_save.json"
            
            # Write corrupt JSON
            save_path.write_text("{ this is not valid json }")
            
            config = get_test_config()
            save_mgr = SaveManager.from_resolved_config(config)
            
            try:
                save_mgr.load_state(save_path)
                result.message = "Should have failed"
                result.error = "No exception for corrupt JSON"
            except SaveSchemaError as e:
                if "json" in str(e).lower() or "invalid" in str(e).lower():
                    result.passed = True
                    result.message = "Hard failure on corrupt JSON"
                else:
                    result.error = str(e)
            
    except Exception as e:
        result.message = "Unexpected error"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_7_missing_required_field() -> TestResult:
    """Test 7: Missing Required Field — expect hard failure."""
    result = TestResult("7 - Missing Required Field")
    
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "incomplete_save.json"
            
            config = get_test_config()
            
            # Write incomplete save (missing tick)
            import json
            incomplete = {
                "schema_version": "1.0.0",
                "save_id": "test-123",
                "engine_version": "12.0.0",
                "plate_stack_hash": config.checksum,
                "created_at": "2026-01-23T00:00:00Z",
                # Missing: "tick"
                "state": {}
            }
            save_path.write_text(json.dumps(incomplete))
            
            save_mgr = SaveManager.from_resolved_config(config)
            
            try:
                save_mgr.load_state(save_path)
                result.message = "Should have failed"
                result.error = "No exception for missing field"
            except SaveSchemaError as e:
                if "tick" in str(e).lower() or "missing" in str(e).lower():
                    result.passed = True
                    result.message = "Hard failure on missing required field"
                else:
                    result.error = str(e)
            
    except Exception as e:
        result.message = "Unexpected error"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_8_atomic_write() -> TestResult:
    """Test 8: Atomic Write — verify temp file approach."""
    result = TestResult("8 - Atomic Write")
    
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "atomic_save.json"
            
            config = get_test_config()
            save_mgr = SaveManager.from_resolved_config(config)
            state = get_test_state()
            
            # Save multiple times - should work without corruption
            for i in range(5):
                save_mgr.save_state(save_path, tick=i * 100, state=state)
                loaded = save_mgr.load_state(save_path)
                assert loaded.tick == i * 100, f"Tick mismatch on iteration {i}"
            
            # Verify no temp files left behind
            temp_files = list(Path(tmpdir).glob(".save_*.tmp"))
            assert len(temp_files) == 0, f"Temp files remaining: {temp_files}"
            
            result.passed = True
            result.message = "Atomic writes verified, no temp files left behind"
            
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


# =============================================================================
# MAIN
# =============================================================================

def main():
    print()
    print("=" * 70)
    print("🧪 PHASE 14 × ENGINE V12 — SAVE/LOAD ACCEPTANCE TESTS")
    print("=" * 70)
    print(f"Engine Version: {ENGINE_VERSION}")
    print(f"Timestamp: {datetime.now(timezone.utc).isoformat()}")
    print("-" * 70)
    print()
    
    # Run all tests
    tests = [
        run_test_1_save_load_identity,
        run_test_2_plate_stack_mismatch,
        run_test_3_determinism,
        run_test_4_plate_immutability,
        run_test_5_engine_version_mismatch,
        run_test_6_corrupt_json,
        run_test_7_missing_required_field,
        run_test_8_atomic_write,
    ]
    
    results = []
    for test in tests:
        test_result = test()
        results.append(test_result)
        print(test_result)
        print()
    
    # Summary
    print("-" * 70)
    passed = sum(1 for r in results if r.passed)
    total = len(results)
    
    print(f"RESULTS: {passed}/{total} tests passed")
    print()
    
    # Verdict
    if passed == total:
        print("=" * 70)
        print("✅ Phase 14 runtime state persistence verified.")
        print("✅ Plates remain immutable.")
        print("✅ Saves restore deterministically.")
        print("=" * 70)
        return 0
    else:
        print("=" * 70)
        print("❌ Some tests failed. Review required.")
        print("=" * 70)
        return 1


if __name__ == "__main__":
    sys.exit(main())

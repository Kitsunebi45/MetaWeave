"""Phase 16 × Engine V12 — Interface Acceptance Tests

Tests:
1. Read commands do not mutate state
2. Teach command updates learning state correctly
3. Invalid commands fail early
4. Engine errors propagate unchanged
5. Determinism (same inputs → same outputs)
"""

import sys
import os
import tempfile
from pathlib import Path
from datetime import datetime, timezone
from io import StringIO

# Ensure we're testing the actual v12 engine
ENGINE_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ENGINE_ROOT))

# Import from real v12 engine
from engine.phase13_boot import validate_plate_stack, ENGINE_VERSION
from engine.save import SaveManager, create_runtime_state
from engine.learning import LearningManager, create_skill_envelope
from engine.interface import (
    CommandRouter,
    InterfaceAPI,
    REPL,
    create_repl,
    ParsedCommand,
    CommandParseError,
    CommandSchemaError,
    CommandNotFoundError
)


# =============================================================================
# TEST FIXTURES
# =============================================================================

def make_world_plate():
    """Create valid WORLD plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "world-001",
        "plate_type": "WORLD",
        "name": "Test World",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "world.test.v0",
        "created_at": "2026-01-23T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/world.json"},
        "content": {
            "world_id": "test_world",
            "topology": {"mode": "graph"},
            "regions": [
                {"region_id": "r0", "name": "Spawn"},
                {"region_id": "r1", "name": "Zone A"}
            ],
            "connections": [{"from": "r0", "to": "r1"}],
            "constraints": {"max_entities": 100}
        }
    }


def make_entity_plate():
    """Create valid ENTITY plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "entity-001",
        "plate_type": "ENTITY",
        "name": "Test Entities",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "entities.test.v0",
        "created_at": "2026-01-23T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/entities.json"},
        "content": {
            "entity_templates": [
                {
                    "template_id": "basic_entity",
                    "name": "Basic Entity",
                    "traits": {"speed": 1.0},
                    "capabilities": ["move", "observe"]
                }
            ]
        }
    }


def make_scenario_plate():
    """Create valid SCENARIO plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "scenario-001",
        "plate_type": "SCENARIO",
        "name": "Test Scenario",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "scenario.test.v0",
        "created_at": "2026-01-23T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/scenario.json"},
        "content": {
            "scenario_id": "test_scenario",
            "world_ref": "test_world",
            "initial_entities": [
                {
                    "entity_id": "e1",
                    "template_id": "basic_entity",
                    "region_id": "r0",
                    "state": {}
                }
            ],
            "parameters": {"ticks": 0}
        }
    }


def get_test_config():
    """Get resolved config for test plates."""
    return validate_plate_stack([
        make_world_plate(),
        make_entity_plate(),
        make_scenario_plate()
    ])


def create_test_learning_manager() -> LearningManager:
    """Create learning manager with test envelopes."""
    manager = LearningManager()
    manager.register_envelope("navigation", create_skill_envelope(0.0, 1.0, 0.05))
    manager.register_envelope("perception", create_skill_envelope(0.0, 1.0, 0.05))
    return manager


# =============================================================================
# TEST EXECUTION
# =============================================================================

class TestResult:
    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.message = ""
        self.error = None
    
    def __str__(self):
        status = "✅ PASS" if self.passed else "❌ FAIL"
        result = f"{status} | Test {self.name}: {self.message}"
        if self.error:
            result += f"\n         Error: {self.error}"
        return result


def run_test_1_read_commands_no_mutation() -> TestResult:
    """Test 1: Read commands do not mutate state."""
    result = TestResult("1 - Read Commands No Mutation")
    
    try:
        config = get_test_config()
        learning_mgr = create_test_learning_manager()
        
        api = InterfaceAPI(
            learning_manager=learning_mgr,
            resolved_config=config
        )
        router = CommandRouter()
        
        # Get initial state
        initial_tick = api._tick
        initial_entities = dict(api._entities)
        
        # Execute read commands
        read_commands = [
            "show world",
            "show entities",
            "show rules",
            "show scenario",
            "show status",
            "help"
        ]
        
        for cmd in read_commands:
            parsed = router.parse(cmd)
            response = api.execute(parsed)
            assert response.success, f"Command failed: {cmd}"
        
        # Verify no mutation
        assert api._tick == initial_tick, "Tick mutated by read command"
        assert api._entities == initial_entities, "Entities mutated by read command"
        
        result.passed = True
        result.message = "Read commands do not mutate state"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_2_teach_updates_learning() -> TestResult:
    """Test 2: Teach command updates learning state correctly."""
    result = TestResult("2 - Teach Updates Learning")
    
    try:
        config = get_test_config()
        learning_mgr = create_test_learning_manager()
        
        api = InterfaceAPI(
            learning_manager=learning_mgr,
            resolved_config=config
        )
        router = CommandRouter()
        
        # Initial skill value
        initial_value = learning_mgr.get_skill("e1", "navigation")
        assert initial_value == 0.0, f"Expected 0.0, got {initial_value}"
        
        # Execute teach command
        cmd = 'teach entity e1 navigation 0.1 reason "test teaching"'
        parsed = router.parse(cmd)
        response = api.execute(parsed)
        
        assert response.success, f"Teach failed: {response.error}"
        
        # Verify learning updated
        new_value = learning_mgr.get_skill("e1", "navigation")
        assert new_value == 0.1, f"Expected 0.1, got {new_value}"
        
        # Verify history recorded
        history = learning_mgr.get_history("e1")
        assert len(history) > 0, "No history recorded"
        assert "taught_navigation" in history[-1].event, "Teaching not in history"
        
        result.passed = True
        result.message = "Teach command updates learning correctly"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_3_invalid_commands_fail_early() -> TestResult:
    """Test 3: Invalid commands fail early (before engine call)."""
    result = TestResult("3 - Invalid Commands Fail Early")
    
    try:
        router = CommandRouter()
        errors_caught = 0
        
        # Test unknown command
        try:
            router.parse("foobar bazqux")
        except CommandNotFoundError:
            errors_caught += 1
        
        # Test empty command
        try:
            router.parse("")
        except CommandParseError:
            errors_caught += 1
        
        # Test malformed teach (missing reason)
        try:
            router.parse("teach entity e1 navigation 0.1")
        except (CommandNotFoundError, CommandSchemaError):
            errors_caught += 1
        
        assert errors_caught == 3, f"Expected 3 errors, caught {errors_caught}"
        
        result.passed = True
        result.message = "Invalid commands fail at parse stage"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_4_engine_errors_propagate() -> TestResult:
    """Test 4: Engine errors propagate unchanged."""
    result = TestResult("4 - Engine Errors Propagate")
    
    try:
        # API without required managers
        api = InterfaceAPI()  # No learning manager
        router = CommandRouter()
        
        # Try to teach without learning manager
        cmd = 'teach entity e1 navigation 0.1 reason "test"'
        parsed = router.parse(cmd)
        response = api.execute(parsed)
        
        # Should fail with error from engine
        assert not response.success, "Should have failed"
        assert response.error is not None, "Should have error"
        assert "Learning manager" in response.error.get("message", ""), \
            f"Wrong error: {response.error}"
        
        result.passed = True
        result.message = "Engine errors propagate unchanged"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_5_determinism() -> TestResult:
    """Test 5: Determinism — same inputs → same outputs."""
    result = TestResult("5 - Determinism")
    
    try:
        def run_command_sequence():
            config = get_test_config()
            learning_mgr = create_test_learning_manager()
            api = InterfaceAPI(
                learning_manager=learning_mgr,
                resolved_config=config
            )
            router = CommandRouter()
            
            commands = [
                "show status",
                'teach entity e1 navigation 0.1 reason "step 1"',
                'teach entity e1 navigation 0.1 reason "step 2"',
                "tick",
                "tick 5",
            ]
            
            results = []
            for cmd in commands:
                parsed = router.parse(cmd)
                response = api.execute(parsed)
                results.append(response.to_dict())
            
            return results, learning_mgr.get_state_dict()
        
        # Run twice
        results1, state1 = run_command_sequence()
        results2, state2 = run_command_sequence()
        
        # Compare results (excluding timestamps)
        for r1, r2 in zip(results1, results2):
            assert r1["success"] == r2["success"], "Success differs"
            assert r1["command"] == r2["command"], "Command differs"
        
        # Compare learning state
        assert state1["entities"]["e1"]["skills"] == state2["entities"]["e1"]["skills"], \
            "Learning skills differ"
        
        result.passed = True
        result.message = "Same inputs produce same outputs"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_6_save_load_via_interface() -> TestResult:
    """Test 6: Save and load work via interface."""
    result = TestResult("6 - Save/Load Via Interface")
    
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            save_dir = Path(tmpdir)
            
            config = get_test_config()
            learning_mgr = create_test_learning_manager()
            save_mgr = SaveManager.from_resolved_config(config)
            
            api = InterfaceAPI(
                learning_manager=learning_mgr,
                save_manager=save_mgr,
                resolved_config=config,
                save_dir=save_dir
            )
            router = CommandRouter()
            
            # Teach something
            cmd = 'teach entity e1 navigation 0.3 reason "before save"'
            parsed = router.parse(cmd)
            api.execute(parsed)
            
            # Save
            cmd = "save as test.json"
            parsed = router.parse(cmd)
            response = api.execute(parsed)
            assert response.success, f"Save failed: {response.error}"
            
            # Modify state
            cmd = 'teach entity e1 navigation 0.5 reason "after save"'
            parsed = router.parse(cmd)
            api.execute(parsed)
            
            # Verify modified
            value_before_load = learning_mgr.get_skill("e1", "navigation")
            assert value_before_load == 0.8, f"Expected 0.8, got {value_before_load}"
            
            # Load
            cmd = "load from test.json"
            parsed = router.parse(cmd)
            response = api.execute(parsed)
            assert response.success, f"Load failed: {response.error}"
            
            # Verify restored
            value_after_load = learning_mgr.get_skill("e1", "navigation")
            assert value_after_load == 0.3, f"Expected 0.3, got {value_after_load}"
            
            result.passed = True
            result.message = "Save and load work via interface"
            
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_7_start_scenario() -> TestResult:
    """Test 7: Start scenario initializes entities."""
    result = TestResult("7 - Start Scenario")
    
    try:
        config = get_test_config()
        learning_mgr = create_test_learning_manager()
        
        api = InterfaceAPI(
            learning_manager=learning_mgr,
            resolved_config=config
        )
        router = CommandRouter()
        
        # Initially no entities
        assert len(api._entities) == 0, "Should have no entities initially"
        
        # Start scenario
        cmd = "start scenario test_scenario"
        parsed = router.parse(cmd)
        response = api.execute(parsed)
        
        assert response.success, f"Start failed: {response.error}"
        assert api._running, "Should be running"
        assert len(api._entities) == 1, "Should have 1 entity"
        assert "e1" in api._entities, "Should have entity e1"
        
        result.passed = True
        result.message = "Start scenario initializes entities correctly"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_8_plate_safety() -> TestResult:
    """Test 8: Plates remain unchanged after interface operations."""
    result = TestResult("8 - Plate Safety")
    
    try:
        config = get_test_config()
        original_checksum = config.checksum
        original_world_id = config.world_config.world_id
        
        learning_mgr = create_test_learning_manager()
        api = InterfaceAPI(
            learning_manager=learning_mgr,
            resolved_config=config
        )
        router = CommandRouter()
        
        # Execute many commands
        commands = [
            "show world",
            "start scenario test_scenario",
            'teach entity e1 navigation 0.5 reason "test"',
            "tick 10",
            "stop scenario",
        ]
        
        for cmd in commands:
            parsed = router.parse(cmd)
            api.execute(parsed)
        
        # Verify plates unchanged
        config_after = get_test_config()
        assert config_after.checksum == original_checksum, "Plate checksum changed!"
        assert config_after.world_config.world_id == original_world_id, "World ID changed!"
        
        result.passed = True
        result.message = "Plates remain unchanged after interface operations"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_9_repl_execute_commands() -> TestResult:
    """Test 9: REPL executes commands correctly."""
    result = TestResult("9 - REPL Execute Commands")
    
    try:
        config = get_test_config()
        learning_mgr = create_test_learning_manager()
        
        repl = create_repl(
            learning_manager=learning_mgr,
            resolved_config=config
        )
        
        commands = [
            "show status",
            "start scenario test_scenario",
            "show entities",
        ]
        
        responses = repl.execute_commands(commands)
        
        assert len(responses) == 3, f"Expected 3 responses, got {len(responses)}"
        assert all(r.success for r in responses), "Some commands failed"
        
        result.passed = True
        result.message = "REPL executes commands correctly"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


# =============================================================================
# MAIN
# =============================================================================

def main():
    print()
    print("=" * 70)
    print("🧪 PHASE 16 × ENGINE V12 — INTERFACE ACCEPTANCE TESTS")
    print("=" * 70)
    print(f"Engine Version: {ENGINE_VERSION}")
    print(f"Timestamp: {datetime.now(timezone.utc).isoformat()}")
    print("-" * 70)
    print()
    
    # Run all tests
    tests = [
        run_test_1_read_commands_no_mutation,
        run_test_2_teach_updates_learning,
        run_test_3_invalid_commands_fail_early,
        run_test_4_engine_errors_propagate,
        run_test_5_determinism,
        run_test_6_save_load_via_interface,
        run_test_7_start_scenario,
        run_test_8_plate_safety,
        run_test_9_repl_execute_commands,
    ]
    
    results = []
    for test in tests:
        test_result = test()
        results.append(test_result)
        print(test_result)
        print()
    
    # Summary
    print("-" * 70)
    passed = sum(1 for r in results if r.passed)
    total = len(results)
    
    print(f"RESULTS: {passed}/{total} tests passed")
    print()
    
    # Verdict
    if passed == total:
        print("=" * 70)
        print("✅ Phase 16 interface layer verified.")
        print("✅ Read commands do not mutate state.")
        print("✅ Write commands update correctly.")
        print("✅ Plates remain immutable.")
        print("✅ Determinism holds.")
        print("=" * 70)
        return 0
    else:
        print("=" * 70)
        print("❌ Some tests failed. Review required.")
        print("=" * 70)
        return 1


if __name__ == "__main__":
    sys.exit(main())

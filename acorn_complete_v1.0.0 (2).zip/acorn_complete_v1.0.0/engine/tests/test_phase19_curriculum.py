"""Phase 19 × Engine V12 — Curriculum Acceptance Tests

Tests:
1. Schema validation fails on missing required fields
2. additionalProperties rejected
3. Curriculum fails if lesson_id is missing
4. Deterministic ordering (lessons executed in correct order)
5. Dry-run does not mutate learning state
6. Live-run mutates learning state ONLY through teaching pathway
7. Failure halts curriculum and produces report
8. Report shape is stable
"""

import sys
from pathlib import Path
from datetime import datetime, timezone
import json

# Ensure we're testing the actual engine
ENGINE_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ENGINE_ROOT))

# Import from real engine
from engine.phase13_boot import validate_plate_stack, ENGINE_VERSION
from engine.learning import LearningManager, create_skill_envelope
from engine.interface import InterfaceAPI, CommandRouter
from engine.curriculum import (
    LessonStore, CurriculumStore,
    load_lesson, load_curriculum,
    CurriculumRunner, create_runner,
    SchemaError, SemanticError,
    RunMode, RunStatus, LessonStatus
)


# =============================================================================
# TEST FIXTURES
# =============================================================================

def make_world_plate():
    """Create valid WORLD plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "world-001",
        "plate_type": "WORLD",
        "name": "Test World",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "world.test.v0",
        "created_at": "2026-01-24T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/world.json"},
        "content": {
            "world_id": "test_world",
            "topology": {"mode": "graph"},
            "regions": [
                {"region_id": "r0", "name": "Spawn"},
                {"region_id": "r1", "name": "Zone A"}
            ],
            "connections": [{"from": "r0", "to": "r1"}],
            "constraints": {"max_entities": 100}
        }
    }


def make_entity_plate():
    """Create valid ENTITY plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "entity-001",
        "plate_type": "ENTITY",
        "name": "Test Entities",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "entities.test.v0",
        "created_at": "2026-01-24T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/entities.json"},
        "content": {
            "entity_templates": [
                {
                    "template_id": "basic_entity",
                    "name": "Basic Entity",
                    "traits": {"speed": 1.0},
                    "capabilities": ["move", "observe"]
                }
            ]
        }
    }


def make_scenario_plate():
    """Create valid SCENARIO plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "scenario-001",
        "plate_type": "SCENARIO",
        "name": "Test Scenario",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "scenario.test.v0",
        "created_at": "2026-01-24T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/scenario.json"},
        "content": {
            "scenario_id": "test_scenario",
            "world_ref": "test_world",
            "initial_entities": [
                {
                    "entity_id": "e1",
                    "template_id": "basic_entity",
                    "region_id": "r0",
                    "state": {}
                }
            ],
            "parameters": {"ticks": 0}
        }
    }


def get_test_config():
    """Get resolved config for test plates."""
    return validate_plate_stack([
        make_world_plate(),
        make_entity_plate(),
        make_scenario_plate()
    ])


def create_test_api():
    """Create test API with curriculum support."""
    config = get_test_config()
    learning_mgr = LearningManager()
    learning_mgr.register_envelope("navigation", create_skill_envelope(0.0, 1.0, 0.05))
    learning_mgr.register_envelope("perception", create_skill_envelope(0.0, 1.0, 0.05))
    
    lesson_store = LessonStore()
    curriculum_store = CurriculumStore()
    
    api = InterfaceAPI(
        learning_manager=learning_mgr,
        resolved_config=config,
        lesson_store=lesson_store,
        curriculum_store=curriculum_store
    )
    
    # Initialize entity
    api._entities["e1"] = {
        "entity_id": "e1",
        "template_id": "basic_entity",
        "region_id": "r0"
    }
    
    return api, learning_mgr, lesson_store, curriculum_store


def create_valid_lesson(lesson_id: str, delta: float = 0.1):
    """Create a valid lesson data dict."""
    return {
        "lesson_id": lesson_id,
        "target_entity": "e1",
        "skill": "navigation",
        "delta": delta,
        "reason": f"Test lesson {lesson_id}"
    }


def create_valid_curriculum(curriculum_id: str, lesson_ids: list):
    """Create a valid curriculum data dict."""
    return {
        "curriculum_id": curriculum_id,
        "lessons": lesson_ids
    }


# =============================================================================
# TEST EXECUTION
# =============================================================================

class TestResult:
    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.message = ""
        self.error = None
    
    def __str__(self):
        status = "✅ PASS" if self.passed else "❌ FAIL"
        result = f"{status} | Test {self.name}: {self.message}"
        if self.error:
            result += f"\n         Error: {self.error}"
        return result


def run_test_1_schema_missing_required() -> TestResult:
    """Test 1: Schema validation fails on missing required fields."""
    result = TestResult("1 - Schema Missing Required Fields")
    
    try:
        # Missing lesson_id
        invalid_lesson = {
            "target_entity": "e1",
            "skill": "navigation",
            "delta": 0.1,
            "reason": "test"
        }
        
        try:
            load_lesson(invalid_lesson)
            result.message = "Should have raised SchemaError"
            return result
        except SchemaError as e:
            assert "lesson_id" in str(e), "Error should mention lesson_id"
        
        # Missing curriculum_id
        invalid_curriculum = {
            "lessons": ["l1"]
        }
        
        try:
            load_curriculum(invalid_curriculum)
            result.message = "Should have raised SchemaError"
            return result
        except SchemaError as e:
            assert "curriculum_id" in str(e), "Error should mention curriculum_id"
        
        result.passed = True
        result.message = "Schema validation correctly rejects missing required fields"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_2_additional_properties_rejected() -> TestResult:
    """Test 2: additionalProperties rejected."""
    result = TestResult("2 - Additional Properties Rejected")
    
    try:
        # Lesson with extra field
        invalid_lesson = {
            "lesson_id": "l1",
            "target_entity": "e1",
            "skill": "navigation",
            "delta": 0.1,
            "reason": "test",
            "extra_field": "should fail"
        }
        
        try:
            load_lesson(invalid_lesson)
            result.message = "Should have raised SchemaError for extra field"
            return result
        except SchemaError as e:
            assert "extra_field" in str(e), "Error should mention extra_field"
        
        # Curriculum with extra field
        invalid_curriculum = {
            "curriculum_id": "c1",
            "lessons": ["l1"],
            "forbidden_field": "bad"
        }
        
        try:
            load_curriculum(invalid_curriculum)
            result.message = "Should have raised SchemaError for extra field"
            return result
        except SchemaError as e:
            assert "forbidden_field" in str(e), "Error should mention forbidden_field"
        
        result.passed = True
        result.message = "Additional properties correctly rejected"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_3_curriculum_missing_lesson() -> TestResult:
    """Test 3: Curriculum fails if lesson_id is missing from store."""
    result = TestResult("3 - Curriculum Missing Lesson")
    
    try:
        api, learning_mgr, lesson_store, curriculum_store = create_test_api()
        
        # Add curriculum referencing non-existent lesson
        curriculum = load_curriculum({
            "curriculum_id": "c1",
            "lessons": ["missing_lesson"]
        })
        curriculum_store.add(curriculum)
        
        # Create runner and try to run
        runner = create_runner(api, lesson_store, curriculum_store)
        report = runner.run("c1", dry=True)
        
        assert report.status == RunStatus.FAIL, "Should fail for missing lesson"
        assert "missing_lesson" in report.error, "Error should mention missing lesson"
        
        result.passed = True
        result.message = "Curriculum correctly fails when lesson is missing"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_4_deterministic_ordering() -> TestResult:
    """Test 4: Lessons execute in correct order."""
    result = TestResult("4 - Deterministic Ordering")
    
    try:
        api, learning_mgr, lesson_store, curriculum_store = create_test_api()
        
        # Create lessons with increasing deltas
        for i in range(5):
            lesson = load_lesson(create_valid_lesson(f"l{i}", delta=0.05))
            lesson_store.add(lesson)
        
        # Create curriculum with specific order
        curriculum = load_curriculum({
            "curriculum_id": "c1",
            "lessons": ["l0", "l1", "l2", "l3", "l4"]
        })
        curriculum_store.add(curriculum)
        
        # Run curriculum
        runner = create_runner(api, lesson_store, curriculum_store)
        report = runner.run("c1", dry=False)
        
        assert report.status == RunStatus.PASS, "Should succeed"
        assert len(report.lesson_results) == 5, "Should have 5 results"
        
        # Verify order
        for i, lr in enumerate(report.lesson_results):
            assert lr.lesson_id == f"l{i}", f"Order mismatch at {i}"
        
        result.passed = True
        result.message = "Lessons executed in correct deterministic order"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_5_dry_run_no_mutation() -> TestResult:
    """Test 5: Dry-run does not mutate learning state."""
    result = TestResult("5 - Dry Run No Mutation")
    
    try:
        api, learning_mgr, lesson_store, curriculum_store = create_test_api()
        
        # Record initial state
        initial_state = learning_mgr.get_state_dict()
        
        # Add lessons and curriculum
        lesson = load_lesson(create_valid_lesson("l1", delta=0.5))
        lesson_store.add(lesson)
        
        curriculum = load_curriculum({
            "curriculum_id": "c1",
            "lessons": ["l1"]
        })
        curriculum_store.add(curriculum)
        
        # Dry run
        runner = create_runner(api, lesson_store, curriculum_store)
        report = runner.run("c1", dry=True)
        
        # Verify state unchanged
        final_state = learning_mgr.get_state_dict()
        assert initial_state == final_state, "Learning state should not change during dry run"
        
        result.passed = True
        result.message = "Dry-run does not mutate learning state"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_6_live_run_uses_teaching_pathway() -> TestResult:
    """Test 6: Live-run mutates state through teaching pathway."""
    result = TestResult("6 - Live Run Uses Teaching Pathway")
    
    try:
        api, learning_mgr, lesson_store, curriculum_store = create_test_api()
        
        # Add lesson
        lesson = load_lesson(create_valid_lesson("l1", delta=0.1))
        lesson_store.add(lesson)
        
        curriculum = load_curriculum({
            "curriculum_id": "c1",
            "lessons": ["l1"]
        })
        curriculum_store.add(curriculum)
        
        # Check initial state
        initial_value = learning_mgr.get_skill("e1", "navigation")
        assert initial_value is None or initial_value == 0.0, "Should start at 0"
        
        # Live run
        runner = create_runner(api, lesson_store, curriculum_store)
        report = runner.run("c1", dry=False)
        
        assert report.status == RunStatus.PASS, "Should succeed"
        
        # Verify state changed via teaching
        final_value = learning_mgr.get_skill("e1", "navigation")
        
        # Value should be clamped delta (0.05 per event due to envelope)
        assert final_value is not None, "Skill should be set"
        assert final_value > 0, "Skill should have increased"
        
        # Check history for teaching event
        history = learning_mgr.get_history("e1")
        assert len(history) > 0, "Should have history"
        
        result.passed = True
        result.message = "Live-run correctly mutates state through teaching pathway"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_7_failure_halts_curriculum() -> TestResult:
    """Test 7: Failure halts curriculum and produces report."""
    result = TestResult("7 - Failure Halts Curriculum")
    
    try:
        api, learning_mgr, lesson_store, curriculum_store = create_test_api()
        
        # Create lessons - second one targets non-existent skill
        lesson1 = load_lesson(create_valid_lesson("l1", delta=0.1))
        lesson_store.add(lesson1)
        
        # Lesson with precondition that won't be met
        lesson2_data = {
            "lesson_id": "l2",
            "target_entity": "e1",
            "skill": "navigation",
            "delta": 0.1,
            "reason": "test",
            "preconditions": {
                "min_value": 0.9,  # Won't be met
                "max_value": 1.0
            }
        }
        lesson2 = load_lesson(lesson2_data)
        lesson_store.add(lesson2)
        
        lesson3 = load_lesson(create_valid_lesson("l3", delta=0.1))
        lesson_store.add(lesson3)
        
        curriculum = load_curriculum({
            "curriculum_id": "c1",
            "lessons": ["l1", "l2", "l3"]
        })
        curriculum_store.add(curriculum)
        
        # Run curriculum
        runner = create_runner(api, lesson_store, curriculum_store)
        report = runner.run("c1", dry=False)
        
        # Should fail at l2
        assert report.status == RunStatus.FAIL, "Should fail"
        assert report.lessons_executed == 1, "Should only execute first lesson"
        
        # l3 should not have been attempted
        lesson_ids = [lr.lesson_id for lr in report.lesson_results]
        assert "l3" not in lesson_ids or report.lesson_results[-1].status != LessonStatus.PASS, \
            "l3 should not have passed"
        
        result.passed = True
        result.message = "Failure correctly halts curriculum"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_8_report_shape_stable() -> TestResult:
    """Test 8: Report shape is stable."""
    result = TestResult("8 - Report Shape Stable")
    
    try:
        api, learning_mgr, lesson_store, curriculum_store = create_test_api()
        
        # Add lesson and curriculum
        lesson = load_lesson(create_valid_lesson("l1", delta=0.1))
        lesson_store.add(lesson)
        
        curriculum = load_curriculum({
            "curriculum_id": "c1",
            "lessons": ["l1"]
        })
        curriculum_store.add(curriculum)
        
        # Run multiple times
        runner = create_runner(api, lesson_store, curriculum_store)
        
        # Reset between runs
        learning_mgr.reset_entity("e1")
        report1 = runner.run("c1", dry=True)
        
        learning_mgr.reset_entity("e1")
        report2 = runner.run("c1", dry=True)
        
        # Verify report shape
        dict1 = report1.to_dict()
        dict2 = report2.to_dict()
        
        # Keys should match
        assert set(dict1.keys()) == set(dict2.keys()), "Report keys should match"
        
        # Required fields present
        required_fields = [
            "curriculum_id", "mode", "started", "completed",
            "status", "lessons_executed", "lesson_results"
        ]
        for field in required_fields:
            assert field in dict1, f"Report missing field: {field}"
        
        # Lesson result shape
        for lr in dict1["lesson_results"]:
            assert "lesson_id" in lr
            assert "target_entity" in lr
            assert "skill" in lr
            assert "delta" in lr
            assert "status" in lr
        
        result.passed = True
        result.message = "Report shape is stable and complete"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


# =============================================================================
# MAIN
# =============================================================================

def main():
    print()
    print("=" * 70)
    print("🧪 PHASE 19 × ENGINE V12 — CURRICULUM ACCEPTANCE TESTS")
    print("=" * 70)
    print(f"Engine Version: {ENGINE_VERSION}")
    print(f"Timestamp: {datetime.now(timezone.utc).isoformat()}")
    print("-" * 70)
    print()
    
    # Run all tests
    tests = [
        run_test_1_schema_missing_required,
        run_test_2_additional_properties_rejected,
        run_test_3_curriculum_missing_lesson,
        run_test_4_deterministic_ordering,
        run_test_5_dry_run_no_mutation,
        run_test_6_live_run_uses_teaching_pathway,
        run_test_7_failure_halts_curriculum,
        run_test_8_report_shape_stable,
    ]
    
    results = []
    for test in tests:
        test_result = test()
        results.append(test_result)
        print(test_result)
        print()
    
    # Summary
    print("-" * 70)
    passed = sum(1 for r in results if r.passed)
    total = len(results)
    
    print(f"RESULTS: {passed}/{total} tests passed")
    print()
    
    # Verdict
    if passed == total:
        print("=" * 70)
        print("✅ Phase 19 curriculum system verified.")
        print("✅ Schema validation works correctly.")
        print("✅ Deterministic execution confirmed.")
        print("✅ Teaching pathway enforced.")
        print("✅ Report structure stable.")
        print("=" * 70)
        return 0
    else:
        print("=" * 70)
        print("❌ Some tests failed. Review required.")
        print("=" * 70)
        return 1


if __name__ == "__main__":
    sys.exit(main())

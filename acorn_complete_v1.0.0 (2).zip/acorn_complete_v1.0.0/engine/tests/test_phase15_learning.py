"""Phase 15 × Engine V12 — Learning Acceptance Tests

Tests:
1. Learning Persistence — Teach → save → load → learning identical
2. Envelope Enforcement — Excessive teaching clamps correctly
3. Determinism — Identical teaching sequence → identical learning
4. Plate Safety — No plate files modified, no rule changes
"""

import sys
import os
import tempfile
from pathlib import Path
from datetime import datetime, timezone
from copy import deepcopy

# Ensure we're testing the actual v12 engine
ENGINE_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ENGINE_ROOT))

# Import from real v12 engine
from engine.phase13_boot import validate_plate_stack, ENGINE_VERSION
from engine.save import SaveManager, create_runtime_state
from engine.learning import (
    LearningManager,
    LearningState,
    SkillEnvelope,
    SkillUpdateEvent,
    MetricIncrementEvent,
    HistoryAppendEvent,
    create_skill_envelope,
    create_default_envelopes,
    HISTORY_MAX_LENGTH
)


# =============================================================================
# TEST FIXTURES
# =============================================================================

def make_world_plate():
    """Create valid WORLD plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "world-001",
        "plate_type": "WORLD",
        "name": "Test World",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "world.test.v0",
        "created_at": "2026-01-23T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/world.json"},
        "content": {
            "world_id": "test_world",
            "topology": {"mode": "graph"},
            "regions": [
                {"region_id": "r0", "name": "Spawn"},
                {"region_id": "r1", "name": "Zone A"}
            ],
            "connections": [{"from": "r0", "to": "r1"}],
            "constraints": {"max_entities": 100}
        }
    }


def make_entity_plate():
    """Create valid ENTITY plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "entity-001",
        "plate_type": "ENTITY",
        "name": "Test Entities",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "entities.test.v0",
        "created_at": "2026-01-23T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/entities.json"},
        "content": {
            "entity_templates": [
                {
                    "template_id": "basic_entity",
                    "name": "Basic Entity",
                    "traits": {"speed": 1.0},
                    "capabilities": ["move", "observe"]
                }
            ]
        }
    }


def get_test_config():
    """Get resolved config for test plates."""
    return validate_plate_stack([make_world_plate(), make_entity_plate()])


def create_learning_manager_with_envelopes() -> LearningManager:
    """Create learning manager with default envelopes."""
    manager = LearningManager()
    for skill, envelope in create_default_envelopes().items():
        manager.register_envelope(skill, envelope)
    return manager


# =============================================================================
# TEST EXECUTION
# =============================================================================

class TestResult:
    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.message = ""
        self.error = None
    
    def __str__(self):
        status = "✅ PASS" if self.passed else "❌ FAIL"
        result = f"{status} | Test {self.name}: {self.message}"
        if self.error:
            result += f"\n         Error: {self.error}"
        return result


def run_test_1_learning_persistence() -> TestResult:
    """Test 1: Learning Persistence — Teach → save → load → learning identical."""
    result = TestResult("1 - Learning Persistence")
    
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "test_save.json"
            
            # Get plate config
            config = get_test_config()
            
            # Create learning manager
            manager = create_learning_manager_with_envelopes()
            
            # Apply teaching events
            manager.apply_teaching_event(SkillUpdateEvent(
                entity_id="e1", tick=100, skill="navigation", delta=0.15
            ))
            manager.apply_teaching_event(MetricIncrementEvent(
                entity_id="e1", tick=100, metric="attempts", amount=1
            ))
            manager.apply_teaching_event(HistoryAppendEvent(
                entity_id="e1", tick=100, event_name="training_session"
            ))
            
            # Capture learning state
            learning_before = manager.get_state_dict()
            
            # Create runtime state with learning
            runtime_state = create_runtime_state(
                world_state={"counter": 42},
                entities={"e1": {"health": 100}},
                systems={"learning": learning_before}
            )
            
            # Save
            save_mgr = SaveManager.from_resolved_config(config)
            save_mgr.save_state(save_path, tick=100, state=runtime_state)
            
            # Load
            loaded = save_mgr.load_state(save_path)
            
            # Restore learning state
            manager2 = create_learning_manager_with_envelopes()
            learning_after = loaded.state.systems.get("learning", {})
            manager2.load_state_dict(learning_after)
            
            # Compare
            assert manager.get_skill("e1", "navigation") == manager2.get_skill("e1", "navigation"), \
                "Navigation skill mismatch"
            assert manager.get_metric("e1", "attempts") == manager2.get_metric("e1", "attempts"), \
                "Attempts metric mismatch"
            assert len(manager.get_history("e1")) == len(manager2.get_history("e1")), \
                "History length mismatch"
            
            result.passed = True
            result.message = "Learning state identical after save/load"
            
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_2_envelope_enforcement() -> TestResult:
    """Test 2: Envelope Enforcement — Excessive teaching clamps correctly."""
    result = TestResult("2 - Envelope Enforcement")
    
    try:
        manager = LearningManager()
        
        # Register envelope: min=0.0, max=1.0, delta=0.1
        manager.register_envelope("navigation", SkillEnvelope(
            min=0.0, max=1.0, delta_per_event=0.1
        ))
        
        # Apply excessive positive delta
        for i in range(20):  # 20 * 0.5 = 10.0, way over max
            manager.apply_teaching_event(SkillUpdateEvent(
                entity_id="e1", tick=i, skill="navigation", delta=0.5
            ))
        
        # Check clamped to max
        skill_value = manager.get_skill("e1", "navigation")
        assert skill_value == 1.0, f"Expected 1.0 (max), got {skill_value}"
        
        # Apply excessive negative delta
        for i in range(30):  # 30 * -0.5 = -15.0, way under min
            manager.apply_teaching_event(SkillUpdateEvent(
                entity_id="e1", tick=100 + i, skill="navigation", delta=-0.5
            ))
        
        # Check clamped to min
        skill_value = manager.get_skill("e1", "navigation")
        assert skill_value == 0.0, f"Expected 0.0 (min), got {skill_value}"
        
        result.passed = True
        result.message = "Envelope clamping works correctly (no errors on overflow)"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_3_determinism() -> TestResult:
    """Test 3: Determinism — Identical teaching sequence → identical learning."""
    result = TestResult("3 - Determinism")
    
    try:
        # Create identical teaching sequence
        def apply_teaching_sequence(manager: LearningManager):
            for i in range(10):
                manager.apply_teaching_event(SkillUpdateEvent(
                    entity_id="e1", tick=i * 10, skill="navigation", delta=0.05
                ))
                manager.apply_teaching_event(MetricIncrementEvent(
                    entity_id="e1", tick=i * 10, metric="steps", amount=1
                ))
                manager.apply_teaching_event(HistoryAppendEvent(
                    entity_id="e1", tick=i * 10, event_name=f"step_{i}"
                ))
        
        # Apply to two independent managers
        manager1 = create_learning_manager_with_envelopes()
        manager2 = create_learning_manager_with_envelopes()
        
        apply_teaching_sequence(manager1)
        apply_teaching_sequence(manager2)
        
        # Compare state dictionaries
        state1 = manager1.get_state_dict()
        state2 = manager2.get_state_dict()
        
        # Compare skills
        assert state1["entities"]["e1"]["skills"] == state2["entities"]["e1"]["skills"], \
            "Skills differ"
        
        # Compare metrics
        assert state1["entities"]["e1"]["metrics"] == state2["entities"]["e1"]["metrics"], \
            "Metrics differ"
        
        # Compare history
        hist1 = state1["entities"]["e1"]["history"]
        hist2 = state2["entities"]["e1"]["history"]
        assert len(hist1) == len(hist2), "History length differs"
        for h1, h2 in zip(hist1, hist2):
            assert h1["tick"] == h2["tick"], "History tick differs"
            assert h1["event"] == h2["event"], "History event differs"
        
        result.passed = True
        result.message = "Identical teaching → identical learning state"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_4_plate_safety() -> TestResult:
    """Test 4: Plate Safety — No plate files modified, no rule changes."""
    result = TestResult("4 - Plate Safety")
    
    try:
        # Get plate config BEFORE learning
        config_before = get_test_config()
        checksum_before = config_before.checksum
        world_id_before = config_before.world_config.world_id
        template_ids_before = set(config_before.entity_templates.keys())
        
        # Create manager and apply extensive teaching
        manager = create_learning_manager_with_envelopes()
        
        for i in range(100):
            manager.apply_teaching_event(SkillUpdateEvent(
                entity_id=f"e{i % 5}", tick=i, skill="navigation", delta=0.01
            ))
            manager.apply_teaching_event(MetricIncrementEvent(
                entity_id=f"e{i % 5}", tick=i, metric="actions", amount=1
            ))
        
        # Get plate config AFTER learning
        config_after = get_test_config()
        
        # Verify plates unchanged
        assert config_after.checksum == checksum_before, "Plate checksum changed!"
        assert config_after.world_config.world_id == world_id_before, "World ID changed!"
        assert set(config_after.entity_templates.keys()) == template_ids_before, "Templates changed!"
        
        # Verify config is still immutable
        try:
            config_after.checksum = "tampered"
            result.error = "Config mutation allowed"
            return result
        except AttributeError:
            pass  # Expected
        
        # Verify learning state is separate
        learning_state = manager.get_state_dict()
        assert "entities" in learning_state, "Learning has no entities"
        assert "version" in learning_state, "Learning has no version"
        
        # Verify learning state does NOT contain plate data
        assert "world_id" not in str(learning_state), "Learning contains world_id"
        assert "template_id" not in str(learning_state), "Learning contains template_id"
        
        result.passed = True
        result.message = "Plates remain immutable, learning is isolated"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_5_history_fifo_eviction() -> TestResult:
    """Test 5: History FIFO Eviction — Max 100 entries, oldest evicted first."""
    result = TestResult("5 - History FIFO Eviction")
    
    try:
        manager = LearningManager()
        
        # Add 150 history entries
        for i in range(150):
            manager.apply_teaching_event(HistoryAppendEvent(
                entity_id="e1", tick=i, event_name=f"event_{i}"
            ))
        
        # Check length is capped at 100
        history = manager.get_history("e1")
        assert len(history) == HISTORY_MAX_LENGTH, \
            f"Expected {HISTORY_MAX_LENGTH} entries, got {len(history)}"
        
        # Check oldest entries were evicted (entries 0-49 gone, 50-149 remain)
        assert history[0].event == "event_50", \
            f"Expected first entry 'event_50', got '{history[0].event}'"
        assert history[-1].event == "event_149", \
            f"Expected last entry 'event_149', got '{history[-1].event}'"
        
        result.passed = True
        result.message = f"History capped at {HISTORY_MAX_LENGTH}, FIFO eviction verified"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_6_reset_functionality() -> TestResult:
    """Test 6: Reset Functionality — Entity and full reset work correctly."""
    result = TestResult("6 - Reset Functionality")
    
    try:
        manager = create_learning_manager_with_envelopes()
        
        # Teach multiple entities
        for entity in ["e1", "e2", "e3"]:
            manager.apply_teaching_event(SkillUpdateEvent(
                entity_id=entity, tick=100, skill="navigation", delta=0.3
            ))
        
        # Verify all have learning
        assert manager.get_skill("e1", "navigation") > 0
        assert manager.get_skill("e2", "navigation") > 0
        assert manager.get_skill("e3", "navigation") > 0
        
        # Reset single entity
        manager.reset_entity("e1")
        assert manager.get_skill("e1", "navigation") == 0.0, "e1 not reset"
        assert manager.get_skill("e2", "navigation") > 0, "e2 incorrectly reset"
        
        # Reset all
        manager.reset_all()
        assert manager.get_skill("e2", "navigation") == 0.0, "e2 not reset"
        assert manager.get_skill("e3", "navigation") == 0.0, "e3 not reset"
        
        result.passed = True
        result.message = "Reset functionality works correctly"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_7_teaching_validation() -> TestResult:
    """Test 7: Teaching Validation — Invalid events fail properly."""
    result = TestResult("7 - Teaching Validation")
    
    try:
        from engine.learning import LearningTeachingError
        
        manager = LearningManager()
        errors_caught = 0
        
        # Test 1: Empty entity_id
        try:
            manager.apply_teaching_event(SkillUpdateEvent(
                entity_id="", tick=100, skill="navigation", delta=0.1
            ))
        except LearningTeachingError:
            errors_caught += 1
        
        # Test 2: Negative tick
        try:
            manager.apply_teaching_event(SkillUpdateEvent(
                entity_id="e1", tick=-1, skill="navigation", delta=0.1
            ))
        except LearningTeachingError:
            errors_caught += 1
        
        # Test 3: Empty skill name
        try:
            manager.apply_teaching_event(SkillUpdateEvent(
                entity_id="e1", tick=100, skill="", delta=0.1
            ))
        except LearningTeachingError:
            errors_caught += 1
        
        # Test 4: Empty metric name
        try:
            manager.apply_teaching_event(MetricIncrementEvent(
                entity_id="e1", tick=100, metric="", amount=1
            ))
        except LearningTeachingError:
            errors_caught += 1
        
        # Test 5: Empty event name
        try:
            manager.apply_teaching_event(HistoryAppendEvent(
                entity_id="e1", tick=100, event_name=""
            ))
        except LearningTeachingError:
            errors_caught += 1
        
        assert errors_caught == 5, f"Expected 5 validation errors, caught {errors_caught}"
        
        result.passed = True
        result.message = "Invalid teaching events properly rejected"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_8_unbounded_skills() -> TestResult:
    """Test 8: Unbounded Skills — Skills without envelopes are unrestricted."""
    result = TestResult("8 - Unbounded Skills")
    
    try:
        manager = LearningManager()  # No envelopes registered
        
        # Apply large positive delta
        manager.apply_teaching_event(SkillUpdateEvent(
            entity_id="e1", tick=100, skill="custom_skill", delta=1000.0
        ))
        
        skill_value = manager.get_skill("e1", "custom_skill")
        assert skill_value == 1000.0, f"Expected 1000.0, got {skill_value}"
        
        # Apply large negative delta
        manager.apply_teaching_event(SkillUpdateEvent(
            entity_id="e1", tick=101, skill="custom_skill", delta=-2000.0
        ))
        
        skill_value = manager.get_skill("e1", "custom_skill")
        assert skill_value == -1000.0, f"Expected -1000.0, got {skill_value}"
        
        result.passed = True
        result.message = "Unbounded skills allow unrestricted values"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


# =============================================================================
# MAIN
# =============================================================================

def main():
    print()
    print("=" * 70)
    print("🧪 PHASE 15 × ENGINE V12 — LEARNING ACCEPTANCE TESTS")
    print("=" * 70)
    print(f"Engine Version: {ENGINE_VERSION}")
    print(f"Timestamp: {datetime.now(timezone.utc).isoformat()}")
    print("-" * 70)
    print()
    
    # Run all tests
    tests = [
        run_test_1_learning_persistence,
        run_test_2_envelope_enforcement,
        run_test_3_determinism,
        run_test_4_plate_safety,
        run_test_5_history_fifo_eviction,
        run_test_6_reset_functionality,
        run_test_7_teaching_validation,
        run_test_8_unbounded_skills,
    ]
    
    results = []
    for test in tests:
        test_result = test()
        results.append(test_result)
        print(test_result)
        print()
    
    # Summary
    print("-" * 70)
    passed = sum(1 for r in results if r.passed)
    total = len(results)
    
    print(f"RESULTS: {passed}/{total} tests passed")
    print()
    
    # Verdict
    if passed == total:
        print("=" * 70)
        print("✅ Phase 15 bounded learning verified.")
        print("✅ Plates remain immutable.")
        print("✅ Learning persists correctly via Phase 14 saves.")
        print("✅ Determinism holds.")
        print("=" * 70)
        return 0
    else:
        print("=" * 70)
        print("❌ Some tests failed. Review required.")
        print("=" * 70)
        return 1


if __name__ == "__main__":
    sys.exit(main())

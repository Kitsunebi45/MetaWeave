"""Phase 18 × Engine V12 — Visualization Acceptance Tests

Tests:
1. Visualization does not mutate engine state
2. Adapter consumes only Phase 16 APIs
3. Closing UI leaves engine unchanged
4. Deterministic redraw from identical state
5. No hidden persistent state
"""

import sys
from pathlib import Path
from datetime import datetime, timezone
from io import StringIO

# Ensure we're testing the actual engine
ENGINE_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ENGINE_ROOT))

# Import from real engine
from engine.phase13_boot import validate_plate_stack, ENGINE_VERSION
from engine.save import SaveManager
from engine.learning import LearningManager, create_skill_envelope
from engine.interface import InterfaceAPI, CommandRouter
from engine.visualization import (
    VisualizationAdapter,
    TextRenderer,
    VisualizationApp,
    create_visualization_app,
    WorldView,
    EntityView,
    LearningView,
    RuleView
)


# =============================================================================
# TEST FIXTURES
# =============================================================================

def make_world_plate():
    """Create valid WORLD plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "world-001",
        "plate_type": "WORLD",
        "name": "Test World",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "world.test.v0",
        "created_at": "2026-01-24T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/world.json"},
        "content": {
            "world_id": "test_world",
            "topology": {"mode": "graph"},
            "regions": [
                {"region_id": "r0", "name": "Spawn"},
                {"region_id": "r1", "name": "Zone A"}
            ],
            "connections": [{"from": "r0", "to": "r1"}],
            "constraints": {"max_entities": 100}
        }
    }


def make_entity_plate():
    """Create valid ENTITY plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "entity-001",
        "plate_type": "ENTITY",
        "name": "Test Entities",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "entities.test.v0",
        "created_at": "2026-01-24T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/entities.json"},
        "content": {
            "entity_templates": [
                {
                    "template_id": "basic_entity",
                    "name": "Basic Entity",
                    "traits": {"speed": 1.0},
                    "capabilities": ["move", "observe"]
                }
            ]
        }
    }


def make_scenario_plate():
    """Create valid SCENARIO plate."""
    return {
        "schema_version": "1.0.0",
        "plate_id": "scenario-001",
        "plate_type": "SCENARIO",
        "name": "Test Scenario",
        "version": "0.1.0",
        "engine_compat": ">=12.0.0 <13.0.0",
        "resonance_key": "scenario.test.v0",
        "created_at": "2026-01-24T12:00:00Z",
        "tags": ["test"],
        "source": {"author": "test", "source_path": "test/scenario.json"},
        "content": {
            "scenario_id": "test_scenario",
            "world_ref": "test_world",
            "initial_entities": [
                {
                    "entity_id": "e1",
                    "template_id": "basic_entity",
                    "region_id": "r0",
                    "state": {}
                }
            ],
            "parameters": {"ticks": 0}
        }
    }


def get_test_config():
    """Get resolved config for test plates."""
    return validate_plate_stack([
        make_world_plate(),
        make_entity_plate(),
        make_scenario_plate()
    ])


def create_test_api():
    """Create test API with learning manager."""
    config = get_test_config()
    learning_mgr = LearningManager()
    learning_mgr.register_envelope("navigation", create_skill_envelope(0.0, 1.0, 0.05))
    
    api = InterfaceAPI(
        learning_manager=learning_mgr,
        resolved_config=config
    )
    
    return api, learning_mgr, config


# =============================================================================
# TEST EXECUTION
# =============================================================================

class TestResult:
    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.message = ""
        self.error = None
    
    def __str__(self):
        status = "✅ PASS" if self.passed else "❌ FAIL"
        result = f"{status} | Test {self.name}: {self.message}"
        if self.error:
            result += f"\n         Error: {self.error}"
        return result


def run_test_1_no_state_mutation() -> TestResult:
    """Test 1: Visualization does not mutate engine state."""
    result = TestResult("1 - No State Mutation")
    
    try:
        api, learning_mgr, config = create_test_api()
        
        # Record initial state
        initial_tick = api._tick
        initial_entities = dict(api._entities)
        initial_learning = learning_mgr.get_state_dict()
        
        # Create and use visualization
        app = create_visualization_app(api, mode="text")
        
        # Perform multiple refreshes and renders
        for _ in range(5):
            app.refresh()
            app.render_status()
            app.render_world()
            app.render_entities()
            app.render_rules()
            app.render_scenario()
            app.render_full()
        
        # Verify state unchanged
        assert api._tick == initial_tick, "Tick was mutated"
        assert api._entities == initial_entities, "Entities were mutated"
        assert learning_mgr.get_state_dict() == initial_learning, "Learning was mutated"
        
        result.passed = True
        result.message = "Visualization does not mutate engine state"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_2_adapter_uses_phase16_only() -> TestResult:
    """Test 2: Adapter consumes only Phase 16 APIs."""
    result = TestResult("2 - Adapter Uses Phase 16 Only")
    
    try:
        api, learning_mgr, config = create_test_api()
        adapter = VisualizationAdapter(api)
        
        # Adapter should use CommandRouter (Phase 16)
        assert adapter._router is not None, "Adapter should have router"
        assert hasattr(adapter._router, 'parse'), "Router should have parse method"
        
        # Adapter should only call read methods
        # Check that get methods exist and work
        status = adapter.get_status()
        assert status is not None, "get_status should return data"
        
        world = adapter.get_world()
        # World may be None if not properly loaded, that's OK
        
        entities = adapter.get_entities()
        assert entities is not None, "get_entities should return data"
        
        rules = adapter.get_rules()
        # Rules may be None, that's OK
        
        # Verify no write methods exist on adapter
        write_methods = ['set_', 'save_', 'write_', 'teach_', 'modify_']
        for method_name in dir(adapter):
            for prefix in write_methods:
                assert not method_name.startswith(prefix), \
                    f"Adapter has write method: {method_name}"
        
        result.passed = True
        result.message = "Adapter uses Phase 16 read APIs only"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_3_closing_leaves_engine_unchanged() -> TestResult:
    """Test 3: Closing UI leaves engine unchanged."""
    result = TestResult("3 - Closing Leaves Engine Unchanged")
    
    try:
        api, learning_mgr, config = create_test_api()
        
        # Start scenario to have some state
        router = CommandRouter()
        parsed = router.parse("start scenario test_scenario")
        api.execute(parsed)
        
        # Teach something
        from engine.learning import SkillUpdateEvent
        learning_mgr.apply_teaching_event(SkillUpdateEvent(
            entity_id="e1",
            tick=0,
            skill="navigation",
            delta=0.3
        ))
        
        # Record state
        state_before = {
            "tick": api._tick,
            "entities": dict(api._entities),
            "running": api._running,
            "learning": learning_mgr.get_state_dict()
        }
        
        # Create, use, and "close" visualization
        app = create_visualization_app(api, mode="text")
        app.refresh()
        app.render_full()
        
        # Simulate closing (app goes out of scope)
        del app
        
        # Record state after
        state_after = {
            "tick": api._tick,
            "entities": dict(api._entities),
            "running": api._running,
            "learning": learning_mgr.get_state_dict()
        }
        
        # Compare
        assert state_before == state_after, "State changed after closing visualization"
        
        result.passed = True
        result.message = "Closing visualization leaves engine unchanged"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_4_deterministic_redraw() -> TestResult:
    """Test 4: Deterministic redraw from identical state."""
    result = TestResult("4 - Deterministic Redraw")
    
    try:
        api, learning_mgr, config = create_test_api()
        
        # Start scenario
        router = CommandRouter()
        parsed = router.parse("start scenario test_scenario")
        api.execute(parsed)
        
        # Create two separate visualization instances
        app1 = create_visualization_app(api, mode="text")
        app2 = create_visualization_app(api, mode="text")
        
        # Refresh both
        app1.refresh()
        app2.refresh()
        
        # Render same views
        render1_status = app1.render_status()
        render2_status = app2.render_status()
        
        render1_world = app1.render_world()
        render2_world = app2.render_world()
        
        render1_entities = app1.render_entities()
        render2_entities = app2.render_entities()
        
        render1_rules = app1.render_rules()
        render2_rules = app2.render_rules()
        
        # Compare outputs (excluding timestamps)
        # Status view includes tick which should be identical
        assert render1_status == render2_status, "Status renders differ"
        assert render1_world == render2_world, "World renders differ"
        assert render1_entities == render2_entities, "Entity renders differ"
        assert render1_rules == render2_rules, "Rule renders differ"
        
        result.passed = True
        result.message = "Same state produces identical renders"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_5_no_hidden_persistent_state() -> TestResult:
    """Test 5: No hidden persistent state."""
    result = TestResult("5 - No Hidden Persistent State")
    
    try:
        api, learning_mgr, config = create_test_api()
        
        # Create app
        app = create_visualization_app(api, mode="text")
        
        # Check app has no persistent storage
        # Should not have:
        # - File handles
        # - Database connections
        # - Cache directories
        # - State files
        
        # Check internal state
        assert app._snapshot is None, "App should not pre-cache snapshot"
        
        # Refresh and check snapshot is ephemeral
        app.refresh()
        snapshot1 = app._snapshot
        
        # Refresh again
        app.refresh()
        snapshot2 = app._snapshot
        
        # Snapshots should be different objects (not cached)
        assert snapshot1 is not snapshot2, "Snapshots should not be cached"
        
        # Check that deleting app leaves no artifacts
        import gc
        del app
        gc.collect()
        
        # No file artifacts should exist in current directory
        import os
        viz_files = [f for f in os.listdir('.') if 'visualization' in f.lower()]
        viz_files = [f for f in viz_files if not f.endswith('.py')]  # Exclude source
        assert len(viz_files) == 0, f"Found visualization artifacts: {viz_files}"
        
        result.passed = True
        result.message = "No hidden persistent state"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_6_read_only_controls() -> TestResult:
    """Test 6: All views are read-only (no editing controls)."""
    result = TestResult("6 - Read Only Controls")
    
    try:
        renderer = TextRenderer()
        
        # Check views have no edit methods
        world_view = WorldView(renderer)
        entity_view = EntityView(renderer)
        learning_view = LearningView(renderer)
        rule_view = RuleView(renderer)
        
        edit_prefixes = ['set_', 'update_', 'modify_', 'change_', 'edit_', 'write_']
        
        for view in [world_view, entity_view, learning_view, rule_view]:
            view_name = type(view).__name__
            for method_name in dir(view):
                if method_name.startswith('_'):
                    continue
                for prefix in edit_prefixes:
                    assert not method_name.startswith(prefix), \
                        f"{view_name} has edit method: {method_name}"
        
        result.passed = True
        result.message = "All views are read-only"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_7_models_are_immutable() -> TestResult:
    """Test 7: Visualization models are immutable (frozen dataclasses)."""
    result = TestResult("7 - Models Are Immutable")
    
    try:
        from engine.visualization.models import (
            RegionModel, ConnectionModel, WorldModel,
            EntityModel, EntityListModel,
            SkillEnvelopeModel, HistoryEntryModel, LearningModel,
            RuleModel, RuleSetModel,
            ScenarioModel, EngineStatusModel
        )
        
        # Test RegionModel is frozen
        region = RegionModel(region_id="r1", name="Test")
        try:
            region.name = "Modified"
            raise AssertionError("RegionModel should be frozen")
        except AttributeError:
            pass  # Expected - frozen
        
        # Test EntityModel is frozen
        entity = EntityModel(entity_id="e1", template_id=None, region_id=None)
        try:
            entity.region_id = "r2"
            raise AssertionError("EntityModel should be frozen")
        except AttributeError:
            pass  # Expected - frozen
        
        # Test EngineStatusModel is frozen
        status = EngineStatusModel(
            tick=0, running=False, scenario_id=None,
            entity_count=0, config_loaded=False,
            learning_enabled=False, save_enabled=False
        )
        try:
            status.tick = 100
            raise AssertionError("EngineStatusModel should be frozen")
        except AttributeError:
            pass  # Expected - frozen
        
        result.passed = True
        result.message = "All visualization models are immutable"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


def run_test_8_renderer_determinism() -> TestResult:
    """Test 8: Renderer produces deterministic output."""
    result = TestResult("8 - Renderer Determinism")
    
    try:
        from engine.visualization.models import (
            RegionModel, ConnectionModel, WorldModel,
            EntityModel, EntityListModel,
            EngineStatusModel
        )
        
        renderer = TextRenderer(width=80)
        
        # Create identical models
        status = EngineStatusModel(
            tick=1000, running=True, scenario_id="test",
            entity_count=5, config_loaded=True,
            learning_enabled=True, save_enabled=True
        )
        
        # Render multiple times
        output1 = renderer.render_status(status)
        output2 = renderer.render_status(status)
        output3 = renderer.render_status(status)
        
        assert output1 == output2 == output3, "Renderer output varies"
        
        # Test with different data
        world = WorldModel(
            world_id="test",
            topology_mode="graph",
            regions=(
                RegionModel("r1", "Region 1", {}, True, 3),
                RegionModel("r2", "Region 2", {}, False, 0),
            ),
            connections=(
                ConnectionModel("r1", "r2", True),
            )
        )
        
        world_out1 = renderer.render_world(world)
        world_out2 = renderer.render_world(world)
        
        assert world_out1 == world_out2, "World render varies"
        
        result.passed = True
        result.message = "Renderer produces deterministic output"
        
    except Exception as e:
        result.message = "Failed"
        result.error = f"{type(e).__name__}: {e}"
    
    return result


# =============================================================================
# MAIN
# =============================================================================

def main():
    print()
    print("=" * 70)
    print("🧪 PHASE 18 × ENGINE V12 — VISUALIZATION ACCEPTANCE TESTS")
    print("=" * 70)
    print(f"Engine Version: {ENGINE_VERSION}")
    print(f"Timestamp: {datetime.now(timezone.utc).isoformat()}")
    print("-" * 70)
    print()
    
    # Run all tests
    tests = [
        run_test_1_no_state_mutation,
        run_test_2_adapter_uses_phase16_only,
        run_test_3_closing_leaves_engine_unchanged,
        run_test_4_deterministic_redraw,
        run_test_5_no_hidden_persistent_state,
        run_test_6_read_only_controls,
        run_test_7_models_are_immutable,
        run_test_8_renderer_determinism,
    ]
    
    results = []
    for test in tests:
        test_result = test()
        results.append(test_result)
        print(test_result)
        print()
    
    # Summary
    print("-" * 70)
    passed = sum(1 for r in results if r.passed)
    total = len(results)
    
    print(f"RESULTS: {passed}/{total} tests passed")
    print()
    
    # Verdict
    if passed == total:
        print("=" * 70)
        print("✅ Phase 18 visualization layer verified.")
        print("✅ Visualization does not mutate engine state.")
        print("✅ Adapter uses Phase 16 read APIs only.")
        print("✅ All views are read-only.")
        print("✅ Deterministic rendering confirmed.")
        print("=" * 70)
        return 0
    else:
        print("=" * 70)
        print("❌ Some tests failed. Review required.")
        print("=" * 70)
        return 1


if __name__ == "__main__":
    sys.exit(main())

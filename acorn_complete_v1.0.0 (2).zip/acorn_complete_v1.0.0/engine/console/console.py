"""
Console - human-facing interface for engine interaction.
Manages display, input routing, and Local Name.
"""

import sys
from typing import Optional

# Import from Phase 1 (frozen, read-only)
from identity import EngineIdentity

# Import from Phase 2
from .schema import Event, EventCategory
from .packet_router import PacketRouter
from .packet_validator import SchemaViolation
from .output_formatter import OutputFormatter


class Console:
    """
    Human-facing interface for engine interaction.
    Manages display, input routing, and Local Name.
    """
    
    def __init__(self, identity: EngineIdentity, router: PacketRouter):
        """
        Initialize console with injected dependencies.
        
        Args:
            identity: Engine identity (injected by boot)
            router: Packet router (injected by boot)
        """
        # Dependency injection: identity and router provided by boot
        self._identity = identity
        self._router = router

        # ─────────────────────────────────────────────────────────────
        # PHASE 9: Human control layer (no agency transfer)
        # ─────────────────────────────────────────────────────────────
        # Modes: PREVIEW / EXECUTE / PAUSED
        self._mode: str = "EXECUTE"
        self._in_execution: bool = False

        # Intent + Debug/Notes are human-only and MUST NOT influence commands.
        # They are stored only in console memory and are never passed to engine.
        self._intent_log: list[str] = []
        self._debug_notes: list[str] = []

        # Session boundary: cleared on stop or explicit unload.
        self._session_active: bool = True
        
        # Local Name: transient, display-only metadata
        self._local_name: Optional[str] = None
        
        # Console state
        self._running = False
    
    @property
    def local_name(self) -> str:
        """
        Get display name (local name or truncated UUID).
        
        Returns:
            Display name for console prompt
        """
        if self._local_name is None:
            # Default: first 8 characters of engine UUID
            return f"Engine {self._identity.uuid[:8]}"
        return self._local_name
    
    def set_local_name(self, name: str) -> None:
        """
        Set transient local name (display only).
        
        This is metadata ONLY - does not affect:
        - Engine identity (engine_uuid)
        - Memory storage keys
        - Cognition state
        - Packet routing logic
        - Permission checking
        
        Args:
            name: Local name to set (empty to reset to default)
        """
        if not name or not name.strip():
            # Reset to default
            self._local_name = None
        else:
            self._local_name = name.strip()
    
    def start(self) -> None:
        """
        Begin console interaction loop.
        
        This is a simple text-based REPL (Read-Eval-Print Loop).
        """
        self._running = True
        
        # Display welcome message
        print(f"\n{'=' * 70}")
        print(f"Acorn Engine Console")
        print(f"Engine UUID: {self._identity.uuid}")
        print(f"Session ID:  {self._identity.get_session_id()}")
        print(f"Display Name: {self.local_name}")
        print(f"{'=' * 70}\n")
        print("Type 'exit' or 'quit' to stop the console.\n")
        
        # Main interaction loop
        while self._running:
            try:
                self.display_prompt()
                user_input = input().strip()
                
                if user_input:
                    self.process_input(user_input)
                    
            except KeyboardInterrupt:
                print("\n\n[Console interrupted by user]")
                self.stop()
            except EOFError:
                print("\n\n[Console input closed]")
                self.stop()
            except Exception as e:
                print(f"\n[Console error: {e}]", file=sys.stderr)
    
    def stop(self) -> None:
        """Gracefully stop console."""
        self._running = False
        # Phase 9: session boundary - clear intent on stop
        self._intent_log.clear()
        print("\nConsole stopped.\n")
    
    def display_prompt(self) -> None:
        """Display input prompt with local name."""
        mode_tag = f"[{self._mode}] "
        print(f"{mode_tag}{self.local_name}> ", end="", flush=True)

    def set_initial_mode(self, mode: str) -> None:
        """
        Set initial mode before console starts.
        
        Phase 12: Used by run_system.py to set PAUSED on startup.
        
        Args:
            mode: Initial mode (PREVIEW/EXECUTE/PAUSED)
        """
        mode = mode.upper().strip()
        if mode not in {"PREVIEW", "EXECUTE", "PAUSED"}:
            raise ValueError(f"Invalid mode: {mode}")
        self._mode = mode
    
    def _is_legal_mode_transition(self, from_mode: str, to_mode: str) -> bool:
        """Phase 9: Legal mode transition table (R9.D2)."""
        table = {
            "EXECUTE": {"EXECUTE": True, "PREVIEW": True, "PAUSED": True},
            "PREVIEW": {"EXECUTE": True, "PREVIEW": True, "PAUSED": True},
            "PAUSED":  {"EXECUTE": True, "PREVIEW": True, "PAUSED": True},
        }
        return bool(table.get(from_mode, {}).get(to_mode, False))

    def _set_mode(self, to_mode: str) -> None:
        """Set mode with explicit validation. No transitions during execution."""
        to_mode = to_mode.upper().strip()
        if to_mode not in {"PREVIEW", "EXECUTE", "PAUSED"}:
            print(f"[ERROR: Unknown mode '{to_mode}']", file=sys.stderr)
            return
        if self._in_execution:
            print("[ERROR: Cannot change mode during execution]", file=sys.stderr)
            return
        if not self._is_legal_mode_transition(self._mode, to_mode):
            print(f"[ERROR: Illegal mode transition {self._mode} → {to_mode}]", file=sys.stderr)
            return
        self._mode = to_mode
        print(f"Mode set to {self._mode}")
    
    def process_input(self, user_input: str) -> None:
        """
        Process user input and route to packet system.
        
        Phase 7.2: Support "preview" prefix for read-only introspection.
        
        Args:
            user_input: User input string
        """
        # Handle console commands
        if user_input.lower() in ('exit', 'quit'):
            self.stop()
            return

        # ─────────────────────────────────────────────────────────────
        # PHASE 9: Control surface commands (control events, NOT packets)
        # These must never enter the validator/executor pipeline.
        # ─────────────────────────────────────────────────────────────
        lower = user_input.strip().lower()

        # Mode control
        if lower.startswith('mode '):
            self._set_mode(user_input.split(' ', 1)[1])
            return
        if lower in {'pause', 'paused'}:
            self._set_mode('PAUSED')
            return
        if lower in {'previewmode', 'preview-mode'}:
            self._set_mode('PREVIEW')
            return
        if lower in {'executemode', 'execute-mode'}:
            self._set_mode('EXECUTE')
            return

        # Intent declaration (non-executable metadata)
        if lower.startswith('intent '):
            intent_text = user_input.split(' ', 1)[1].strip()
            if intent_text:
                self._intent_log.append(intent_text)
                print("[INTENT LOGGED] (non-executable)")
            else:
                print("[ERROR: intent requires text]", file=sys.stderr)
            return
        if lower == 'intent.show':
            print("\nIntent (this session only):")
            for i, t in enumerate(self._intent_log, 1):
                print(f"  {i}. {t}")
            print()
            return
        if lower == 'intent.clear':
            self._intent_log.clear()
            print("Intent cleared (session-scoped).")
            return

        # Debug/notes (human-only)
        if lower.startswith('notes '):
            note_text = user_input.split(' ', 1)[1].strip()
            if note_text:
                self._debug_notes.append(note_text)
                print("[NOTE SAVED] (human-only)")
            else:
                print("[ERROR: notes requires text]", file=sys.stderr)
            return
        if lower == 'notes.show':
            print("\nNotes (human-only):")
            for i, t in enumerate(self._debug_notes, 1):
                print(f"  {i}. {t}")
            print()
            return
        if lower == 'notes.clear':
            self._debug_notes.clear()
            print("Notes cleared.")
            return

        # Learning toggle (human-only control; never via engine command)
        if lower in {'learning on', 'learning off'}:
            desired = lower.endswith('on')
            # Router owns parameter store; access via a safe attribute if present.
            store = getattr(self._router, '_parameter_store', None)
            if store is None:
                print("[ERROR: Learning control unavailable (no parameter store)]", file=sys.stderr)
            else:
                store.learning_enabled = bool(desired)
                print(f"Learning enabled = {store.learning_enabled}")
            return

        # Load/unload are control events. They do not execute scenario commands.
        if lower.startswith('load '):
            scenario_id = user_input.split(' ', 1)[1].strip()
            if scenario_id:
                # Session boundary per spec: intent does not silently persist across loads.
                self._intent_log.clear()
                print(f"[LOADED] scenario target '{scenario_id}' (control-only; run 'scenario.activate {scenario_id}' to execute)")
            else:
                print("[ERROR: load requires scenario id]", file=sys.stderr)
            return
        if lower == 'unload':
            self._intent_log.clear()
            print("[UNLOADED] (control-only)")
            return
        
        if user_input.lower().startswith('setname '):
            # Set local name
            new_name = user_input[8:].strip()
            self.set_local_name(new_name)
            print(f"Display name set to: {self.local_name}")
            return
        
        if user_input.lower() == 'info':
            # Display engine info
            print(f"\nEngine Information:")
            print(f"  UUID:        {self._identity.uuid}")
            print(f"  Session ID:  {self._identity.get_session_id()}")
            print(f"  Display Name: {self.local_name}")
            print()
            return
        
        # Phase 7.2 + Phase 9: Determine preview mode
        preview_mode = (self._mode == "PREVIEW")
        command_input = user_input
        
        if user_input.lower().startswith('preview '):
            preview_mode = True
            command_input = user_input[8:].strip()  # Remove "preview " prefix
            
            # Guard: Block nested preview (preview preview ...)
            if command_input.lower().startswith('preview '):
                print("[ERROR: Cannot preview a preview command (nested preview forbidden)]", file=sys.stderr)
                return
        
        # Route to packet system and execute
        try:
            if self._mode == "PAUSED":
                print("[PAUSED: execution disabled]", file=sys.stderr)
                return

            self._in_execution = True
            result = self._router.route_input(
                command_input,
                self._identity.uuid,
                self._identity.get_session_id(),
                preview=preview_mode  # Phase 7.2
            )
            self._in_execution = False
            
            # Phase 3: Display execution result
            formatted_output = OutputFormatter.format(result)
            if formatted_output:
                print(formatted_output)
            
        except SchemaViolation as e:
            self._in_execution = False
            print(f"[Invalid input: {e}]", file=sys.stderr)
        except Exception as e:
            self._in_execution = False
            print(f"[Error processing input: {e}]", file=sys.stderr)
    
    def display_event(self, event: Event) -> None:
        """
        Display event according to classification.
        
        Args:
            event: Event to display
        """
        # Event display based on category
        if event.category == EventCategory.SILENT:
            # Silent events should not be displayed
            # (EventDispatcher should not route these here)
            return
        
        if event.category == EventCategory.INTERRUPT:
            # Interrupt events get priority display
            print(f"\n⚠️  {event.message}")
            if event.data:
                print(f"   Data: {event.data}")
            print()
        else:
            # Visible events get normal display
            print(f"\n→ {event.message}")
            if event.data:
                print(f"  Data: {event.data}")
            print()

"""
Event dispatcher - classifies and dispatches events to Console.
Implements event coalescing to prevent output spam.
"""

import time
from typing import Optional, List, Dict
from collections import defaultdict

from .schema import Event, EventCategory


class EventDispatcher:
    """
    Classifies and dispatches events to Console.
    Implements event coalescing to prevent output spam.
    """
    
    def __init__(self, console: Optional['Console'] = None):
        """
        Initialize dispatcher.
        
        Args:
            console: Console reference for event delivery (may be set later)
        """
        self._console = console
        self._event_buffer: List[Event] = []
        self._coalesce_window_ms = 1000  # Default 1 second window
    
    def set_console(self, console: 'Console') -> None:
        """
        Set console reference after creation.
        
        Args:
            console: Console instance
        """
        self._console = console
    
    def dispatch(self, event: Event) -> None:
        """
        Classify and route event to appropriate handler.
        
        Args:
            event: Event to dispatch
        """
        if self._console is None:
            # No console available - buffer or drop (safe failure)
            return
        
        # Route based on category
        if event.category == EventCategory.SILENT:
            # Log only, no console display
            self._log_silent_event(event)
        elif event.category == EventCategory.VISIBLE:
            # Normal console display
            self._console.display_event(event)
        elif event.category == EventCategory.INTERRUPT:
            # Immediate display with priority
            self._console.display_event(event)
        else:
            # Unknown category - treat as visible (safe fallback)
            self._console.display_event(event)
    
    def coalesce_events(self, window_ms: int = 1000) -> None:
        """
        Merge similar events within time window.
        
        This method processes buffered events and collapses similar ones.
        Uses monotonic time for robustness against clock drift/NTP sync.
        
        Args:
            window_ms: Time window for coalescing (milliseconds)
        """
        self._coalesce_window_ms = window_ms
        
        if not self._event_buffer:
            return
        
        # Group events by (category, event_type) within time window
        # Use monotonic time for elapsed time calculations (immune to clock drift)
        now = time.monotonic()
        window_seconds = window_ms / 1000.0
        
        # Filter events within window
        recent_events = [
            e for e in self._event_buffer
            if (now - e.timestamp) <= window_seconds
        ]
        
        # Group by (category, event_type)
        groups: Dict[tuple, List[Event]] = defaultdict(list)
        for event in recent_events:
            key = (event.category, event.event_type)
            groups[key].append(event)
        
        # Emit coalesced events
        for (category, event_type), events in groups.items():
            if len(events) > 1:
                # Multiple similar events - emit summary
                summary_event = Event(
                    category=category,
                    event_type=event_type,
                    message=f"{len(events)} similar events coalesced",
                    data={"count": len(events), "sample": events[0].data},
                    timestamp=now,
                    source="event_dispatcher"
                )
                self.dispatch(summary_event)
            else:
                # Single event - dispatch normally
                self.dispatch(events[0])
        
        # Clear buffer
        self._event_buffer.clear()
    
    def buffer_event(self, event: Event) -> None:
        """
        Add event to buffer for coalescing.
        
        Args:
            event: Event to buffer
        """
        self._event_buffer.append(event)
    
    def _log_silent_event(self, event: Event) -> None:
        """
        Log silent event (no console output).
        
        Phase 2: Stub - actual logging deferred to later phases.
        
        Args:
            event: Event to log
        """
        # Stub: Actual file logging deferred to later phases
        # For now, silent events are simply not displayed
        pass

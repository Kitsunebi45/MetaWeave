"""
Packet and Event schema definitions for Acorn Engine.
Engine NEVER sees raw language - only validated packets.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Any, Optional


class EventCategory(Enum):
    """Event classification for display/logging behavior."""
    SILENT = "silent"        # Log only, no console output
    VISIBLE = "visible"      # Display in console (normal output)
    INTERRUPT = "interrupt"  # Display immediately, may pause execution


@dataclass
class PacketMetadata:
    """
    Metadata attached to every packet.
    
    Attributes:
        packet_id: Unique packet identifier (UUIDv4)
        timestamp: Unix timestamp of packet creation
        source: Source component (e.g., "console", "engine")
        engine_uuid: Engine identity (for multi-engine scenarios)
        session_id: Session identifier (ephemeral)
        schema_version: Protocol version identifier (default: "2.0")
        preview: Preview mode flag (Phase 7.2) - if True, execute in shadow mode
    """
    packet_id: str
    timestamp: float
    source: str
    engine_uuid: str
    session_id: str
    schema_version: str = "2.0"
    preview: bool = False


@dataclass
class Packet:
    """
    Atomic unit of Engine communication.
    Engine NEVER sees raw language - only validated packets.
    
    Attributes:
        packet_type: Type of packet (e.g., "command", "query", "event")
        payload: Structured data (JSON-serializable dict)
        metadata: Packet metadata
    """
    packet_type: str
    payload: Dict[str, Any]
    metadata: PacketMetadata


@dataclass
class Event:
    """
    Structured event with classification.
    
    Attributes:
        category: Event category (silent/visible/interrupt)
        event_type: Specific event type (e.g., "state_change", "error")
        message: Human-readable message
        data: Structured event data
        timestamp: Unix timestamp
        source: Source component
    """
    category: EventCategory
    event_type: str
    message: str
    data: Dict[str, Any]
    timestamp: float
    source: str


@dataclass(frozen=True)
class ExecutionContext:
    """
    Ephemeral context for a single execution cycle.
    MUST NOT persist or leak across executions.
    
    Attributes:
        correlation_id: Packet ID for traceability (== Packet.metadata.packet_id)
        engine_timestamp: Monotonic timestamp at execution start
        scope: Ephemeral execution scope (empty by default)
    
    Invariants:
        - New instance per packet
        - No persistence
        - No mutation (frozen)
    """
    correlation_id: str
    engine_timestamp: float
    scope: Dict[str, Any]


@dataclass(frozen=True)
class ExecutionResult:
    """
    Mandatory return value for every execution attempt.
    
    Attributes:
        status: Execution status ("success" | "error")
        packet_id: Echo of correlation_id for traceability
        output: Console-facing output (any type)
        error: Structured error information (if status == "error")
    
    Invariants:
        - Always returned (never raises)
        - Exactly one per packet
    """
    status: str
    packet_id: str
    output: Any
    error: Optional[Dict[str, Any]] = None

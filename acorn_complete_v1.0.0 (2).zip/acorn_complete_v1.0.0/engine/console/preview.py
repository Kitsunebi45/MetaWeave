"""
Phase 7.2 - Preview Executor

Implements read-only introspection and preview capabilities.

INVARIANTS:
- No engine mutation
- No identity access  
- No persistence
- No preview nesting
- Preview cannot call preview

Preview Model:
    Validated Packet
    → PreviewExecutor
    → Deep copy of engine-facing inputs
    → Call engine evaluation path in "shadow mode"
    → Collect output/events
    → Discard all state
    → Return formatted preview result
"""

import copy
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

from .schema import Packet, ExecutionResult

from engine.learning.observer import LearningObserver
from engine.parameters import ParameterStore


@dataclass
class PreviewResult:
    """Result of a preview operation."""
    command: str
    target: Optional[str]
    args: Dict[str, Any]
    affected_subsystems: List[str]
    hypothetical_output: Any
    hypothetical_events: List[Dict[str, Any]]
    hypothetical_learning: Optional[Dict[str, Any]] = None
    state_changed: bool = False  # Always False for valid previews
    error: Optional[str] = None
    
    def __post_init__(self):
        """Enforce invariant: preview never changes state."""
        if self.state_changed:
            raise ValueError("INVARIANT VIOLATION: Preview reported state change")


class PreviewError(Exception):
    """Raised when preview encounters an error."""
    pass


class PreviewNestingError(PreviewError):
    """Raised when attempting to preview a preview (forbidden)."""
    pass


class PreviewExecutor:
    """
    Executes commands in shadow mode for read-only introspection.
    
    Phase 7.2 design principles:
    - "Glass box" - makes system legible without making it smarter
    - Pure read-only - no mutations, no real events, no caching
    - Deterministic - same input → same preview
    - Bounded - explicit output limits
    - Explicit - no inference, no suggestions
    
    Responsibilities:
    - Deep copy world state before evaluation
    - Execute command logic against copy
    - Collect hypothetical outputs/events
    - Discard all state changes
    - Return formatted preview result
    
    Hard Rules:
    ❌ No engine mutation
    ❌ No identity access
    ❌ No persistence
    ❌ No preview nesting
    ❌ Preview cannot call preview
    """
    
    def __init__(self, engine, *, learning_observer: Optional[LearningObserver] = None, parameter_store: Optional[ParameterStore] = None):
        """
        Initialize preview executor with engine reference.
        
        Args:
            engine: Engine instance (read-only access for preview)
        """
        self._engine = engine
        self._learning_observer = learning_observer
        self._parameter_store = parameter_store
    
    def execute_preview(self, packet: Packet) -> ExecutionResult:
        """
        Execute packet in preview mode (shadow execution).
        
        Args:
            packet: Validated packet to preview
            
        Returns:
            ExecutionResult containing PreviewResult
        """
        # Extract command components
        payload = packet.payload
        command = payload.get("command", "")
        target = payload.get("target")
        args = payload.get("args", {})
        
        try:
            # Determine affected subsystems
            affected = self._determine_affected_subsystems(command, target)
            
            # Execute in shadow mode
            hypothetical_output, hypothetical_events = self._shadow_execute(
                command, target, args
            )
            
            # Phase 8: Preview learning effects (dry-run, no mutation)
            learning_preview = None
            if self._learning_observer is not None and self._parameter_store is not None:
                cycle, _ = self._learning_observer.run_cycle(
                    events=hypothetical_events,
                    correlation_id=packet.metadata.packet_id,
                    dry_run=True,
                )
                learning_preview = {
                    "parameters_version": self._parameter_store.parameters_version,
                    "enabled": bool(self._parameter_store.learning_enabled),
                    "dry_run": True,
                    "status": cycle.status,
                    "records": [
                        {
                            "parameters_version": r.parameters_version,
                            "learning_rule_id": r.learning_rule_id,
                            "affected_parameters": [{"name": d.name, "old": d.old, "new": d.new} for d in r.affected_parameters],
                            "triggering_events": r.triggering_events,
                            "correlation_ids": r.correlation_ids,
                            "aggregation_window": r.aggregation_window,
                            "explanation": r.explanation,
                            "status": r.status,
                        }
                        for r in cycle.records
                    ],
                }

            # Build preview result
            preview_result = PreviewResult(
                command=command,
                target=target,
                args=args,
                affected_subsystems=affected,
                hypothetical_output=hypothetical_output,
                hypothetical_events=hypothetical_events,
                hypothetical_learning=learning_preview,
                state_changed=False,  # Invariant: never changes state
                error=None
            )
            
            return ExecutionResult(
                status="success",
                packet_id=packet.metadata.packet_id,
                output={"preview": True, "result": preview_result},
                error=None
            )
            
        except Exception as e:
            return ExecutionResult(
                status="error",
                packet_id=packet.metadata.packet_id,
                output=None,
                error={
                    "code": "PREVIEW_ERROR",
                    "message": str(e),
                    "command": command
                }
            )
    
    def _determine_affected_subsystems(self, command: str, target: Optional[str]) -> List[str]:
        """
        Determine which subsystems would be affected by command.
        
        Args:
            command: Command name
            target: Optional entity target
            
        Returns:
            List of affected subsystem names
        """
        affected = []
        
        # World-level commands
        if command in ("world.reset", "world.get"):
            affected.append("world_state")
        
        # Entity commands
        if command.startswith("entity.") or command.startswith("counter.") or \
           command.startswith("flag.") or command.startswith("container."):
            affected.append("entities")
            if target:
                affected.append(f"entity:{target}")
        
        # Scenario commands
        if command.startswith("scenario."):
            affected.append("scenario_engine")
        
        # If nothing specific, mark as "command_execution"
        if not affected:
            affected.append("command_execution")
        
        return affected
    
    def _shadow_execute(self, command: str, target: Optional[str], args: Dict[str, Any]) -> tuple:
        """
        Execute command in shadow mode against a deep copy of state.
        
        Args:
            command: Command to execute
            target: Optional entity target
            args: Command arguments
            
        Returns:
            Tuple of (hypothetical_output, hypothetical_events)
        """
        # Deep copy world state for shadow execution
        # WorldEngine exposes world state via .world property
        original_state = self._engine.world.to_dict()  # Get dict representation
        shadow_state = copy.deepcopy(original_state)
        
        # Simulate command execution (simplified - just report what would happen)
        hypothetical_output = self._simulate_command_effect(command, target, args, shadow_state)
        hypothetical_events = self._collect_hypothetical_events(command, target, args)
        
        # Discard shadow_state (no persistence)
        return (hypothetical_output, hypothetical_events)
    
    def _simulate_command_effect(self, command: str, target: Optional[str], 
                                  args: Dict[str, Any], shadow_state: Dict) -> str:
        """
        Simulate what the command would output.
        
        Args:
            command: Command name
            target: Optional target
            args: Command args
            shadow_state: Shadow copy of world state
            
        Returns:
            Description of hypothetical outcome
        """
        # World commands
        if command == "world.reset":
            return "Would reset world to baseline state"
        
        if command == "world.get":
            entity_count = len(shadow_state.get("entities", {}))
            return f"Would return world state with {entity_count} entities"
        
        # Scenario commands
        if command == "scenario.activate":
            scenario_id = args.get("scenario_id", "?")
            return f"Would activate scenario: {scenario_id}"
        
        if command == "scenario.advance":
            scenario_id = args.get("scenario_id", "?")
            return f"Would attempt to advance scenario: {scenario_id}"
        
        if command == "scenario.list":
            return "Would return list of available scenarios"
        
        if command == "scenario.status":
            return "Would return current scenario status"
        
        if command == "scenario.reset":
            return "Would reset scenario state to sandbox mode"
        
        # Entity commands
        if command == "counter.inc" and target:
            entities = shadow_state.get("entities", {})
            if target in entities:
                current_value = entities[target].get("state", {}).get("value", 0)
                return f"Would increment {target} from {current_value} to {current_value + 1}"
            return f"Would increment {target} (not found in current state)"
        
        if command == "counter.dec" and target:
            entities = shadow_state.get("entities", {})
            if target in entities:
                current_value = entities[target].get("state", {}).get("value", 0)
                return f"Would decrement {target} from {current_value} to {current_value - 1}"
            return f"Would decrement {target} (not found in current state)"
        
        if command == "counter.set" and target:
            value = args.get("value", 0)
            return f"Would set {target} to {value}"
        
        if command == "flag.enable" and target:
            return f"Would enable flag {target}"
        
        if command == "flag.disable" and target:
            return f"Would disable flag {target}"
        
        if command == "flag.toggle" and target:
            entities = shadow_state.get("entities", {})
            if target in entities:
                current = entities[target].get("state", {}).get("enabled", False)
                new_state = not current
                return f"Would toggle {target} from {current} to {new_state}"
            return f"Would toggle {target} (not found in current state)"
        
        if command == "container.add" and target:
            item = args.get("item", "")
            return f"Would add '{item}' to container {target}"
        
        if command == "container.remove" and target:
            item = args.get("item", "")
            return f"Would remove '{item}' from container {target}"
        
        if command == "container.clear" and target:
            entities = shadow_state.get("entities", {})
            if target in entities:
                item_count = len(entities[target].get("state", {}).get("items", []))
                return f"Would clear {item_count} items from container {target}"
            return f"Would clear container {target}"
        
        # Default
        return f"Would execute command: {command}"
    
    def _collect_hypothetical_events(self, command: str, target: Optional[str], 
                                      args: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Collect events that would be emitted by this command.
        
        Args:
            command: Command name
            target: Optional target
            args: Command args
            
        Returns:
            List of hypothetical events
        """
        events = []
        
        # Commands that modify state would emit events
        if command in ("counter.inc", "counter.dec", "counter.set"):
            events.append({
                "type": "entity_modified",
                "entity_id": target,
                "command": command
            })
        
        if command in ("flag.enable", "flag.disable", "flag.toggle"):
            events.append({
                "type": "entity_modified",
                "entity_id": target,
                "command": command
            })
        
        if command in ("container.add", "container.remove", "container.clear"):
            events.append({
                "type": "entity_modified",
                "entity_id": target,
                "command": command
            })
        
        if command == "world.reset":
            events.append({
                "type": "world_reset",
                "command": command
            })
        
        if command == "scenario.activate":
            events.append({
                "type": "scenario_activated",
                "scenario_id": args.get("scenario_id"),
                "command": command
            })
        
        if command == "scenario.advance":
            events.append({
                "type": "scenario_advance_attempted",
                "scenario_id": args.get("scenario_id"),
                "command": command
            })
        
        return events

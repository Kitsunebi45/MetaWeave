"""
Phase 11 Console - Inbox Reader

Waits for and reads response packets from inbox.
"""

import time
import json
from pathlib import Path
from typing import Optional

from io_bridge.io_schema import ResponsePacket, generate_packet_filename


class InboxReader:
    """
    Reads response packets from inbox with timeout.
    """
    
    def __init__(self, inbox_dir: Path):
        """
        Initialize inbox reader.
        
        Args:
            inbox_dir: Path to runtime_io/inbox
        """
        self.inbox_dir = Path(inbox_dir)
        self.inbox_dir.mkdir(parents=True, exist_ok=True)
    
    def wait_for_response(self, packet_id: str, 
                         timeout_seconds: float = 30.0,
                         poll_interval: float = 0.1) -> Optional[ResponsePacket]:
        """
        Wait for response packet with timeout.
        
        Args:
            packet_id: Packet ID to wait for
            timeout_seconds: Maximum wait time
            poll_interval: How often to check (seconds)
            
        Returns:
            ResponsePacket if found within timeout, None otherwise
        """
        filename = generate_packet_filename("res", packet_id)
        response_path = self.inbox_dir / filename
        
        start_time = time.time()
        
        while True:
            # Check if response exists
            if response_path.exists():
                try:
                    return self.read_response(packet_id)
                except Exception:
                    # File might be partially written, retry
                    pass
            
            # Check timeout
            elapsed = time.time() - start_time
            if elapsed >= timeout_seconds:
                return None
            
            # Wait before next check
            time.sleep(poll_interval)
    
    def read_response(self, packet_id: str) -> ResponsePacket:
        """
        Read response packet immediately (no waiting).
        
        Args:
            packet_id: Packet ID to read
            
        Returns:
            ResponsePacket
            
        Raises:
            FileNotFoundError: If response doesn't exist
            ValueError: If response is invalid
        """
        filename = generate_packet_filename("res", packet_id)
        response_path = self.inbox_dir / filename
        
        if not response_path.exists():
            raise FileNotFoundError(f"Response not found: {filename}")
        
        with open(response_path, 'r') as f:
            data = json.load(f)
        
        return ResponsePacket.from_dict(data)
    
    def delete_response(self, packet_id: str) -> bool:
        """
        Delete response packet after reading.
        
        Args:
            packet_id: Packet ID to delete
            
        Returns:
            True if deleted, False if not found
        """
        filename = generate_packet_filename("res", packet_id)
        response_path = self.inbox_dir / filename
        
        if response_path.exists():
            response_path.unlink()
            return True
        
        return False
    
    def has_response(self, packet_id: str) -> bool:
        """
        Check if response exists without reading.
        
        Args:
            packet_id: Packet ID to check
            
        Returns:
            True if response file exists
        """
        filename = generate_packet_filename("res", packet_id)
        response_path = self.inbox_dir / filename
        return response_path.exists()

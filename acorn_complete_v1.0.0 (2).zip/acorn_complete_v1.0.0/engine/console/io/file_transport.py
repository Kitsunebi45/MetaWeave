"""
Phase 11 Console - File Transport

High-level coordinator for console-side file transport.
"""

import uuid
import os
import time
from pathlib import Path
from typing import Optional

from io_bridge.io_schema import (
    RequestPacket, 
    ResponsePacket, 
    generate_timestamp,
    PacketMode,
)
from console.io.outbox_writer import OutboxWriter
from console.io.inbox_reader import InboxReader


class FileTransport:
    """
    Console-side file transport coordinator.
    
    Handles request/response cycle via filesystem.
    """
    
    def __init__(self, runtime_io_dir: Path):
        """
        Initialize file transport.
        
        Args:
            runtime_io_dir: Path to runtime_io directory
        """
        self.runtime_io_dir = Path(runtime_io_dir)
        
        # Initialize readers/writers
        self.outbox_writer = OutboxWriter(self.runtime_io_dir / "outbox")
        self.inbox_reader = InboxReader(self.runtime_io_dir / "inbox")

        # Single-process convenience: in real deployments the engine
        # runs separately and polls the outbox. For local dev/tests,
        # we can optionally pump the engine-side processor once per
        # wait cycle so `send_command()` can be used synchronously.
        self._local_engine_processor = None

    def _maybe_pump_local_engine(self) -> None:
        """Attempt to run the engine-side IO processor once (best-effort).

        This is a no-op if the engine processor cannot be imported.
        """
        try:
            from run_io import EngineIOProcessor  # local dev helper
        except Exception:
            return

        if self._local_engine_processor is None:
            try:
                self._local_engine_processor = EngineIOProcessor(self.runtime_io_dir)
            except Exception:
                # If engine boot fails, don't break console transport
                self._local_engine_processor = None
                return

        try:
            self._local_engine_processor.run_once()
        except Exception:
            # Never let local pumping break the request path
            return
    
    def send_command(self, 
                    command: str,
                    engine_uuid: str,
                    session_id: str,
                    mode: str = "EXECUTE",
                    timeout: float = 30.0) -> Optional[ResponsePacket]:
        """
        Send command and wait for response.
        
        Args:
            command: Raw command string
            engine_uuid: Engine UUID from Phase 1
            session_id: Session ID from Phase 1
            mode: "EXECUTE" or "PREVIEW"
            timeout: Response timeout in seconds
            
        Returns:
            ResponsePacket or None if timeout
        """
        # Generate unique packet ID
        packet_id = str(uuid.uuid4())
        
        # Create request packet
        request = RequestPacket(
            packet_version="11.0",
            packet_id=packet_id,
            engine_uuid=engine_uuid,
            session_id=session_id,
            mode=mode,
            command=command,
            created_at=generate_timestamp(),
        )
        
        # Write request
        self.outbox_writer.write_request(request)
        
        # Wait for response. In production, the engine runs in a separate
        # process and will write to the inbox asynchronously. For local
        # dev/tests, optionally pump the engine-side processor.
        end_time = time.time() + timeout
        response = None
        while time.time() < end_time:
            if self.inbox_reader.has_response(packet_id):
                response = self.inbox_reader.read_response(packet_id)
                break
            self._maybe_pump_local_engine()
            time.sleep(0.01)
        
        # Clean up response file if received
        if response:
            self.inbox_reader.delete_response(packet_id)
        
        return response

    def _maybe_pump_engine(self) -> None:
        """Best-effort single-process engine pump.

        If an engine-side IO processor is not running in another process,
        this will attempt to run one polling cycle locally. If disabled or
        unavailable, it is a no-op.
        """
        try:
            if getattr(self, "_local_engine_processor", None) is not None:
                self._local_engine_processor._maybe_run_once()
        except Exception:
            # Pumping is optional; never fail the console path.
            pass
    
    def send_command_async(self,
                          command: str,
                          engine_uuid: str,
                          session_id: str,
                          mode: str = "EXECUTE") -> str:
        """
        Send command without waiting for response.
        
        Args:
            command: Raw command string
            engine_uuid: Engine UUID
            session_id: Session ID
            mode: "EXECUTE" or "PREVIEW"
            
        Returns:
            Packet ID for later retrieval
        """
        # Generate unique packet ID
        packet_id = str(uuid.uuid4())
        
        # Create request packet
        request = RequestPacket(
            packet_version="11.0",
            packet_id=packet_id,
            engine_uuid=engine_uuid,
            session_id=session_id,
            mode=mode,
            command=command,
            created_at=generate_timestamp(),
        )
        
        # Write request
        self.outbox_writer.write_request(request)
        
        return packet_id
    
    def get_response(self, packet_id: str, 
                    timeout: float = 30.0) -> Optional[ResponsePacket]:
        """
        Get response for previously sent command.
        
        Args:
            packet_id: Packet ID from send_command_async
            timeout: Response timeout in seconds
            
        Returns:
            ResponsePacket or None if timeout
        """
        response = self.inbox_reader.wait_for_response(
            packet_id=packet_id,
            timeout_seconds=timeout,
        )
        
        # Clean up response file if received
        if response:
            self.inbox_reader.delete_response(packet_id)
        
        return response
    
    def check_response_ready(self, packet_id: str) -> bool:
        """
        Check if response is ready without waiting.
        
        Args:
            packet_id: Packet ID to check
            
        Returns:
            True if response is ready
        """
        return self.inbox_reader.has_response(packet_id)

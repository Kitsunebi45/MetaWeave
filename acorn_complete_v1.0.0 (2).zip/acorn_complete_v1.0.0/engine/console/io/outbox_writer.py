"""
Phase 11 Console - Outbox Writer

Atomic request packet writing to outbox.
Temp file → fsync → rename pattern.
"""

import json
import os
from pathlib import Path
from typing import Optional

from io_bridge.io_schema import RequestPacket, generate_packet_filename


class OutboxWriter:
    """
    Writes request packets to outbox atomically.
    
    Atomic write pattern:
    1. Write to temp file (.tmp)
    2. Fsync (if supported)
    3. Rename to final name
    """
    
    def __init__(self, outbox_dir: Path):
        """
        Initialize outbox writer.
        
        Args:
            outbox_dir: Path to runtime_io/outbox
        """
        self.outbox_dir = Path(outbox_dir)
        self.outbox_dir.mkdir(parents=True, exist_ok=True)
    
    def write_request(self, request: RequestPacket) -> Path:
        """
        Write request packet atomically.
        
        Args:
            request: RequestPacket to write
            
        Returns:
            Path to written file
            
        Raises:
            IOError: If write fails
        """
        # Validate request first
        request.validate()
        
        # Generate filename
        filename = generate_packet_filename("req", request.packet_id)
        final_path = self.outbox_dir / filename
        temp_path = self.outbox_dir / f"{filename}.tmp"
        
        try:
            # Write to temp file
            with open(temp_path, 'w') as f:
                f.write(request.to_json())
                f.flush()
                
                # Fsync if available (Unix/Linux)
                if hasattr(os, 'fsync'):
                    os.fsync(f.fileno())
            
            # Atomic rename
            temp_path.replace(final_path)
            
            return final_path
            
        except Exception as e:
            # Clean up temp file on error
            if temp_path.exists():
                temp_path.unlink()
            raise IOError(f"Failed to write request packet: {e}")
    
    def get_pending_count(self) -> int:
        """
        Get count of pending requests in outbox.
        
        Returns:
            Number of request files
        """
        if not self.outbox_dir.exists():
            return 0
        
        count = 0
        for filename in os.listdir(self.outbox_dir):
            if filename.startswith("req_") and filename.endswith(".json"):
                count += 1
        
        return count

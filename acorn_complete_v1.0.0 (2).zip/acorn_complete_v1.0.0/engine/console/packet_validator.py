"""
Packet validator - CHOKE POINT for Engine-bound traffic.
All Engine-bound traffic must pass through PacketValidator.validate().
"""

import copy
from .schema import Packet, PacketMetadata


class SchemaViolation(Exception):
    """Raised when packet fails schema validation."""
    pass


class PacketValidator:
    """
    CHOKE POINT: Validates packet schema before Engine access.
    All Engine-bound traffic must pass through validate().
    
    Phase 2: Interface only - validates structure, not content semantics.
    """
    
    def validate(self, packet: Packet) -> Packet:
        """
        Validate packet schema and enforce payload immutability.
        
        This is the CHOKE POINT - all Engine-bound traffic passes here.
        No bypass paths are permitted.
        
        Args:
            packet: Packet to validate
            
        Returns:
            Packet with immutable payload (deep copy to prevent mutation)
            
        Raises:
            SchemaViolation: If packet fails schema validation
        """
        # Structural validation only (Phase 2)
        
        # Validate packet_type
        if not isinstance(packet.packet_type, str):
            raise SchemaViolation(
                f"packet_type must be str, got {type(packet.packet_type).__name__}"
            )
        
        if not packet.packet_type or not packet.packet_type.strip():
            raise SchemaViolation("packet_type cannot be empty")
        
        # Validate payload
        if not isinstance(packet.payload, dict):
            raise SchemaViolation(
                f"payload must be dict, got {type(packet.payload).__name__}"
            )
        
        # Validate metadata
        if not isinstance(packet.metadata, PacketMetadata):
            raise SchemaViolation(
                f"metadata must be PacketMetadata, got {type(packet.metadata).__name__}"
            )
        
        # Validate metadata fields
        self._validate_metadata(packet.metadata)
        
        # Enforce payload immutability via deep copy
        # This prevents downstream components from mutating the payload,
        # preserving audit integrity and replay guarantees
        immutable_packet = Packet(
            packet_type=packet.packet_type,
            payload=copy.deepcopy(packet.payload),
            metadata=packet.metadata
        )
        
        return immutable_packet
    
    def _validate_metadata(self, metadata: PacketMetadata) -> None:
        """
        Validate metadata structure.
        
        Args:
            metadata: PacketMetadata to validate
            
        Raises:
            SchemaViolation: If metadata is invalid
        """
        # Validate required fields are non-empty strings
        required_string_fields = ['packet_id', 'source', 'engine_uuid', 'session_id', 'schema_version']
        
        for field in required_string_fields:
            value = getattr(metadata, field)
            if not isinstance(value, str):
                raise SchemaViolation(
                    f"metadata.{field} must be str, got {type(value).__name__}"
                )
            if not value or not value.strip():
                raise SchemaViolation(f"metadata.{field} cannot be empty")
        
        # Validate timestamp is numeric
        if not isinstance(metadata.timestamp, (int, float)):
            raise SchemaViolation(
                f"metadata.timestamp must be numeric, got {type(metadata.timestamp).__name__}"
            )

"""
Console subsystem for Acorn Engine.
Provides human-facing interface and packet routing.
"""

from .console import Console
from .packet_router import PacketRouter
from .packet_validator import PacketValidator, SchemaViolation
from .event_dispatcher import EventDispatcher
from .schema import Packet, PacketMetadata, Event, EventCategory

__all__ = [
    'Console',
    'PacketRouter',
    'PacketValidator',
    'SchemaViolation',
    'EventDispatcher',
    'Packet',
    'PacketMetadata',
    'Event',
    'EventCategory',
]

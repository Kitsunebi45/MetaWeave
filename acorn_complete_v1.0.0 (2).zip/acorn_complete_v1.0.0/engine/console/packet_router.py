"""
Packet router - routes packets from Console through Validator to Executor.
Enforces packet-only communication with Engine.

Phase 7.2: Adds preview dispatch for read-only introspection.
"""

import time
import uuid
from typing import Optional

from .schema import Packet, PacketMetadata, ExecutionResult
from .packet_validator import PacketValidator, SchemaViolation
from .preview import PreviewExecutor

from engine.learning.observer import LearningObserver
from engine.parameters import ParameterStore


class PacketRouter:
    """
    Routes packets from Console through Validator to Executor.
    Enforces packet-only communication with Engine.
    """
    
    def __init__(self, validator: PacketValidator, executor=None, preview_executor=None, *, learning_observer: Optional[LearningObserver] = None, parameter_store: Optional[ParameterStore] = None):
        """
        Initialize router with injected validator and optional executors.
        
        Args:
            validator: Packet validator (injected by boot)
            executor: Executor instance (Phase 3+, optional for Phase 2 compatibility)
            preview_executor: Preview executor (Phase 7.2+, optional)
        """
        self._validator = validator
        self._executor = executor
        self._preview_executor = preview_executor
        self._learning_observer = learning_observer
        self._parameter_store = parameter_store
    
    def route_input(self, raw_input: str, engine_uuid: str, session_id: str, preview: bool = False) -> ExecutionResult:
        """
        Convert raw input to packet, validate, and execute or preview.
        
        Args:
            raw_input: Raw string input from Console
            engine_uuid: Engine UUID for packet metadata
            session_id: Session ID for packet metadata
            preview: If True, execute in preview mode (Phase 7.2)
            
        Returns:
            ExecutionResult from engine execution or preview
            
        Raises:
            SchemaViolation: If packet fails validation
        """
        # Create packet from raw input
        packet = self._create_packet(raw_input, engine_uuid, session_id, preview)
        
        # Validate through CHOKE POINT
        validated_packet = self._validator.validate(packet)
        
        # Phase 7.2: Route to preview if preview flag is set
        if validated_packet.metadata.preview:
            if self._preview_executor is not None:
                return self._preview_executor.execute_preview(validated_packet)
            else:
                # Preview executor not available
                return ExecutionResult(
                    status="error",
                    packet_id=validated_packet.metadata.packet_id,
                    output=None,
                    error={
                        "code": "PREVIEW_UNAVAILABLE",
                        "message": "Preview executor not initialized"
                    }
                )
        
        # Phase 3: Execute if executor available
        if self._executor is not None:
            result = self._executor.dispatch(validated_packet)
            # Phase 8: Post-execution learning (observer runs only after execution completes)
            if self._learning_observer is not None and self._parameter_store is not None:
                # Only if execution succeeded and produced events
                if result.status == "success" and isinstance(result.output, dict):
                    events = result.output.get("events", [])
                    # Use packet_id as deterministic correlation_id
                    cycle, _ = self._learning_observer.run_cycle(
                        events=events,
                        correlation_id=validated_packet.metadata.packet_id,
                        dry_run=(not self._parameter_store.learning_enabled),
                    )
                    # Attach learning cycle to output (auditable, deterministic)
                    result.output["learning"] = {
                        "parameters_version": self._parameter_store.parameters_version,
                        "enabled": bool(self._parameter_store.learning_enabled),
                        "dry_run": bool(cycle.dry_run),
                        "status": cycle.status,
                        "records": [
                            {
                                "parameters_version": r.parameters_version,
                                "learning_rule_id": r.learning_rule_id,
                                "affected_parameters": [{"name": d.name, "old": d.old, "new": d.new} for d in r.affected_parameters],
                                "triggering_events": r.triggering_events,
                                "correlation_ids": r.correlation_ids,
                                "aggregation_window": r.aggregation_window,
                                "explanation": r.explanation,
                                "status": r.status,
                            }
                            for r in cycle.records
                        ]
                    }
                    # Attach learning info (auditable, deterministic)
                    result.output["learning"] = {
                        "parameters_version": self._parameter_store.parameters_version,
                        "enabled": self._parameter_store.learning_enabled,
                        "dry_run": cycle.dry_run,
                        "status": cycle.status,
                        "records": [
                            {
                                "parameters_version": r.parameters_version,
                                "learning_rule_id": r.learning_rule_id,
                                "affected_parameters": [{"name": d.name, "old": d.old, "new": d.new} for d in r.affected_parameters],
                                "triggering_events": r.triggering_events,
                                "correlation_ids": r.correlation_ids,
                                "aggregation_window": r.aggregation_window,
                                "explanation": r.explanation,
                                "status": r.status,
                            }
                            for r in cycle.records
                        ],
                    }
            return result
        else:
            # Phase 2 compatibility: Return stub result
            return ExecutionResult(
                status="success",
                packet_id=validated_packet.metadata.packet_id,
                output="[Phase 2 mode - no executor]",
                error=None
            )
    
    def _create_packet(self, raw_input: str, engine_uuid: str, session_id: str, preview: bool = False) -> Packet:
        """
        Create packet from raw input.
        
        Phase 4: Parse command format "command_name [args]"
        Phase 7.2: Support preview flag in metadata
        
        Args:
            raw_input: Raw string input
            engine_uuid: Engine UUID
            session_id: Session ID
            preview: Preview mode flag (Phase 7.2)
            
        Returns:
            Packet instance with command and args
        """
        # Create metadata
        metadata = PacketMetadata(
            packet_id=str(uuid.uuid4()),
            timestamp=time.time(),
            source="console",
            engine_uuid=engine_uuid,
            session_id=session_id,
            preview=preview  # Phase 7.2
        )
        
        # Parse command from raw input (Phase 5 grammar supports optional target)
        command, target, args = self._parse_command(raw_input)
        
        # Create packet with command structure
        packet = Packet(
            packet_type="command",
            payload={
                "command": command,
                "target": target,
                "args": args
            },
            metadata=metadata
        )
        
        return packet
    
    def _parse_command(self, raw_input: str) -> tuple:
        """
        Parse raw input into command, optional target, and args.
        
        Format examples:
            Phase 4 style (target omitted):
                "help" → ("help", None, {})
                "counter.inc" → ("counter.inc", None, {})
                "counter.set 42" → ("counter.set", None, {"value": 42})
                "echo hello world" → ("echo", None, {"message": "hello world"})

            Phase 5 style (entity target present):
                "counter.inc counter_1" → ("counter.inc", "counter_1", {})
                "counter.set counter_1 42" → ("counter.set", "counter_1", {"value": 42})
                "container.add container_1 hello" → ("container.add", "container_1", {"item": "hello"})
        
        Args:
            raw_input: Raw string input
            
        Returns:
            Tuple of (command, target, args)
        """
        raw = raw_input.strip()
        if not raw:
            return ("", None, {})

        parts = raw.split()
        command = parts[0]

        # Phase 5 + 6 registry (used only for parsing target + args)
        world_scoped = {"help", "world.get", "world.reset", "echo"}
        # Phase 6: scenario commands (world-scoped, take scenario_id arg)
        scenario_commands = {"scenario.list", "scenario.status", "scenario.reset"}
        scenario_commands_with_id = {"scenario.activate", "scenario.advance"}
        
        entity_scoped_noargs = {"entity.get", "entity.reset", "counter.inc", "counter.dec", "flag.enable", "flag.disable", "flag.toggle", "container.clear"}
        entity_scoped_value = {"counter.set"}
        entity_scoped_item = {"container.add", "container.remove"}

        target = None
        args: dict = {}

        # Phase 6: Scenario commands
        if command in scenario_commands:
            # scenario.list, scenario.status, scenario.reset - no args
            return (command, None, {})
        
        if command in scenario_commands_with_id:
            # scenario.activate <id>, scenario.advance <id>
            if len(parts) >= 2:
                args["scenario_id"] = parts[1]
            return (command, None, args)

        # Determine whether the second token is a target.
        # For entity-scoped commands we expect: <command> <target> ...
        if command in world_scoped:
            # World-level commands have no target.
            remainder = raw[len(command):].strip()
            if command == "echo":
                if remainder:
                    args["message"] = remainder
            elif remainder:
                args["text"] = remainder
            return (command, None, args)

        if command in entity_scoped_noargs | entity_scoped_value | entity_scoped_item:
            if len(parts) >= 2:
                target = parts[1]

            # Parse remaining args
            if command in entity_scoped_value:
                # Expect: counter.set <target> <value>
                if len(parts) >= 3:
                    val_text = " ".join(parts[2:])
                    try:
                        args["value"] = int(val_text)
                    except ValueError:
                        args["value"] = val_text

            elif command in entity_scoped_item:
                # Expect: container.add/remove <target> <item...>
                if len(parts) >= 3:
                    args["item"] = " ".join(parts[2:])
                else:
                    args["item"] = ""

            return (command, target, args)

        # Unknown command: preserve Phase 4 behavior (command + optional raw arg text)
        if len(parts) > 1:
            args["text"] = " ".join(parts[1:])
        return (command, None, args)
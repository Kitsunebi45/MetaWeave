"""Output formatter for console - makes results human-readable."""

import json
from typing import Any, Dict


class OutputFormatter:
    """Format ExecutionResult output for human consumption."""
    
    @staticmethod
    def format(result: Any) -> str:
        """
        Format an ExecutionResult output for display.
        
        Args:
            result: ExecutionResult object
            
        Returns:
            Formatted string for display
        """
        if result.status == "error":
            return OutputFormatter._format_error(result)
        
        output = result.output
        if output is None:
            return "(no output)"
        
        # Phase 7.2: Handle preview results
        if isinstance(output, dict) and output.get("preview") is True:
            return OutputFormatter._format_preview(output["result"])
        
        # Phase 5 world engine returns {result: ..., events: [...]}
        if isinstance(output, dict) and "result" in output:
            result_part = output["result"]
            events = output.get("events", [])
            
            formatted = OutputFormatter._format_result(result_part)
            
            if events:
                formatted += "\n" + OutputFormatter._format_events(events)

            # Phase 8: Attach learning audit (if present)
            learning = output.get("learning")
            if learning is not None:
                formatted += "\n" + OutputFormatter._format_learning(learning)

            return formatted
        
        # Fallback: format as-is
        return OutputFormatter._format_result(output)
    
    @staticmethod
    def _format_result(result: Any) -> str:
        """Format the main result portion."""
        if isinstance(result, str):
            return result
        
        if isinstance(result, dict):
            # Check if it's a world state or entity state
            if "schema_version" in result and "entities" in result:
                return OutputFormatter._format_world_state(result)
            elif "entity_id" in result and "entity_type" in result:
                return OutputFormatter._format_entity(result)
            elif "scenarios" in result:
                # Scenario list
                return OutputFormatter._format_scenario_list(result)
            elif "active_scenario" in result:
                # Scenario status
                return OutputFormatter._format_scenario_status(result)
            else:
                # Generic dict
                return json.dumps(result, indent=2)
        
        return str(result)
    
    @staticmethod
    def _format_world_state(world: Dict[str, Any]) -> str:
        """Format a WorldState for display."""
        lines = []
        lines.append(f"World State (v{world.get('schema_version', '?')})")
        lines.append(f"  Boot ID: {world.get('boot_id', '?')[:16]}...")
        lines.append(f"  Entities: {len(world.get('entities', {}))}")
        
        entities = world.get("entities", {})
        for entity_id in sorted(entities.keys()):
            entity = entities[entity_id]
            entity_type = entity.get("entity_type", "?")
            state = entity.get("state", {})
            
            if entity_type == "counter":
                lines.append(f"    {entity_id} (counter): value = {state.get('value', 0)}")
            elif entity_type == "flag":
                lines.append(f"    {entity_id} (flag): enabled = {state.get('enabled', False)}")
            elif entity_type == "container":
                items = state.get("items", [])
                lines.append(f"    {entity_id} (container): {len(items)} items")
                if items:
                    for item in items[:3]:  # Show first 3
                        lines.append(f"      - {item}")
                    if len(items) > 3:
                        lines.append(f"      ... and {len(items) - 3} more")
        
        return "\n".join(lines)
    
    @staticmethod
    def _format_entity(entity: Dict[str, Any]) -> str:
        """Format a single entity for display."""
        lines = []
        entity_id = entity.get("entity_id", "?")
        entity_type = entity.get("entity_type", "?")
        state = entity.get("state", {})
        
        lines.append(f"Entity: {entity_id} (type: {entity_type})")
        
        for key in sorted(state.keys()):
            value = state[key]
            if isinstance(value, list):
                lines.append(f"  {key}: [{len(value)} items]")
                for item in value[:5]:  # Show first 5
                    lines.append(f"    - {item}")
                if len(value) > 5:
                    lines.append(f"    ... and {len(value) - 5} more")
            else:
                lines.append(f"  {key}: {value}")
        
        return "\n".join(lines)
    
    @staticmethod
    def _format_scenario_list(result: Dict[str, Any]) -> str:
        """Format scenario list for display."""
        lines = []
        scenarios = result.get("scenarios", [])
        lines.append(f"Available Scenarios ({result.get('count', 0)}):")
        
        for scenario in scenarios:
            scenario_id = scenario.get("scenario_id", "?")
            description = scenario.get("description", "")
            lines.append(f"  • {scenario_id}")
            lines.append(f"    {description}")
        
        return "\n".join(lines)
    
    @staticmethod
    def _format_scenario_status(result: Dict[str, Any]) -> str:
        """Format scenario status for display."""
        lines = []
        
        mode = result.get("mode", "?")
        active_scenario = result.get("active_scenario")
        
        if active_scenario is None:
            lines.append(f"Mode: {mode}")
            lines.append("Status: No scenario active")
        else:
            description = result.get("description", "")
            ready = result.get("ready_to_advance", False)
            exit_conditions = result.get("exit_conditions", [])
            next_scenarios = result.get("next_scenarios", [])
            
            lines.append(f"Mode: {mode}")
            lines.append(f"Active Scenario: {active_scenario}")
            lines.append(f"Description: {description}")
            lines.append("")
            lines.append("Exit Conditions:")
            
            for cond in exit_conditions:
                condition_text = cond.get("condition", "?")
                current = cond.get("current_value", "?")
                satisfied = cond.get("satisfied", False)
                status_mark = "✓" if satisfied else "✗"
                lines.append(f"  {status_mark} {condition_text} [Current: {current}]")
            
            lines.append("")
            if ready:
                lines.append("Status: ✓ Ready to advance")
                if next_scenarios:
                    lines.append(f"Next: {', '.join(next_scenarios)}")
            else:
                lines.append("Status: ✗ Conditions not met")
        
        return "\n".join(lines)
    
    @staticmethod
    def _format_events(events: list) -> str:
        """Format events for display."""
        if not events:
            return ""
        
        lines = ["Events:"]
        for event in events:
            event_type = event.get("type", "UNKNOWN")
            lines.append(f"  • {event_type}")
            for key, value in event.items():
                if key != "type":
                    lines.append(f"    {key}: {value}")
        
        return "\n".join(lines)
    
    @staticmethod
    def _format_error(result: Any) -> str:
        """Format an error result."""
        error = result.error
        if isinstance(error, dict):
            code = error.get("code", "UNKNOWN_ERROR")
            message = error.get("message", "No message")
            
            lines = [f"ERROR: {code}", f"  {message}"]
            
            # Add extra details if present
            for key, value in error.items():
                if key not in ("code", "message"):
                    lines.append(f"  {key}: {value}")
            
            return "\n".join(lines)
        
        return f"ERROR: {error}"
    
    @staticmethod
    def _format_preview(preview_result: Any) -> str:
        """
        Format a preview result for display.
        Phase 7.2 - clearly distinguish preview from execution.
        
        Args:
            preview_result: PreviewResult object
            
        Returns:
            Formatted preview string with clear labeling
        """
        lines = []
        lines.append("╔════════════════════════════════════════╗")
        lines.append("║           [PREVIEW MODE]               ║")
        lines.append("╚════════════════════════════════════════╝")
        lines.append("")
        
        # Command details
        command = preview_result.command
        target = preview_result.target
        args = preview_result.args
        
        if target:
            lines.append(f"Command: {command} {target}")
        else:
            lines.append(f"Command: {command}")
        
        if args:
            lines.append(f"Arguments: {args}")
        
        lines.append("")
        
        # Affected subsystems
        affected = preview_result.affected_subsystems
        lines.append(f"Affected Subsystems: {', '.join(affected)}")
        lines.append("")
        
        # Hypothetical output
        lines.append("Hypothetical Output:")
        lines.append(f"  {preview_result.hypothetical_output}")
        lines.append("")
        
        # Hypothetical events
        events = preview_result.hypothetical_events
        if events:
            lines.append(f"Hypothetical Events ({len(events)}):")
            for event in events:
                event_type = event.get("type", "UNKNOWN")
                lines.append(f"  • {event_type}")
                for key, value in event.items():
                    if key != "type":
                        lines.append(f"      {key}: {value}")
        else:
            lines.append("Hypothetical Events: (none)")
        
        # Hypothetical learning (Phase 8)
        if getattr(preview_result, "hypothetical_learning", None):
            lines.append("")
            lines.append(OutputFormatter._format_learning(preview_result.hypothetical_learning))

        lines.append("")
        lines.append("┌────────────────────────────────────────┐")
        lines.append("│   ⚠ NO STATE CHANGED (Preview Only)   │")
        lines.append("└────────────────────────────────────────┘")
        
        return "\n".join(lines)

    # ─────────────────────────────────────────────────────────────
    # Phase 8: Learning audit formatting (bounded, human legible)
    # ─────────────────────────────────────────────────────────────
    @staticmethod
    def _format_learning(learning: Any) -> str:
        """Format learning audit payload, if present.

        Expected shapes (Phase 8):
        - None
        - {"enabled": bool, "records": [...]} OR {"records": [...]} OR a list of records
        """
        if learning is None:
            return ""

        # Normalize
        records = None
        enabled = None
        if isinstance(learning, dict):
            enabled = learning.get("enabled")
            records = learning.get("records")
        elif isinstance(learning, list):
            records = learning

        if records is None:
            # Fallback: print compact JSON for unknown shapes
            return "Learning:\n" + json.dumps(learning, indent=2)

        lines = ["Learning:"]
        if enabled is not None:
            lines.append(f"  enabled: {bool(enabled)}")

        if not records:
            lines.append("  (no records)")
            return "\n".join(lines)

        for rec in records[:20]:
            # Record schema is intentionally small and auditable.
            rule_id = rec.get("learning_rule_id", "?") if isinstance(rec, dict) else "?"
            status = rec.get("status", "applied") if isinstance(rec, dict) else "?"
            lines.append(f"  • {rule_id} [{status}]")
            if isinstance(rec, dict):
                for change in rec.get("affected_parameters", [])[:10]:
                    name = change.get("name", "?")
                    old = change.get("old")
                    new = change.get("new")
                    lines.append(f"    - {name}: {old} → {new}")
                reason = rec.get("reason") or rec.get("explanation")
                if reason:
                    lines.append(f"    reason: {reason}")

        if len(records) > 20:
            lines.append(f"  ... and {len(records) - 20} more")

        return "\n".join(lines)

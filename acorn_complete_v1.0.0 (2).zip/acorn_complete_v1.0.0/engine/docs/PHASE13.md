# Phase 13 — Plate Contract System

## Summary

Phase 13 implements the **Plate Contract System** for Spore Engine v12, enabling modular world configuration through immutable data packages.

## Key Concepts

### Plates

Plates are immutable JSON documents that define:
- **WORLD**: World topology, regions, connections
- **RULE**: Rule sets and parameters
- **ENTITY**: Entity templates and traits
- **SCENARIO**: Initial conditions and entity placement

### Plate Stack

Multiple plates are combined into a **plate stack** that is validated at boot time:
1. Schema validation (JSON Schema)
2. Engine compatibility check (SemVer ranges)
3. Stack ordering (WORLD → RULE/ENTITY → SCENARIO)
4. Resonance key uniqueness
5. Reference validation (world_ref, template_id, etc.)

## Invariants

- Plates are **immutable** — never modified at runtime
- Plate stack is **resolved once** at boot
- Any validation failure **aborts boot**
- No partial plate loading

## API

```python
from engine.phase13_boot import validate_plate_stack, boot_engine_with_plate_stack

# Validate and resolve plate stack
config = validate_plate_stack([world_plate, entity_plate, scenario_plate])

# Boot engine with plates
boot_engine_with_plate_stack(plate_paths)
```

## Schema Location

Authoritative schemas are shipped in:
```
engine/plates/schemas/
├── plate.schema.v1.0.json
├── world.content.schema.v1.0.json
├── rule.content.schema.v1.0.json
├── entity.content.schema.v1.0.json
└── scenario.content.schema.v1.0.json
```

## Error Classes

| Error | Meaning |
|-------|---------|
| SCHEMA_ERROR | JSON Schema validation failed |
| SEMANTIC_ERROR | Reference validation failed |
| COMPAT_ERROR | Engine version mismatch |
| INTEGRITY_ERROR | Checksum mismatch |
| CONFLICT_ERROR | Resonance key collision |

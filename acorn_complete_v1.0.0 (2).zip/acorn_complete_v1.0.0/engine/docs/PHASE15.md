# Phase 15 — Bounded Learning & Teaching

## Summary

Phase 15 implements **bounded learning** for Spore Engine v12, enabling entities to adapt over time through explicit teaching inputs while preserving plate immutability.

## Core Principle

> **Learning modifies runtime state only.**
> **Plates define the classroom. Saves record the student.**

## Key Concepts

### Learning State

Learning state lives in `state.learning` and contains:
- **Skills**: Numeric values bounded by envelopes
- **Metrics**: Counters and tracking values
- **History**: Append-only log (max 100 entries, FIFO)

### Teaching

Teaching is **external input only**. Valid sources:
- Scenario scripts
- Console commands
- Test harnesses

Teaching **never** originates from:
- Learning state itself
- Rules
- Engine heuristics

### Skill Envelopes

All skills are bounded:
```json
{
  "min": 0.0,
  "max": 1.0,
  "delta_per_event": 0.05
}
```

Overflow is **clamped**, not rejected.

## Invariants

- Learning lives ONLY in runtime state
- Plates remain immutable
- All updates are pure functions (deterministic)
- History capped at 100 entries
- No self-modifying code

## API

```python
from engine.learning import LearningManager, SkillUpdateEvent

# Create manager with envelopes
manager = LearningManager()
manager.register_envelope("navigation", ...)

# Apply teaching
manager.apply_teaching_event(SkillUpdateEvent(
    entity_id="e1",
    tick=1000,
    skill="navigation",
    delta=0.05
))

# Query state
value = manager.get_skill("e1", "navigation")
```

## Integration with Phase 14

Learning state is persisted via the save system:
```python
state_dict = manager.get_state_dict()
# Include in save: runtime_state.systems["learning"] = state_dict
```

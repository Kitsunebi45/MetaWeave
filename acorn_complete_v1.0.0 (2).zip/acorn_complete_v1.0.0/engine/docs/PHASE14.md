# Phase 14 — Runtime State Persistence

## Summary

Phase 14 implements **save/load functionality** for Spore Engine v12, enabling runtime state to be persisted and restored without mutating plates.

## Key Concepts

### Save Bundle

A save bundle captures **runtime state only**:
- World state (counters, flags)
- Entity state (positions, health)
- System state (tick count, learning state)

It explicitly **does not contain**:
- World topology (from plates)
- Rules (from plates)
- Templates (from plates)

### Plate Stack Hash

Every save records a `plate_stack_hash` (SHA256). On load, this must match the active plate stack exactly. Mismatch = abort.

## Invariants

- Plates = immutable substrate
- Saves = mutable runtime state
- Cold-load only (no hot-reload)
- Any validation failure aborts load
- Deterministic save/load

## Save Envelope Format

```json
{
  "schema_version": "1.0.0",
  "save_id": "uuid",
  "engine_version": "12.0.0",
  "plate_stack_hash": "sha256...",
  "created_at": "ISO-8601",
  "tick": 123456,
  "state": {
    "world_state": { },
    "entities": { },
    "systems": { }
  }
}
```

## API

```python
from engine.save import SaveManager, create_runtime_state

# Create save manager
save_mgr = SaveManager.from_resolved_config(config)

# Save current state
state = create_runtime_state(...)
envelope = save_mgr.save_state(path, tick, state)

# Load saved state
envelope = save_mgr.load_state(path)
```

## Validation Failures

| Condition | Result |
|-----------|--------|
| Plate stack hash mismatch | Abort |
| Engine version mismatch | Abort |
| Corrupt save JSON | Abort |
| Missing required field | Abort |

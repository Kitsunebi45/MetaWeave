# Phase 19 — Curriculum & Teaching Tooling

## Summary

Phase 19 implements **data-only lesson/curriculum definitions** and a **deterministic curriculum runner** for Spore Engine v12.

## Core Principle

> **Curricula are data, not code.**
> **Teaching flows through Phase 16 choke point.**
> **No adaptive behavior, no branching, no scoring.**

## Key Constraints

| Constraint | Meaning |
|------------|---------|
| Data-only | Lessons and curricula are JSON, no executable content |
| Determinism | No randomness, no wall-clock dependence |
| Linear ordering | Lessons execute in order, no branching |
| Authority preservation | Teaching via Phase 16 pathway only |
| Fail-fast | Schema errors abort immediately |

## Data Objects

### Lesson

```json
{
  "lesson_id": "navigation_basics_1",
  "target_entity": "e1",
  "skill": "navigation",
  "delta": 0.1,
  "reason": "Basic navigation training",
  "preconditions": {
    "min_value": 0.0,
    "max_value": 0.5
  }
}
```

Required fields: `lesson_id`, `target_entity`, `skill`, `delta`, `reason`

### Curriculum

```json
{
  "curriculum_id": "navigation_training",
  "lessons": ["navigation_basics_1", "navigation_basics_2"],
  "name": "Navigation Training",
  "description": "Basic navigation skill development"
}
```

Required fields: `curriculum_id`, `lessons`

## Run Modes

### Dry Run

- Validates curriculum and lessons
- Optionally checks entity existence and skill values
- MUST NOT mutate state

### Live Run

- Executes lessons sequentially
- Issues teaching events via Phase 16
- Halts on first failure
- Produces structured report

## API

```python
from engine.curriculum import (
    LessonStore, CurriculumStore,
    load_lesson, load_curriculum,
    create_runner
)

# Create stores
lesson_store = LessonStore()
curriculum_store = CurriculumStore()

# Load lessons
lesson = load_lesson({
    "lesson_id": "l1",
    "target_entity": "e1",
    "skill": "navigation",
    "delta": 0.1,
    "reason": "Training"
})
lesson_store.add(lesson)

# Load curriculum
curriculum = load_curriculum({
    "curriculum_id": "c1",
    "lessons": ["l1"]
})
curriculum_store.add(curriculum)

# Create runner
runner = create_runner(interface_api, lesson_store, curriculum_store)

# Dry run
report = runner.run("c1", dry=True)

# Live run
report = runner.run("c1", dry=False)
```

## Phase 16 Commands

| Command | Description |
|---------|-------------|
| `load curriculum <path>` | Load curriculum from file or directory |
| `show curriculum <id>` | Display curriculum details |
| `show lesson <id>` | Display lesson details |
| `run curriculum <id>` | Execute curriculum (live) |
| `run curriculum <id> dry` | Validate curriculum (dry-run) |

## Report Structure

```json
{
  "curriculum_id": "c1",
  "mode": "live",
  "started": "2026-01-24T12:00:00Z",
  "completed": "2026-01-24T12:00:01Z",
  "status": "PASS",
  "lessons_executed": 3,
  "lesson_results": [
    {
      "lesson_id": "l1",
      "target_entity": "e1",
      "skill": "navigation",
      "delta": 0.1,
      "status": "PASS",
      "previous_value": 0.0,
      "new_value": 0.05
    }
  ],
  "error": null
}
```

## Error Classes

| Error | Meaning |
|-------|---------|
| SCHEMA_ERROR | JSON Schema validation failed |
| SEMANTIC_ERROR | Semantic validation failed (e.g., missing lesson) |
| EXECUTION_ERROR | Runtime execution failed |

## Invariants Enforced

- ✅ Lessons are data-only (no executable content)
- ✅ Curricula define linear ordering only
- ✅ Teaching via Phase 16 pathway
- ✅ Dry-run MUST NOT mutate state
- ✅ Live-run halts on first failure
- ✅ Reports are deterministic and stable in shape

# Acorn Engine v12.19.0 Release Notes

**Release Date:** January 24, 2026  
**Status:** PRODUCTION READY

---

## Overview

Acorn Engine v12.19.0 is a complete release including the core engine and all Phase 13-19 features:

- **Phase 13**: Plate Contract System (immutable world configuration)
- **Phase 14**: Runtime State Persistence (save/load)
- **Phase 15**: Bounded Learning & Teaching
- **Phase 16**: Text-Based Interface Layer
- **Phase 18**: Observation & Visualization Layer
- **Phase 19**: Curriculum & Teaching Tooling

---

## What's Included

### Core Engine (v12)
- Deterministic simulation engine
- Rule evaluation system
- Entity management
- World state management

### Phase 13 — Plate System
- Immutable plate contracts (WORLD, RULE, ENTITY, SCENARIO)
- JSON Schema validation
- SemVer compatibility checking
- Stack ordering enforcement

### Phase 14 — Persistence
- Atomic save/load operations
- Plate stack hash validation
- Engine version validation
- Structured JSON save format

### Phase 15 — Learning
- Bounded skill system with envelopes
- Metric tracking
- History logging (FIFO, max 100)
- Teaching API

### Phase 16 — Interface
- Text-based REPL
- Read/write command separation
- Structured JSON output
- Full engine control

### Phase 18 — Visualization
- Read-only observation layer
- World topology view
- Entity view with learning badges
- Learning state visualization
- Rule status display
- Text and GUI modes

### Phase 19 — Curriculum
- Data-only lesson definitions
- Linear curriculum execution
- Dry-run validation mode
- Structured execution reports
- Teaching via Phase 16 pathway

---

## Test Results

| Component | Tests | Status |
|-----------|-------|--------|
| V12 Baseline | 156 | ✅ PASS |
| Phase 13 | 7 | ✅ PASS |
| Phase 14 | 8 | ✅ PASS |
| Phase 15 | 8 | ✅ PASS |
| Phase 16 | 9 | ✅ PASS |
| Phase 18 | 8 | ✅ PASS |
| Phase 19 | 8 | ✅ PASS |

**Total: 204 tests passing**

---

## Key Invariants

1. **Plates are immutable** — never modified at runtime
2. **Saves capture runtime state only** — not plate data
3. **Learning is bounded** — envelopes enforce limits
4. **Interface cannot bypass validation** — engine enforces rules
5. **Deterministic execution** — same inputs → same outputs

---

## What This Engine Is NOT

- ❌ Not a game (it's an engine)
- ❌ Not networked (offline only)
- ❌ Not a GUI application (text-based)
- ❌ Not self-modifying (plates are immutable)
- ❌ Not autonomous (teaching is explicit)

---

## Known Limitations

- Cold-load only (no hot-reload of plates)
- No branching timelines
- No PNG transport
- History capped at 100 entries per entity
- Single-threaded execution

---

## Verification

See `ACCEPTANCE.md` in the verification bundle for the complete acceptance checklist.

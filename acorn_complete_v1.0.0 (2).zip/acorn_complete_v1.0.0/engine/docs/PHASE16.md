# Phase 16 — Interface Layer

## Summary

Phase 16 implements a **text-based interface layer** for Spore Engine v12, allowing humans to observe state, teach entities, and manage save/load operations.

## Key Concepts

### Command Types

- **Read Commands**: Do not mutate state
- **Write Commands**: May mutate runtime state (not plates)

### Authority Model

- Interface may **request** actions
- Engine **enforces** all validation
- Interface cannot bypass plate immutability

## Invariants

- Deterministic command execution
- One command processed at a time
- No background tasks
- No hidden state in interface
- Structured JSON output only

## Command Reference

### Read Commands

| Command | Description |
|---------|-------------|
| `show world` | Display world state |
| `show entities` | List all entities |
| `show entity <id>` | Display entity details |
| `show learning <id>` | Display learning state |
| `show rules` | List enabled rules |
| `show scenario` | Display scenario state |
| `show status` | Display engine status |
| `help` | Show available commands |

### Write Commands

| Command | Description |
|---------|-------------|
| `start scenario <id>` | Start a scenario |
| `stop scenario` | Stop current scenario |
| `teach entity <id> <skill> <delta> reason "<text>"` | Apply teaching |
| `reset learning <id>` | Reset entity learning |
| `save` | Save current state |
| `save as <filename>` | Save to file |
| `load` | Load most recent save |
| `load from <filename>` | Load from file |
| `tick` | Advance one tick |
| `tick <count>` | Advance N ticks |
| `quit` | Exit interface |

## API

```python
from engine.interface import create_repl

# Create REPL with managers
repl = create_repl(
    learning_manager=learning_mgr,
    save_manager=save_mgr,
    resolved_config=config
)

# Run interactive loop
repl.run()

# Or execute commands programmatically
responses = repl.execute_commands([
    "show status",
    "start scenario test",
    "tick 10"
])
```

## Output Format

All responses are structured JSON:

```json
{
  "success": true,
  "command": "show_status",
  "data": {
    "tick": 1000,
    "running": true
  }
}
```

# Phase 18 — Observation & Visualization Layer

## Summary

Phase 18 implements a **read-only visualization layer** for Spore Engine v12, allowing humans to observe engine state without modifying it.

## Core Principle

> **Visualization is OBSERVER-ONLY.**
> **Engine state is NEVER mutated by the visualization layer.**

## Key Constraints

| Constraint | Meaning |
|------------|---------|
| Observer-only | NO write paths, NO teaching, NO scenario control |
| Read-path purity | ONLY consumes Phase 16 read APIs |
| Determinism | No prediction, smoothing, or extrapolation |
| Isolation | No persistent state |
| Offline only | No networking, telemetry, or remote dashboards |

## Architecture

```
Engine Core
   ↓
Phase 16 Read APIs
   ↓
Phase 18 Visualization Adapter
   ↓
Visualization UI
```

**No other data paths are permitted.**

## Views

### World View
- Regions / nodes
- Connections (bidirectional per Phase 13)
- Activity overlay

### Entity View
- Entity ID
- Current region / position
- Capabilities
- Learning badge (presence only)

### Learning View
- Skills with current values
- Envelope bounds (min/max/delta)
- Metrics
- History timeline

### Rule View
- Active rules
- Disabled rules
- Rule set configuration

## Update Model

**Pull-based refresh only:**
- Manual refresh button
- Fixed interval refresh (optional)

Rules:
- Refresh MUST NOT trigger engine logic
- Refresh MUST NOT mutate state

## API

```python
from engine.interface import InterfaceAPI
from engine.visualization import create_visualization_app

# Create interface API
api = InterfaceAPI(learning_manager=..., resolved_config=...)

# Create and run visualization
app = create_visualization_app(api, mode="text")
app.run()
```

## Modes

### Text Mode
Console-based visualization. Always available.

Commands:
- `refresh` - Update data from engine
- `status` - Show engine status
- `world` - Show world topology
- `entities` - Show entity list
- `learning <id>` - Show learning for entity
- `rules` - Show rule configuration
- `scenario` - Show scenario status
- `full` - Show complete snapshot
- `quit` - Exit visualization

### GUI Mode
Desktop window visualization. Requires tkinter.

Features:
- Tabbed interface
- Refresh button
- Read-only text displays

## Invariants Enforced

- ✅ Visualization MUST NOT mutate engine state
- ✅ Adapter MUST NOT cache data
- ✅ Adapter MUST NOT normalize or transform semantics
- ✅ Adapter MUST NOT infer missing data
- ✅ All models are immutable (frozen dataclasses)
- ✅ Closing UI leaves engine unchanged
- ✅ Deterministic redraw from identical state

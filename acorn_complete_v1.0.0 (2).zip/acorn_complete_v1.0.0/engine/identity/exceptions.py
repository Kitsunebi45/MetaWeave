"""
Identity subsystem exceptions.
All identity-related errors derive from IdentityError.
"""


class IdentityError(Exception):
    """Base exception for all identity-related errors."""
    pass


class IdentityMissingError(IdentityError):
    """Raised when identity file is missing in an initialized system."""
    pass


class IdentityCorruptError(IdentityError):
    """Raised when identity file exists but content is invalid."""
    pass


class IdentityTamperError(IdentityError):
    """Raised when identity file permissions or integrity are compromised."""
    pass

"""
Engine identity management.
Provides immutable access to engine UUID and ephemeral session ID.
"""

import hashlib
import time
import uuid as uuid_module
from typing import Optional

from .exceptions import IdentityCorruptError


class EngineIdentity:
    """
    Immutable engine identity container.
    
    The engine_uuid is the persistent, unique identifier for this engine instance.
    The session_id is ephemeral and unique to this process run.
    """
    
    def __init__(self, engine_uuid: str):
        """
        Initialize engine identity with strict UUIDv4 validation.
        
        Args:
            engine_uuid: String representation of a UUIDv4
            
        Raises:
            IdentityCorruptError: If uuid is not a valid UUIDv4
        """
        # Strict UUIDv4 validation
        try:
            parsed = uuid_module.UUID(engine_uuid)
        except (ValueError, AttributeError, TypeError) as e:
            raise IdentityCorruptError(
                f"Invalid UUID format: {engine_uuid} - {e}"
            )
        
        # Explicitly check version 4
        if parsed.version != 4:
            raise IdentityCorruptError(
                f"UUID must be version 4, got version {parsed.version}: {engine_uuid}"
            )
        
        # Store canonical string representation
        self._uuid = str(parsed)
        self._session_id: Optional[str] = None
        self._launch_timestamp = time.time()
    
    @property
    def uuid(self) -> str:
        """
        Read-only access to engine UUID.
        
        This is the only authorized way for other modules (Plates, Memory, Logs)
        to reference the engine's identity.
        
        Returns:
            Persistent engine UUID as string
        """
        return self._uuid
    
    def get_session_id(self) -> str:
        """
        Get ephemeral session identifier for this process run.
        
        Session ID is derived from engine UUID + launch timestamp and cached
        for the lifetime of this process. It is NOT persisted.
        
        Returns:
            12-character hex session identifier (stable per process)
        """
        if self._session_id is None:
            seed = f"{self._uuid}-{self._launch_timestamp}".encode()
            self._session_id = hashlib.sha256(seed).hexdigest()[:12]
        return self._session_id
    
    def reset_identity(self) -> None:
        """
        Stub for identity reset functionality.
        
        Identity reset is not implemented in Phase 1.
        This would require operator-level authorization and migration logic.
        
        Raises:
            NotImplementedError: Always
        """
        raise NotImplementedError(
            "Identity reset requires operator authorization (not implemented in Phase 1)"
        )
    
    def __repr__(self) -> str:
        return f"EngineIdentity(uuid={self._uuid[:8]}..., session={self.get_session_id()})"

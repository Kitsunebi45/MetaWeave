"""
Identity subsystem for Acorn Engine.
Provides immutable engine identity with atomic persistence.
"""

from .engine_identity import EngineIdentity
from .identity_storage import IdentityStorage
from .exceptions import (
    IdentityError,
    IdentityMissingError,
    IdentityCorruptError,
    IdentityTamperError
)

__all__ = [
    'EngineIdentity',
    'IdentityStorage',
    'IdentityError',
    'IdentityMissingError',
    'IdentityCorruptError',
    'IdentityTamperError',
]

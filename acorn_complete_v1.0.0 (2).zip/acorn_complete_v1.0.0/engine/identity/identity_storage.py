"""
Identity storage with atomic write and immutability enforcement.
Handles OS-specific file permission logic for identity protection.
"""

import os
import stat
import sys
from pathlib import Path
from typing import Optional

from .exceptions import IdentityCorruptError, IdentityTamperError


class IdentityStorage:
    """
    Manages persistent storage of engine identity with atomic write guarantees.
    """
    
    IDENTITY_FILENAME = "engine.uuid"
    TEMP_SUFFIX = ".tmp"
    
    def __init__(self, identity_dir: Path):
        """
        Initialize identity storage.
        
        Args:
            identity_dir: Directory where identity file will be stored
        """
        self.identity_dir = Path(identity_dir)
        self.identity_file = self.identity_dir / self.IDENTITY_FILENAME
        self.temp_file = self.identity_dir / f"{self.IDENTITY_FILENAME}{self.TEMP_SUFFIX}"
    
    def exists(self) -> bool:
        """Check if identity file exists."""
        return self.identity_file.exists()
    
    def directory_exists(self) -> bool:
        """Check if identity directory exists."""
        return self.identity_dir.exists()
    
    def write_identity(self, engine_uuid: str) -> None:
        """
        Atomically write identity to storage with immutability enforcement.
        
        This method:
        1. Refuses to overwrite existing identity
        2. Writes to temporary file
        3. Applies read-only permissions to temp file
        4. Atomically moves temp file to final location
        5. Verifies final file exists and is read-only
        6. Cleans up temp file on any failure
        
        Args:
            engine_uuid: UUIDv4 string to persist
            
        Raises:
            IdentityTamperError: If identity already exists or atomic write fails
        """
        # Refuse to overwrite existing identity
        if self.exists():
            raise IdentityTamperError(
                f"Identity file already exists at {self.identity_file}. "
                "Cannot overwrite existing identity."
            )
        
        # Ensure directory exists
        self.identity_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            # Step 1: Write to temporary file
            self.temp_file.write_text(engine_uuid, encoding='utf-8')
            
            # Step 2: Apply read-only permissions to temp file (before exposure)
            self._set_read_only(self.temp_file)
            
            # Step 3: Atomic move to final location
            # os.replace() is atomic on both POSIX and Windows
            os.replace(str(self.temp_file), str(self.identity_file))
            
            # Step 4: Verify final state
            if not self.identity_file.exists():
                raise IdentityTamperError("Atomic move succeeded but file does not exist")
            
            if not self.is_read_only(self.identity_file):
                raise IdentityTamperError("Identity file is not read-only after creation")
                
        except Exception as e:
            # Cleanup on any failure
            if self.temp_file.exists():
                try:
                    # Must remove read-only before deletion
                    self._set_writable(self.temp_file)
                    self.temp_file.unlink()
                except Exception:
                    pass  # Best effort cleanup
            raise
    
    def read_identity(self) -> str:
        """
        Read and validate identity from storage.
        
        Returns:
            Engine UUID string
            
        Raises:
            IdentityCorruptError: If file is empty, unreadable, or invalid
            IdentityTamperError: If file permissions are not read-only
        """
        # Check for 0-byte ghost file
        file_size = self.identity_file.stat().st_size
        if file_size == 0:
            raise IdentityCorruptError(
                f"Identity file exists but is empty (0-byte ghost): {self.identity_file}"
            )
        
        # Verify read-only permissions
        if not self.is_read_only(self.identity_file):
            raise IdentityTamperError(
                f"Identity file permissions have been modified to writable: {self.identity_file}"
            )
        
        # Read content
        try:
            content = self.identity_file.read_text(encoding='utf-8').strip()
        except Exception as e:
            raise IdentityCorruptError(
                f"Cannot read identity file {self.identity_file}: {e}"
            )
        
        if not content:
            raise IdentityCorruptError("Identity file contains no content")
        
        return content
    
    def is_read_only(self, file_path: Path) -> bool:
        """
        Check if file has read-only permissions (OS-specific).
        
        Args:
            file_path: Path to check
            
        Returns:
            True if file is read-only, False otherwise
        """
        if sys.platform == 'win32':
            # Windows: Check if file has write access
            return not os.access(str(file_path), os.W_OK)
        else:
            # POSIX: Check if owner write bit is not set
            mode = file_path.stat().st_mode
            return not bool(mode & stat.S_IWUSR)
    
    def _set_read_only(self, file_path: Path) -> None:
        """
        Set file to read-only (OS-specific, best effort).
        
        Args:
            file_path: Path to make read-only
        """
        if sys.platform == 'win32':
            # Windows: Set read-only attribute
            import ctypes
            FILE_ATTRIBUTE_READONLY = 0x01
            ctypes.windll.kernel32.SetFileAttributesW(str(file_path), FILE_ATTRIBUTE_READONLY)
        else:
            # POSIX: chmod 444 (read-only for all)
            os.chmod(str(file_path), stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)
    
    def _set_writable(self, file_path: Path) -> None:
        """
        Remove read-only restriction (for cleanup only).
        
        Args:
            file_path: Path to make writable
        """
        if sys.platform == 'win32':
            import ctypes
            FILE_ATTRIBUTE_NORMAL = 0x80
            ctypes.windll.kernel32.SetFileAttributesW(str(file_path), FILE_ATTRIBUTE_NORMAL)
        else:
            # POSIX: chmod 644 (owner writable)
            os.chmod(str(file_path), stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH)

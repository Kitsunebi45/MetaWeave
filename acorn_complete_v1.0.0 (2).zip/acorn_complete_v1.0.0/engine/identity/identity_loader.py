"""
Phase 12.1 Identity Loader

Simple wrapper for identity loading used by run_system.py
Delegates to existing Phase 1 boot logic.
"""

from pathlib import Path
from .engine_identity import EngineIdentity
from .identity_storage import IdentityStorage


def load_identity(identity_dir: Path = None) -> EngineIdentity:
    """
    Load engine identity using Phase 1 storage.
    
    Args:
        identity_dir: Directory for identity storage (default: ./engine_data)
        
    Returns:
        EngineIdentity instance
        
    Raises:
        RuntimeError: If identity cannot be loaded
    """
    if identity_dir is None:
        identity_dir = Path("engine_data")
    
    identity_dir.mkdir(parents=True, exist_ok=True)
    
    storage = IdentityStorage(identity_dir)
    
    # Create identity on first boot
    if not storage.exists():
        import uuid
        engine_uuid = str(uuid.uuid4())
        storage.write_identity(engine_uuid)
    
    # Load identity
    try:
        uuid_str = storage.read_identity()
        return EngineIdentity(uuid_str)
    except Exception as e:
        raise RuntimeError(f"Failed to load identity: {e}")

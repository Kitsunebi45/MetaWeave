#!/usr/bin/env python3
"""Acorn Engine v12.16.0 — Main Entry Point

Starts the engine with the Phase 16 interface layer.

Usage:
    python main.py

The engine will start in interactive REPL mode.
Type 'help' for available commands.
Type 'quit' to exit.
"""

import sys
import json
from pathlib import Path

# Ensure engine is importable
sys.path.insert(0, str(Path(__file__).parent))


def load_example_plates():
    """Load example plates from plates/examples/."""
    plates_dir = Path(__file__).parent / "plates" / "examples"
    
    plates = []
    for plate_file in ["world.json", "entities.json", "rules.json", "scenario.json"]:
        plate_path = plates_dir / plate_file
        if plate_path.exists():
            with open(plate_path) as f:
                plates.append(json.load(f))
    
    return plates


def main():
    """Main entry point."""
    print("=" * 60)
    print("Acorn Engine v12.19.0")
    print("=" * 60)
    print()
    
    # Start console socket server FIRST
    print("Starting console socket server...")
    try:
        from engine.console_socket import start_console_server
        console_server = start_console_server()
    except ImportError as e:
        print(f"Warning: Could not start console socket: {e}")
        console_server = None
    
    # Import engine components
    try:
        from engine.phase13_boot import validate_plate_stack
        from engine.save import SaveManager
        from engine.learning import LearningManager, create_skill_envelope
        from engine.interface import create_repl
    except ImportError as e:
        print(f"Error: Could not import engine components: {e}")
        print("Make sure you are running from the acorn-engine directory.")
        return 1
    
    # Load example plates
    print("Loading example plates...")
    plates = load_example_plates()
    
    if not plates:
        print("Warning: No example plates found. Starting with minimal configuration.")
        config = None
        save_mgr = None
    else:
        try:
            # Validate plate stack
            config = validate_plate_stack(plates)
            print(f"  Loaded {len(plates)} plates")
            print(f"  World: {config.world_config.world_id if config.world_config else 'None'}")
            print(f"  Scenario: {config.scenario_config.scenario_id if config.scenario_config else 'None'}")
            
            # Create save manager
            save_mgr = SaveManager.from_resolved_config(config)
        except Exception as e:
            print(f"Warning: Could not load plates: {e}")
            config = None
            save_mgr = None
    
    # Create learning manager with default envelopes
    print("Initializing learning system...")
    learning_mgr = LearningManager()
    learning_mgr.register_envelope("navigation", create_skill_envelope(0.0, 1.0, 0.05))
    learning_mgr.register_envelope("perception", create_skill_envelope(0.0, 1.0, 0.05))
    learning_mgr.register_envelope("coordination", create_skill_envelope(0.0, 1.0, 0.05))
    
    # Create save directory
    save_dir = Path(__file__).parent / "saves"
    save_dir.mkdir(exist_ok=True)
    
    # Create and run REPL
    print()
    print("Starting interface...")
    print("-" * 60)
    
    repl = create_repl(
        learning_manager=learning_mgr,
        save_manager=save_mgr,
        resolved_config=config,
        save_dir=save_dir
    )
    
    try:
        repl.run()
    except KeyboardInterrupt:
        print("\nInterrupted.")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

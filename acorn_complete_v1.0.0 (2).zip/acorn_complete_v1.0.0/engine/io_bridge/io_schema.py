"""
Phase 11 IO Bridge - Shared Schema

Request/Response packet definitions for file-based transport.
Strict validation, deterministic serialization.
"""

from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
from enum import Enum
import json


class PacketMode(Enum):
    """Request execution mode."""
    EXECUTE = "EXECUTE"
    PREVIEW = "PREVIEW"


class ResponseStatus(Enum):
    """Response status codes."""
    OK = "OK"
    REJECTED = "REJECTED"
    ERROR = "ERROR"


@dataclass
class RequestPacket:
    """
    Console → Engine request packet.
    
    All fields required except where noted.
    """
    packet_version: str  # Always "11.0"
    packet_id: str  # ULID or UUID
    engine_uuid: str  # From Phase 1
    session_id: str  # From Phase 1
    mode: str  # "EXECUTE" or "PREVIEW"
    command: str  # Raw command string
    created_at: str  # ISO 8601 UTC
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return asdict(self)
    
    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=2)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'RequestPacket':
        """Deserialize from dictionary with validation."""
        # Validate required fields
        required = ['packet_version', 'packet_id', 'engine_uuid', 
                   'session_id', 'mode', 'command', 'created_at']
        
        for field_name in required:
            if field_name not in data:
                raise ValueError(f"Missing required field: {field_name}")
        
        # Validate packet version
        if data['packet_version'] != "11.0":
            raise ValueError(f"Invalid packet_version: {data['packet_version']}")
        
        # Validate mode
        if data['mode'] not in ['EXECUTE', 'PREVIEW']:
            raise ValueError(f"Invalid mode: {data['mode']}")
        
        return cls(
            packet_version=data['packet_version'],
            packet_id=data['packet_id'],
            engine_uuid=data['engine_uuid'],
            session_id=data['session_id'],
            mode=data['mode'],
            command=data['command'],
            created_at=data['created_at'],
        )
    
    @classmethod
    def from_json(cls, json_str: str) -> 'RequestPacket':
        """Deserialize from JSON string."""
        return cls.from_dict(json.loads(json_str))
    
    def validate(self) -> None:
        """
        Validate packet fields.
        
        Raises:
            ValueError: If validation fails
        """
        if self.packet_version != "11.0":
            raise ValueError("packet_version must be '11.0'")
        
        if not self.packet_id:
            raise ValueError("packet_id cannot be empty")
        
        if not self.engine_uuid:
            raise ValueError("engine_uuid cannot be empty")
        
        if not self.session_id:
            raise ValueError("session_id cannot be empty")
        
        if self.mode not in ['EXECUTE', 'PREVIEW']:
            raise ValueError(f"Invalid mode: {self.mode}")
        
        if not self.command:
            raise ValueError("command cannot be empty")
        
        if not self.created_at:
            raise ValueError("created_at cannot be empty")


@dataclass
class ResponsePacket:
    """
    Engine → Console response packet.
    
    All fields required.
    """
    packet_version: str  # Always "11.0"
    packet_id: str  # Same as request
    status: str  # "OK" | "REJECTED" | "ERROR"
    stdout: List[str]  # Output lines
    events: List[Dict[str, Any]]  # Event objects
    state_changed: bool  # True if state modified
    created_at: str  # ISO 8601 UTC
    error_message: Optional[str] = None  # Only for ERROR status
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return asdict(self)
    
    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=2)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ResponsePacket':
        """Deserialize from dictionary with validation."""
        # Validate required fields
        required = ['packet_version', 'packet_id', 'status', 
                   'stdout', 'events', 'state_changed', 'created_at']
        
        for field_name in required:
            if field_name not in data:
                raise ValueError(f"Missing required field: {field_name}")
        
        # Validate packet version
        if data['packet_version'] != "11.0":
            raise ValueError(f"Invalid packet_version: {data['packet_version']}")
        
        # Validate status
        if data['status'] not in ['OK', 'REJECTED', 'ERROR']:
            raise ValueError(f"Invalid status: {data['status']}")
        
        return cls(
            packet_version=data['packet_version'],
            packet_id=data['packet_id'],
            status=data['status'],
            stdout=data['stdout'],
            events=data['events'],
            state_changed=data['state_changed'],
            created_at=data['created_at'],
            error_message=data.get('error_message'),
        )
    
    @classmethod
    def from_json(cls, json_str: str) -> 'ResponsePacket':
        """Deserialize from JSON string."""
        return cls.from_dict(json.loads(json_str))
    
    def validate(self) -> None:
        """
        Validate packet fields.
        
        Raises:
            ValueError: If validation fails
        """
        if self.packet_version != "11.0":
            raise ValueError("packet_version must be '11.0'")
        
        if not self.packet_id:
            raise ValueError("packet_id cannot be empty")
        
        if self.status not in ['OK', 'REJECTED', 'ERROR']:
            raise ValueError(f"Invalid status: {self.status}")
        
        if not isinstance(self.stdout, list):
            raise ValueError("stdout must be a list")
        
        if not isinstance(self.events, list):
            raise ValueError("events must be a list")
        
        if not isinstance(self.state_changed, bool):
            raise ValueError("state_changed must be a boolean")


def generate_timestamp() -> str:
    """Generate ISO 8601 UTC timestamp."""
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def generate_packet_filename(prefix: str, packet_id: str) -> str:
    """
    Generate packet filename.
    
    Args:
        prefix: "req" or "res"
        packet_id: Packet ID
        
    Returns:
        Filename like "req_<packet_id>.json"
    """
    return f"{prefix}_{packet_id}.json"


def is_request_file(filename: str) -> bool:
    """Check if filename is a request packet."""
    return filename.startswith("req_") and filename.endswith(".json")


def is_response_file(filename: str) -> bool:
    """Check if filename is a response packet."""
    return filename.startswith("res_") and filename.endswith(".json")


def extract_packet_id(filename: str) -> Optional[str]:
    """
    Extract packet ID from filename.
    
    Args:
        filename: "req_<id>.json" or "res_<id>.json"
        
    Returns:
        Packet ID or None if invalid format
    """
    if not (is_request_file(filename) or is_response_file(filename)):
        return None
    
    # Remove prefix and suffix
    packet_id = filename[4:-5]  # Strip "req_" or "res_" and ".json"
    return packet_id if packet_id else None

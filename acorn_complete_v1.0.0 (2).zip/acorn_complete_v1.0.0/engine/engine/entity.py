"""engine.entity

Phase 5: Typed entities with explicit schemas.

Conservative / deterministic constraints:
- No persistence
- No randomness
- No wall-clock time
- Pure validation helpers
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


# Static entity schemas (Phase 5.0)
ENTITY_SCHEMAS: Dict[str, Dict[str, Dict[str, Any]]] = {
    "counter": {
        "value": {"type": "int", "default": 0, "bounds": [-1000, 1000]},
    },
    "flag": {
        "enabled": {"type": "bool", "default": False},
    },
    "container": {
        "items": {"type": "list[str]", "default": [], "max_length": 100},
    },
}


@dataclass
class Entity:
    """A single typed entity."""

    entity_id: str
    entity_type: str
    state: Dict[str, Any]


class EntityValidationError(ValueError):
    """Base class for schema-related validation errors."""

    def __init__(self, code: str, message: str, *, entity_id: Optional[str] = None):
        super().__init__(message)
        self.code = code
        self.entity_id = entity_id


def build_default_state(entity_type: str) -> Dict[str, Any]:
    """Build default state for an entity type (deep-copy safe)."""

    if entity_type not in ENTITY_SCHEMAS:
        raise EntityValidationError(
            "INVALID_ENTITY_TYPE",
            f"Unknown entity type '{entity_type}'.",
        )

    schema = ENTITY_SCHEMAS[entity_type]
    state: Dict[str, Any] = {}
    for field_name, spec in schema.items():
        # For list defaults, always create a new list.
        default = spec.get("default")
        if isinstance(default, list):
            state[field_name] = list(default)
        else:
            state[field_name] = default
    return state


def validate_entity(entity: Entity) -> None:
    """Validate entity against its schema.

    Raises EntityValidationError on violations.
    """

    if entity.entity_type not in ENTITY_SCHEMAS:
        raise EntityValidationError(
            "INVALID_ENTITY_TYPE",
            f"Entity '{entity.entity_id}' has invalid type '{entity.entity_type}'.",
            entity_id=entity.entity_id,
        )

    schema = ENTITY_SCHEMAS[entity.entity_type]

    # Ensure required fields exist
    for field_name in schema.keys():
        if field_name not in entity.state:
            raise EntityValidationError(
                "ENTITY_SCHEMA_VIOLATION",
                f"Entity '{entity.entity_id}' missing required field '{field_name}'.",
                entity_id=entity.entity_id,
            )

    # Validate each field
    for field_name, spec in schema.items():
        value = entity.state.get(field_name)
        field_type = spec.get("type")

        if field_type == "int":
            if not isinstance(value, int):
                raise EntityValidationError(
                    "ENTITY_SCHEMA_VIOLATION",
                    f"Entity '{entity.entity_id}' field '{field_name}' must be int.",
                    entity_id=entity.entity_id,
                )
            bounds = spec.get("bounds")
            if bounds is not None:
                lo, hi = bounds
                if value < lo or value > hi:
                    raise EntityValidationError(
                        "RULE_VIOLATION",
                        f"Entity '{entity.entity_id}' field '{field_name}' out of bounds ({lo}..{hi}).",
                        entity_id=entity.entity_id,
                    )

        elif field_type == "bool":
            if not isinstance(value, bool):
                raise EntityValidationError(
                    "ENTITY_SCHEMA_VIOLATION",
                    f"Entity '{entity.entity_id}' field '{field_name}' must be bool.",
                    entity_id=entity.entity_id,
                )

        elif field_type == "list[str]":
            if not isinstance(value, list) or any(not isinstance(x, str) for x in value):
                raise EntityValidationError(
                    "ENTITY_SCHEMA_VIOLATION",
                    f"Entity '{entity.entity_id}' field '{field_name}' must be list[str].",
                    entity_id=entity.entity_id,
                )
            max_len = spec.get("max_length")
            if max_len is not None and len(value) > max_len:
                raise EntityValidationError(
                    "RULE_VIOLATION",
                    f"Entity '{entity.entity_id}' field '{field_name}' exceeds max_length {max_len}.",
                    entity_id=entity.entity_id,
                )

        else:
            # Phase 5.0 should never reach here.
            raise EntityValidationError(
                "INVALID_ENTITY_STATE",
                f"Unsupported schema type '{field_type}' for '{entity.entity_type}.{field_name}'.",
                entity_id=entity.entity_id,
            )


def normalize_entity_state(entity_type: str, state: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Normalize state for an entity type.

    - If state is None, returns defaults.
    - If state provided, overlays onto defaults, then validates.
    """

    base = build_default_state(entity_type)
    if state:
        for k, v in state.items():
            base[k] = v
    temp = Entity(entity_id="__temp__", entity_type=entity_type, state=base)
    validate_entity(temp)
    return base

"""engine.scenario_engine

Phase 6: ScenarioEngine (deterministic progression orchestration).

Extends WorldEngine with:
- Scenario registry (hardcoded)
- Mode management (sandbox, scenario_active, scenario_complete)
- Command filtering based on mode
- Explicit progression commands

Conservative constraints:
- No autonomy (all progression is human-commanded)
- No new rules (reuses Phase 5 rules)
- No randomness or time-based behavior
- Deterministic scenario transitions
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from console.schema import ExecutionContext, ExecutionResult, Packet

from .world_engine import WorldEngine, Event
from .world_state import EntityConfig, WorldState
from .scenario import Condition, Scenario, ScenarioValidationError
from .rule_engine import RuleEngine
from .rules import WORLD_DEFAULT_RULE_IDS
from .parameters import ParameterStore, ParametersView


class ScenarioEngine(WorldEngine):
    """Deterministic scenario orchestration engine (Phase 6.0).
    
    Extends WorldEngine with scenario progression while preserving all
    Phase 0-5 guarantees.
    """
    
    def __init__(self, *, baseline_entities: Optional[Dict[str, EntityConfig]] = None, parameter_store: Optional[ParameterStore] = None):
        """Initialize scenario engine with hardcoded scenario registry."""
        super().__init__(baseline_entities=baseline_entities)
        
        # Phase 8: Optional parameter store (bounded) for indirect rule thresholds
        self._parameter_store = parameter_store
        self._parameters_view: Optional[ParametersView] = parameter_store.view() if parameter_store is not None else None

        # Build hardcoded scenario registry
        self._scenarios = self._build_scenario_registry()
        
        # Override WorldState to use Phase 7.1 schema version
        self._world.schema_version = "7.1"
        self._world.rules_version = "7.1"
        
        # Register Phase 6 commands
        self._registry.update(self._build_scenario_commands())
    
    def _build_scenario_registry(self) -> Dict[str, Scenario]:
        """Build hardcoded scenario registry.
        
        Returns:
            Dictionary mapping scenario_id to Scenario
        """
        return {
            "tutorial_basic": Scenario(
                scenario_id="tutorial_basic",
                description="Learn basic counter operations",
                initial_world_constraints=[
                    Condition(
                        entity_id="counter_1",
                        field="value",
                        operator="==",
                        value=0
                    )
                ],
                active_rule_ids=["counter_threshold"],  # Phase 5 rule
                exit_conditions=[
                    Condition(
                        entity_id="counter_1",
                        field="value",
                        operator=">=",
                        value=5
                    )
                ],
                next_scenarios=["tutorial_intermediate"]
            ),
            "tutorial_intermediate": Scenario(
                scenario_id="tutorial_intermediate",
                description="Learn flag operations",
                initial_world_constraints=[
                    Condition(
                        entity_id="flag_1",
                        field="enabled",
                        operator="==",
                        value=False
                    )
                ],
                active_rule_ids=[],  # No special rules
                exit_conditions=[
                    Condition(
                        entity_id="flag_1",
                        field="enabled",
                        operator="==",
                        value=True
                    )
                ],
                next_scenarios=["tutorial_advanced"]
            ),
            "tutorial_advanced": Scenario(
                scenario_id="tutorial_advanced",
                description="Learn container operations",
                initial_world_constraints=[
                    Condition(
                        entity_id="container_1",
                        field="items",
                        operator="==",
                        value=[]
                    )
                ],
                active_rule_ids=[],
                exit_conditions=[
                    Condition(
                        entity_id="container_1",
                        field="items",
                        operator="!=",
                        value=[]
                    )
                ],
                next_scenarios=[]  # Final scenario
            )
        }
    
    def _build_scenario_commands(self) -> Dict[str, Dict[str, Any]]:
        """Build scenario command registry.
        
        Returns:
            Dictionary of scenario commands
        """
        return {
            "scenario.list": {
                "scope": "world",
                "handler": self._cmd_scenario_list
            },
            "scenario.activate": {
                "scope": "world",
                "handler": self._cmd_scenario_activate
            },
            "scenario.status": {
                "scope": "world",
                "handler": self._cmd_scenario_status
            },
            "scenario.advance": {
                "scope": "world",
                "handler": self._cmd_scenario_advance
            },
            "scenario.reset": {
                "scope": "world",
                "handler": self._cmd_scenario_reset
            }
        }
    
    def _cmd_help(
        self,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> Tuple[Any, List[Event], Optional[str]]:
        """Override help to include scenario commands."""
        lines = [
            "Available commands:",
            "  World: help, world.get, world.reset, echo",
            "  Scenario: scenario.list, scenario.activate, scenario.status, scenario.advance, scenario.reset",
            "  Entity: entity.get, entity.reset",
            "  Counter: counter.inc, counter.dec, counter.set",
            "  Flag: flag.enable, flag.disable, flag.toggle",
            "  Container: container.add, container.remove, container.clear",
        ]
        return ("\n".join(lines), [], None)
    
    def execute(self, packet: Packet, context: ExecutionContext) -> ExecutionResult:
        """Execute packet with mode-based command filtering.
        
        Overrides WorldEngine.execute to add command filtering based on mode.
        """
        # Check if command is allowed in current mode
        if "command" in packet.payload:
            command = packet.payload["command"]
            mode_check = self._check_command_allowed_in_mode(command)
            if mode_check is not None:
                return mode_check  # Return error result
        
        # Delegate to parent WorldEngine
        return super().execute(packet, context)
    
    def _check_command_allowed_in_mode(self, command: str) -> Optional[ExecutionResult]:
        """Check if command is allowed in current mode.
        
        Args:
            command: Command to check
            
        Returns:
            ExecutionResult with error if not allowed, None if allowed
        """
        mode = self._world.mode
        
        # Define mode permissions
        if mode == "scenario_active":
            # In scenario mode, certain commands are forbidden
            forbidden = ["scenario.activate", "world.reset"]
            if command in forbidden:
                return self._error(
                    "temporary_packet_id",  # Will be overridden by caller
                    "INVALID_COMMAND_IN_MODE",
                    f"Command '{command}' not allowed in mode '{mode}'",
                    extra={"mode": mode, "command": command}
                )
        
        # All other modes allow all commands
        return None
    
    # ---- Scenario Commands ----
    
    def _cmd_scenario_list(
        self,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> Tuple[Any, List[Event], Optional[str]]:
        """List all available scenarios.
        
        Returns:
            Tuple of (result, events, changed_entity)
        """
        scenarios_info = []
        for scenario_id in sorted(self._scenarios.keys()):
            scenario = self._scenarios[scenario_id]
            scenarios_info.append({
                "scenario_id": scenario.scenario_id,
                "description": scenario.description
            })
        
        result = {
            "scenarios": scenarios_info,
            "count": len(scenarios_info)
        }
        
        return (result, [], None)
    
    def _cmd_scenario_activate(
        self,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> Tuple[Any, List[Event], Optional[str]]:
        """Activate a scenario.
        
        Args must contain:
            scenario_id: str - Scenario to activate
        """
        # Get scenario_id from args
        if "scenario_id" not in args:
            raise ValueError("Missing required argument: scenario_id")
        
        scenario_id = args["scenario_id"]
        
        # Check if scenario exists
        if scenario_id not in self._scenarios:
            raise ValueError(f"Scenario '{scenario_id}' not found")
        
        # Check if a scenario is already active
        if self._world.active_scenario_id is not None:
            raise ValueError(
                f"Scenario '{self._world.active_scenario_id}' is already active. "
                "Use scenario.reset first."
            )
        
        scenario = self._scenarios[scenario_id]
        
        # Check initial constraints
        satisfied, violations = scenario.check_initial_constraints(self._world)
        if not satisfied:
            raise ValueError(
                f"Initial world constraints not satisfied for '{scenario_id}': " +
                ", ".join(violations)
            )
        
        # Activate scenario
        self._world.active_scenario_id = scenario_id
        self._world.mode = "scenario_active"
        
        result = f"Scenario activated: {scenario_id}"
        events = [{
            "type": "SCENARIO_ACTIVATED",
            "scenario_id": scenario_id,
            "description": scenario.description
        }]
        
        return (result, events, None)
    
    def _cmd_scenario_status(
        self,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> Tuple[Any, List[Event], Optional[str]]:
        """Show current scenario status.
        
        Returns status of active scenario including exit conditions.
        """
        if self._world.active_scenario_id is None:
            result = {
                "mode": self._world.mode,
                "active_scenario": None,
                "message": "No scenario active"
            }
            return (result, [], None)
        
        scenario = self._scenarios[self._world.active_scenario_id]
        
        # Check exit conditions
        ready, unsatisfied = scenario.check_exit_conditions(self._world)
        
        # Build condition status
        condition_status = []
        for condition in scenario.exit_conditions:
            entity = self._world.entities.get(condition.entity_id)
            current = entity.state.get(condition.field) if entity else "N/A"
            satisfied = condition.evaluate(self._world)
            
            condition_status.append({
                "condition": f"{condition.entity_id}.{condition.field} {condition.operator} {condition.value}",
                "current_value": current,
                "satisfied": satisfied
            })
        
        result = {
            "mode": self._world.mode,
            "active_scenario": self._world.active_scenario_id,
            "description": scenario.description,
            "exit_conditions": condition_status,
            "ready_to_advance": ready,
            "next_scenarios": scenario.next_scenarios
        }
        
        return (result, [], None)
    
    def _cmd_scenario_advance(
        self,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> Tuple[Any, List[Event], Optional[str]]:
        """Advance to next scenario.
        
        Args must contain:
            scenario_id: str - Next scenario to advance to
        """
        # Check if a scenario is active
        if self._world.active_scenario_id is None:
            raise ValueError("No scenario is currently active")
        
        # Get next scenario_id from args
        if "scenario_id" not in args:
            raise ValueError("Missing required argument: scenario_id")
        
        next_scenario_id = args["scenario_id"]
        
        current_scenario = self._scenarios[self._world.active_scenario_id]
        
        # Check exit conditions
        ready, unsatisfied = current_scenario.check_exit_conditions(self._world)
        if not ready:
            raise ValueError(
                f"Exit conditions not satisfied for '{self._world.active_scenario_id}': " +
                ", ".join(unsatisfied)
            )
        
        # Check if next_scenario is valid
        if next_scenario_id not in current_scenario.next_scenarios:
            raise ValueError(
                f"Cannot advance to '{next_scenario_id}' from '{self._world.active_scenario_id}'. " +
                f"Valid next scenarios: {', '.join(current_scenario.next_scenarios) if current_scenario.next_scenarios else 'none'}"
            )
        
        # Check if next scenario exists
        if next_scenario_id not in self._scenarios:
            raise ValueError(f"Next scenario '{next_scenario_id}' not found")
        
        next_scenario = self._scenarios[next_scenario_id]
        
        # Check initial constraints for next scenario
        satisfied, violations = next_scenario.check_initial_constraints(self._world)
        if not satisfied:
            raise ValueError(
                f"Initial constraints not satisfied for '{next_scenario_id}': " +
                ", ".join(violations)
            )
        
        # Advance to next scenario
        old_scenario_id = self._world.active_scenario_id
        self._world.active_scenario_id = next_scenario_id
        self._world.mode = "scenario_active"
        
        result = f"Scenario advanced: {old_scenario_id} → {next_scenario_id}"
        events = [{
            "type": "SCENARIO_ADVANCED",
            "from_scenario": old_scenario_id,
            "to_scenario": next_scenario_id
        }]
        
        return (result, events, None)
    
    def _cmd_scenario_reset(
        self,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> Tuple[Any, List[Event], Optional[str]]:
        """Reset (deactivate) current scenario.
        
        Does NOT reset world entities - only deactivates scenario.
        """
        if self._world.active_scenario_id is None:
            result = "No scenario active"
            return (result, [], None)
        
        old_scenario_id = self._world.active_scenario_id
        
        # Deactivate scenario
        self._world.active_scenario_id = None
        self._world.mode = "sandbox"
        
        result = f"Scenario deactivated: {old_scenario_id}"
        events = [{
            "type": "SCENARIO_DEACTIVATED",
            "scenario_id": old_scenario_id
        }]
        
        return (result, events, None)
    
    def _check_world_rules(self, changed_entity: str, prev_world_state: Optional['WorldState'] = None) -> List[Event]:
        """Check world rules using Phase 7 RuleEngine with Phase 7.1 edge detection.
        
        Overrides WorldEngine._check_world_rules to use declarative rule system.
        Determines which rules are enabled based on mode:
        - sandbox mode: WORLD_DEFAULT_RULE_IDS
        - scenario_active mode: active_scenario.active_rule_ids
        - scenario_complete mode: WORLD_DEFAULT_RULE_IDS
        
        Phase 7.1: Passes previous state snapshot to RuleEngine for edge detection.
        
        Args:
            changed_entity: Entity ID that was changed (preserved for compatibility,
                           but Phase 7 evaluates all rules regardless)
            prev_world_state: Previous state snapshot (for edge rules)
            
        Returns:
            List of events emitted by rules
        """
        # Determine enabled rules based on mode
        if self._world.active_scenario_id is not None:
            # Scenario active - use scenario's rule selection
            scenario = self._scenarios[self._world.active_scenario_id]
            enabled_rule_ids = scenario.active_rule_ids
        else:
            # Sandbox or scenario_complete - use defaults
            enabled_rule_ids = WORLD_DEFAULT_RULE_IDS
        
        # Evaluate rules using Phase 7 RuleEngine with Phase 7.1 edge detection
        try:
            events = RuleEngine.evaluate(
                current_world_state=self._world,
                enabled_rule_ids=enabled_rule_ids,
                prev_world_state=prev_world_state,
                parameters_view=(self._parameter_store.view() if self._parameter_store is not None else None)
            )
        except ValueError as e:
            # Unknown rule ID referenced by scenario
            # This should not happen if scenarios are properly validated,
            # but we handle it gracefully by returning no events
            # and logging the error in events
            events = [{
                "type": "RULE_EVALUATION_ERROR",
                "error": str(e)
            }]
        
        return events

"""
Executor - Execution boundary layer for Phase 3.
CRITICAL: All exceptions must be caught here and converted to ExecutionResult.
"""

import time
from typing import Dict, Any

from console.schema import Packet, ExecutionContext, ExecutionResult
from .base import BaseEngine, UnknownPacketType


class Executor:
    """
    Execution boundary - creates context, invokes engine, catches ALL exceptions.
    
    Responsibilities:
        - Create ephemeral ExecutionContext per packet
        - Call engine.execute()
        - Catch ALL exceptions
        - Convert failures to ExecutionResult
        - NEVER re-raise
    
    Hard Rules:
        ❌ No exception escapes this module
        ❌ No logging-as-control-flow
        ❌ No retries
        ❌ No async
    """
    
    def __init__(self, engine: BaseEngine):
        """
        Initialize executor with engine instance.
        
        Args:
            engine: Engine implementation to execute packets
        """
        self._engine = engine
    
    def dispatch(self, packet: Packet) -> ExecutionResult:
        """
        Dispatch packet to engine within ephemeral context.
        
        This is the execution boundary - ALL exceptions are caught here
        and converted to structured error results. The REPL never crashes.
        
        Args:
            packet: Validated packet to execute
            
        Returns:
            ExecutionResult (always, never raises)
        """
        # Create ephemeral context
        context = self._create_context(packet)
        
        # Execute within try-except boundary
        try:
            # Call engine - may raise UnknownPacketType or any Exception
            return self._engine.execute(packet, context)
            
        except UnknownPacketType as e:
            # Known error: unsupported packet type
            return ExecutionResult(
                status="error",
                packet_id=packet.metadata.packet_id,
                output=None,
                error={
                    "code": "UNSUPPORTED_PACKET_TYPE",
                    "packet_type": packet.packet_type,
                    "message": str(e)
                }
            )
            
        except Exception as e:
            # Unexpected error: catch everything else
            return ExecutionResult(
                status="error",
                packet_id=packet.metadata.packet_id,
                output=None,
                error={
                    "code": "INTERNAL_ERROR",
                    "type": type(e).__name__,
                    "message": str(e)
                }
            )
    
    def _create_context(self, packet: Packet) -> ExecutionContext:
        """
        Create ephemeral execution context for packet.
        
        Args:
            packet: Packet to create context for
            
        Returns:
            Frozen ExecutionContext (new instance per packet)
        """
        return ExecutionContext(
            correlation_id=packet.metadata.packet_id,
            engine_timestamp=time.monotonic(),  # Use monotonic time
            scope={}  # Empty scope - ephemeral
        )

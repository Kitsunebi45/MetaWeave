"""Phase 19 Curriculum Module — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module provides curriculum and teaching tooling for Spore Engine.      ║
║                                                                              ║
║  CRITICAL CONSTRAINTS:                                                       ║
║  - Data-only lesson/curriculum definitions (JSON)                            ║
║  - Deterministic execution (no randomness, no wall-clock dependence)         ║
║  - Linear ordering only (no branching, no scoring)                           ║
║  - Teaching via Phase 16 pathway (no bypass)                                 ║
║  - Dry-run mode validates without mutation                                   ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝

Usage:
    from engine.curriculum import (
        LessonStore, CurriculumStore,
        load_lesson, load_curriculum,
        create_runner
    )
    
    # Create stores
    lesson_store = LessonStore()
    curriculum_store = CurriculumStore()
    
    # Load lessons and curricula
    lesson = load_lesson({"lesson_id": "l1", ...})
    lesson_store.add(lesson)
    
    curriculum = load_curriculum({"curriculum_id": "c1", "lessons": ["l1"]})
    curriculum_store.add(curriculum)
    
    # Create runner
    runner = create_runner(interface_api, lesson_store, curriculum_store)
    
    # Run curriculum
    report = runner.run("c1", dry=False)
"""

from .errors import (
    CurriculumError,
    CurriculumException,
    SchemaError,
    SemanticError,
    ExecutionError,
    create_schema_error,
    create_semantic_error,
    create_execution_error
)

from .loader import (
    Preconditions,
    Lesson,
    Curriculum,
    LessonStore,
    CurriculumStore,
    load_lesson,
    load_curriculum,
    load_lesson_from_file,
    load_curriculum_from_file
)

from .validator import (
    ValidationResult,
    CurriculumValidator,
    validate_lesson,
    validate_curriculum
)

from .report import (
    RunMode,
    RunStatus,
    LessonStatus,
    LessonResult,
    CurriculumReport,
    create_report,
    create_lesson_result
)

from .runner import (
    CurriculumRunner,
    create_runner
)

__all__ = [
    # Errors
    'CurriculumError',
    'CurriculumException',
    'SchemaError',
    'SemanticError',
    'ExecutionError',
    'create_schema_error',
    'create_semantic_error',
    'create_execution_error',
    
    # Data Objects
    'Preconditions',
    'Lesson',
    'Curriculum',
    
    # Stores
    'LessonStore',
    'CurriculumStore',
    
    # Loaders
    'load_lesson',
    'load_curriculum',
    'load_lesson_from_file',
    'load_curriculum_from_file',
    
    # Validation
    'ValidationResult',
    'CurriculumValidator',
    'validate_lesson',
    'validate_curriculum',
    
    # Reports
    'RunMode',
    'RunStatus',
    'LessonStatus',
    'LessonResult',
    'CurriculumReport',
    'create_report',
    'create_lesson_result',
    
    # Runner
    'CurriculumRunner',
    'create_runner'
]

__version__ = "19.0.0"

"""Phase 19 Curriculum Loader — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module loads lessons and curricula from JSON files.                    ║
║  Performs schema validation on load (fail-fast).                             ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .errors import create_schema_error, create_semantic_error


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass(frozen=True)
class Preconditions:
    """Lesson preconditions."""
    min_value: Optional[float] = None
    max_value: Optional[float] = None


@dataclass(frozen=True)
class Lesson:
    """Immutable lesson definition."""
    lesson_id: str
    target_entity: str
    skill: str
    delta: float
    reason: str
    preconditions: Optional[Preconditions] = None


@dataclass(frozen=True)
class Curriculum:
    """Immutable curriculum definition."""
    curriculum_id: str
    lessons: tuple  # Tuple of lesson_id strings, in execution order
    name: Optional[str] = None
    description: Optional[str] = None


# =============================================================================
# SCHEMA LOADING
# =============================================================================

def _load_schema(schema_name: str) -> Dict[str, Any]:
    """Load a JSON schema from the schemas directory."""
    schema_dir = Path(__file__).parent / "schemas"
    schema_path = schema_dir / schema_name
    
    if not schema_path.exists():
        raise create_schema_error(None, f"Schema not found: {schema_name}")
    
    with open(schema_path, 'r') as f:
        return json.load(f)


def _get_lesson_schema() -> Dict[str, Any]:
    """Get the lesson JSON schema."""
    return _load_schema("lesson.schema.v1.0.json")


def _get_curriculum_schema() -> Dict[str, Any]:
    """Get the curriculum JSON schema."""
    return _load_schema("curriculum.schema.v1.0.json")


# =============================================================================
# VALIDATION
# =============================================================================

def _validate_against_schema(data: Dict[str, Any], schema: Dict[str, Any], context: str) -> None:
    """Validate data against a JSON schema (simplified validation).
    
    This performs basic validation without external dependencies.
    For production use, consider jsonschema library.
    """
    # Check required fields
    for required in schema.get("required", []):
        if required not in data:
            raise create_schema_error(required, f"{context}: Missing required field '{required}'")
    
    # Check additionalProperties
    if schema.get("additionalProperties") is False:
        allowed = set(schema.get("properties", {}).keys())
        for key in data.keys():
            if key not in allowed:
                raise create_schema_error(key, f"{context}: Unexpected field '{key}'")
    
    # Check property types
    for prop_name, prop_schema in schema.get("properties", {}).items():
        if prop_name not in data:
            continue
        
        value = data[prop_name]
        expected_type = prop_schema.get("type")
        
        if expected_type == "string":
            if not isinstance(value, str):
                raise create_schema_error(prop_name, f"{context}: Field '{prop_name}' must be string")
            min_len = prop_schema.get("minLength", 0)
            if len(value) < min_len:
                raise create_schema_error(prop_name, f"{context}: Field '{prop_name}' must have minLength {min_len}")
        
        elif expected_type == "number":
            if not isinstance(value, (int, float)):
                raise create_schema_error(prop_name, f"{context}: Field '{prop_name}' must be number")
        
        elif expected_type == "array":
            if not isinstance(value, list):
                raise create_schema_error(prop_name, f"{context}: Field '{prop_name}' must be array")
            # Validate array items
            items_schema = prop_schema.get("items", {})
            if items_schema.get("type") == "string":
                for i, item in enumerate(value):
                    if not isinstance(item, str):
                        raise create_schema_error(f"{prop_name}[{i}]", f"{context}: Array item must be string")
                    min_len = items_schema.get("minLength", 0)
                    if len(item) < min_len:
                        raise create_schema_error(f"{prop_name}[{i}]", f"{context}: Array item must have minLength {min_len}")
        
        elif expected_type == "object":
            if not isinstance(value, dict):
                raise create_schema_error(prop_name, f"{context}: Field '{prop_name}' must be object")
            # Recursively validate nested object
            _validate_against_schema(value, prop_schema, f"{context}.{prop_name}")


# =============================================================================
# LOADERS
# =============================================================================

def load_lesson(data: Dict[str, Any]) -> Lesson:
    """Load and validate a lesson from a dictionary.
    
    Args:
        data: Lesson data dictionary
        
    Returns:
        Validated Lesson object
        
    Raises:
        SchemaError: If validation fails
    """
    schema = _get_lesson_schema()
    _validate_against_schema(data, schema, "Lesson")
    
    # Build preconditions if present
    preconditions = None
    if "preconditions" in data:
        pre_data = data["preconditions"]
        preconditions = Preconditions(
            min_value=pre_data.get("min_value"),
            max_value=pre_data.get("max_value")
        )
    
    return Lesson(
        lesson_id=data["lesson_id"],
        target_entity=data["target_entity"],
        skill=data["skill"],
        delta=float(data["delta"]),
        reason=data["reason"],
        preconditions=preconditions
    )


def load_curriculum(data: Dict[str, Any]) -> Curriculum:
    """Load and validate a curriculum from a dictionary.
    
    Args:
        data: Curriculum data dictionary
        
    Returns:
        Validated Curriculum object
        
    Raises:
        SchemaError: If validation fails
    """
    schema = _get_curriculum_schema()
    _validate_against_schema(data, schema, "Curriculum")
    
    return Curriculum(
        curriculum_id=data["curriculum_id"],
        lessons=tuple(data["lessons"]),
        name=data.get("name"),
        description=data.get("description")
    )


def load_lesson_from_file(path: Path) -> Lesson:
    """Load a lesson from a JSON file.
    
    Args:
        path: Path to lesson JSON file
        
    Returns:
        Validated Lesson object
    """
    if not path.exists():
        raise create_schema_error(None, f"Lesson file not found: {path}")
    
    with open(path, 'r') as f:
        data = json.load(f)
    
    return load_lesson(data)


def load_curriculum_from_file(path: Path) -> Curriculum:
    """Load a curriculum from a JSON file.
    
    Args:
        path: Path to curriculum JSON file
        
    Returns:
        Validated Curriculum object
    """
    if not path.exists():
        raise create_schema_error(None, f"Curriculum file not found: {path}")
    
    with open(path, 'r') as f:
        data = json.load(f)
    
    return load_curriculum(data)


# =============================================================================
# LESSON STORE
# =============================================================================

class LessonStore:
    """In-memory store for lessons.
    
    Enforces no duplicate lesson_id.
    """
    
    def __init__(self):
        self._lessons: Dict[str, Lesson] = {}
    
    def add(self, lesson: Lesson) -> None:
        """Add a lesson to the store.
        
        Raises:
            SemanticError: If lesson_id already exists
        """
        if lesson.lesson_id in self._lessons:
            raise create_semantic_error(
                "lesson_id",
                f"Duplicate lesson_id: {lesson.lesson_id}"
            )
        self._lessons[lesson.lesson_id] = lesson
    
    def get(self, lesson_id: str) -> Optional[Lesson]:
        """Get a lesson by ID."""
        return self._lessons.get(lesson_id)
    
    def has(self, lesson_id: str) -> bool:
        """Check if lesson exists."""
        return lesson_id in self._lessons
    
    def all(self) -> List[Lesson]:
        """Get all lessons."""
        return list(self._lessons.values())
    
    def count(self) -> int:
        """Get number of lessons."""
        return len(self._lessons)
    
    def clear(self) -> None:
        """Clear all lessons."""
        self._lessons.clear()


# =============================================================================
# CURRICULUM STORE
# =============================================================================

class CurriculumStore:
    """In-memory store for curricula."""
    
    def __init__(self):
        self._curricula: Dict[str, Curriculum] = {}
    
    def add(self, curriculum: Curriculum) -> None:
        """Add a curriculum to the store.
        
        Raises:
            SemanticError: If curriculum_id already exists
        """
        if curriculum.curriculum_id in self._curricula:
            raise create_semantic_error(
                "curriculum_id",
                f"Duplicate curriculum_id: {curriculum.curriculum_id}"
            )
        self._curricula[curriculum.curriculum_id] = curriculum
    
    def get(self, curriculum_id: str) -> Optional[Curriculum]:
        """Get a curriculum by ID."""
        return self._curricula.get(curriculum_id)
    
    def has(self, curriculum_id: str) -> bool:
        """Check if curriculum exists."""
        return curriculum_id in self._curricula
    
    def all(self) -> List[Curriculum]:
        """Get all curricula."""
        return list(self._curricula.values())
    
    def count(self) -> int:
        """Get number of curricula."""
        return len(self._curricula)
    
    def clear(self) -> None:
        """Clear all curricula."""
        self._curricula.clear()

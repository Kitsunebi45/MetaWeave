"""Phase 19 Curriculum Report — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module produces structured JSON reports for curriculum execution.      ║
║  Reports are deterministic and stable in shape.                              ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from enum import Enum
import json


class RunMode(Enum):
    """Curriculum run mode."""
    DRY = "dry"
    LIVE = "live"


class RunStatus(Enum):
    """Curriculum run status."""
    PASS = "PASS"
    FAIL = "FAIL"


class LessonStatus(Enum):
    """Individual lesson status."""
    PENDING = "PENDING"
    PASS = "PASS"
    FAIL = "FAIL"
    SKIPPED = "SKIPPED"


@dataclass
class LessonResult:
    """Result for a single lesson execution."""
    lesson_id: str
    target_entity: str
    skill: str
    delta: float
    status: LessonStatus = LessonStatus.PENDING
    error: Optional[str] = None
    previous_value: Optional[float] = None
    new_value: Optional[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "lesson_id": self.lesson_id,
            "target_entity": self.target_entity,
            "skill": self.skill,
            "delta": self.delta,
            "status": self.status.value,
        }
        if self.error:
            result["error"] = self.error
        if self.previous_value is not None:
            result["previous_value"] = self.previous_value
        if self.new_value is not None:
            result["new_value"] = self.new_value
        return result


@dataclass
class CurriculumReport:
    """Structured report for curriculum execution."""
    curriculum_id: str
    mode: RunMode
    started: str  # ISO-8601 timestamp
    completed: Optional[str] = None  # ISO-8601 timestamp
    status: RunStatus = RunStatus.PASS
    lessons_executed: int = 0
    lesson_results: List[LessonResult] = field(default_factory=list)
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "curriculum_id": self.curriculum_id,
            "mode": self.mode.value,
            "started": self.started,
            "completed": self.completed,
            "status": self.status.value,
            "lessons_executed": self.lessons_executed,
            "lesson_results": [lr.to_dict() for lr in self.lesson_results],
            "error": self.error,
        }
    
    def to_json(self, indent: int = 2) -> str:
        """Serialize to JSON."""
        return json.dumps(self.to_dict(), indent=indent)
    
    def mark_completed(self, status: RunStatus, error: Optional[str] = None) -> None:
        """Mark the report as completed.
        
        Args:
            status: Final status
            error: Optional error message
        """
        self.completed = datetime.now(timezone.utc).isoformat()
        self.status = status
        self.error = error
    
    def add_lesson_result(self, result: LessonResult) -> None:
        """Add a lesson result.
        
        Args:
            result: Lesson result to add
        """
        self.lesson_results.append(result)
        if result.status == LessonStatus.PASS:
            self.lessons_executed += 1


def create_report(curriculum_id: str, mode: RunMode) -> CurriculumReport:
    """Create a new curriculum report.
    
    Args:
        curriculum_id: Curriculum ID
        mode: Run mode (dry or live)
        
    Returns:
        New CurriculumReport
    """
    return CurriculumReport(
        curriculum_id=curriculum_id,
        mode=mode,
        started=datetime.now(timezone.utc).isoformat()
    )


def create_lesson_result(
    lesson_id: str,
    target_entity: str,
    skill: str,
    delta: float
) -> LessonResult:
    """Create a new lesson result.
    
    Args:
        lesson_id: Lesson ID
        target_entity: Target entity ID
        skill: Skill name
        delta: Delta value
        
    Returns:
        New LessonResult
    """
    return LessonResult(
        lesson_id=lesson_id,
        target_entity=target_entity,
        skill=skill,
        delta=delta
    )

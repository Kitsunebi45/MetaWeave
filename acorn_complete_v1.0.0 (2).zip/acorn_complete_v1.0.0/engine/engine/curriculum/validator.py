"""Phase 19 Curriculum Validator — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module performs semantic validation of lessons and curricula.          ║
║                                                                              ║
║  Validation checks:                                                          ║
║  - All referenced lesson_id values exist in store                            ║
║  - delta is finite (not NaN/Inf)                                             ║
║  - Preconditions are coherent (min_value <= max_value)                       ║
║                                                                              ║
║  Entity existence is NOT checked unless engine state is provided.            ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import math
from dataclasses import dataclass
from typing import List, Optional

from .loader import Lesson, Curriculum, LessonStore
from .errors import create_semantic_error, SemanticError


@dataclass(frozen=True)
class ValidationResult:
    """Result of validation."""
    valid: bool
    errors: tuple  # Tuple of SemanticError


def validate_lesson(lesson: Lesson) -> ValidationResult:
    """Validate a single lesson semantically.
    
    Checks:
    - delta is finite (not NaN/Inf)
    - preconditions are coherent (min_value <= max_value)
    
    Args:
        lesson: Lesson to validate
        
    Returns:
        ValidationResult
    """
    errors = []
    
    # Check delta is finite
    if math.isnan(lesson.delta) or math.isinf(lesson.delta):
        errors.append(create_semantic_error(
            "delta",
            f"Lesson {lesson.lesson_id}: delta must be finite (got {lesson.delta})"
        ))
    
    # Check preconditions coherence
    if lesson.preconditions:
        pre = lesson.preconditions
        if pre.min_value is not None and pre.max_value is not None:
            if pre.min_value > pre.max_value:
                errors.append(create_semantic_error(
                    "preconditions",
                    f"Lesson {lesson.lesson_id}: min_value ({pre.min_value}) > max_value ({pre.max_value})"
                ))
    
    return ValidationResult(
        valid=len(errors) == 0,
        errors=tuple(errors)
    )


def validate_curriculum(curriculum: Curriculum, lesson_store: LessonStore) -> ValidationResult:
    """Validate a curriculum semantically.
    
    Checks:
    - All referenced lesson_id values exist in the store
    - All referenced lessons are valid
    
    Args:
        curriculum: Curriculum to validate
        lesson_store: Store containing available lessons
        
    Returns:
        ValidationResult
    """
    errors = []
    
    # Check all lesson_ids exist
    for i, lesson_id in enumerate(curriculum.lessons):
        if not lesson_store.has(lesson_id):
            errors.append(create_semantic_error(
                f"lessons[{i}]",
                f"Curriculum {curriculum.curriculum_id}: lesson_id '{lesson_id}' not found"
            ))
        else:
            # Validate the lesson itself
            lesson = lesson_store.get(lesson_id)
            lesson_result = validate_lesson(lesson)
            errors.extend(lesson_result.errors)
    
    return ValidationResult(
        valid=len(errors) == 0,
        errors=tuple(errors)
    )


def validate_preconditions_against_state(
    lesson: Lesson,
    current_value: float
) -> ValidationResult:
    """Validate lesson preconditions against current skill value.
    
    Args:
        lesson: Lesson with optional preconditions
        current_value: Current skill value
        
    Returns:
        ValidationResult
    """
    errors = []
    
    if lesson.preconditions:
        pre = lesson.preconditions
        
        if pre.min_value is not None and current_value < pre.min_value:
            errors.append(create_semantic_error(
                "preconditions.min_value",
                f"Lesson {lesson.lesson_id}: current value ({current_value}) < min_value ({pre.min_value})"
            ))
        
        if pre.max_value is not None and current_value > pre.max_value:
            errors.append(create_semantic_error(
                "preconditions.max_value",
                f"Lesson {lesson.lesson_id}: current value ({current_value}) > max_value ({pre.max_value})"
            ))
    
    return ValidationResult(
        valid=len(errors) == 0,
        errors=tuple(errors)
    )


class CurriculumValidator:
    """Validator for lessons and curricula.
    
    Performs semantic validation. Does NOT validate entity existence
    unless explicitly provided with engine state.
    """
    
    def __init__(self, lesson_store: LessonStore):
        """Initialize validator.
        
        Args:
            lesson_store: Store containing available lessons
        """
        self._lesson_store = lesson_store
    
    def validate_lesson(self, lesson: Lesson) -> ValidationResult:
        """Validate a single lesson."""
        return validate_lesson(lesson)
    
    def validate_curriculum(self, curriculum: Curriculum) -> ValidationResult:
        """Validate a curriculum."""
        return validate_curriculum(curriculum, self._lesson_store)
    
    def validate_all_lessons(self) -> ValidationResult:
        """Validate all lessons in store."""
        errors = []
        
        for lesson in self._lesson_store.all():
            result = validate_lesson(lesson)
            errors.extend(result.errors)
        
        return ValidationResult(
            valid=len(errors) == 0,
            errors=tuple(errors)
        )

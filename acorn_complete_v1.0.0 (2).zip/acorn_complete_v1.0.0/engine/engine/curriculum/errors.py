"""Phase 19 Curriculum Errors — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module defines error classes for the curriculum system.                ║
║  Error classes consistent with prior phases:                                 ║
║  - SCHEMA_ERROR: JSON Schema validation failed                               ║
║  - SEMANTIC_ERROR: Semantic validation failed                                ║
║  - EXECUTION_ERROR: Runtime execution failed                                 ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from dataclasses import dataclass, asdict
from typing import Optional
import json


@dataclass(frozen=True)
class CurriculumError:
    """Structured curriculum error."""
    error_class: str
    field_path: Optional[str]
    message: str
    
    def to_json(self) -> str:
        """Serialize to one-line JSON."""
        return json.dumps(asdict(self), separators=(',', ':'))
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return asdict(self)


class CurriculumException(Exception):
    """Base exception for curriculum errors."""
    
    def __init__(self, error: CurriculumError):
        self.error = error
        super().__init__(error.message)
    
    def to_json(self) -> str:
        return self.error.to_json()
    
    def to_dict(self) -> dict:
        return self.error.to_dict()


class SchemaError(CurriculumException):
    """JSON Schema validation failed."""
    pass


class SemanticError(CurriculumException):
    """Semantic validation failed."""
    pass


class ExecutionError(CurriculumException):
    """Runtime execution failed."""
    pass


# Error factories
def create_schema_error(field_path: Optional[str], message: str) -> SchemaError:
    """Create a schema validation error."""
    return SchemaError(CurriculumError(
        error_class="SCHEMA_ERROR",
        field_path=field_path,
        message=message
    ))


def create_semantic_error(field_path: Optional[str], message: str) -> SemanticError:
    """Create a semantic validation error."""
    return SemanticError(CurriculumError(
        error_class="SEMANTIC_ERROR",
        field_path=field_path,
        message=message
    ))


def create_execution_error(field_path: Optional[str], message: str) -> ExecutionError:
    """Create an execution error."""
    return ExecutionError(CurriculumError(
        error_class="EXECUTION_ERROR",
        field_path=field_path,
        message=message
    ))

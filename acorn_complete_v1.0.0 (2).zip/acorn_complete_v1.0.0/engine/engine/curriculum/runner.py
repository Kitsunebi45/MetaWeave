"""Phase 19 Curriculum Runner — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module executes curricula deterministically.                           ║
║                                                                              ║
║  CRITICAL CONSTRAINTS:                                                       ║
║  - Lessons execute strictly in order listed in curriculum                    ║
║  - No retries                                                                ║
║  - No parallelism                                                            ║
║  - Teaching invoked via Phase 16 pathway (not direct)                        ║
║  - Dry-run mode MUST NOT mutate state                                        ║
║  - Live-run halts on first failure                                           ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from typing import Optional

from .loader import Lesson, Curriculum, LessonStore, CurriculumStore
from .validator import CurriculumValidator, validate_preconditions_against_state
from .report import (
    CurriculumReport, LessonResult, RunMode, RunStatus, LessonStatus,
    create_report, create_lesson_result
)
from .errors import create_execution_error, ExecutionError


class CurriculumRunner:
    """Executes curricula deterministically.
    
    CRITICAL: All teaching is invoked via Phase 16 pathway.
    This runner MUST NOT write engine state directly.
    
    Modes:
    - DRY RUN: Validate only, no mutation
    - LIVE RUN: Execute lessons sequentially, halt on first failure
    """
    
    def __init__(
        self,
        interface_api,
        lesson_store: LessonStore,
        curriculum_store: CurriculumStore
    ):
        """Initialize runner.
        
        Args:
            interface_api: Phase 16 InterfaceAPI instance
            lesson_store: Store containing lessons
            curriculum_store: Store containing curricula
        """
        self._api = interface_api
        self._lesson_store = lesson_store
        self._curriculum_store = curriculum_store
        self._validator = CurriculumValidator(lesson_store)
        
        # Import router for command parsing
        from ..interface.command_router import CommandRouter
        self._router = CommandRouter()
    
    def _get_current_skill_value(self, entity_id: str, skill: str) -> Optional[float]:
        """Get current skill value via Phase 16 read API.
        
        Args:
            entity_id: Entity ID
            skill: Skill name
            
        Returns:
            Current value or None if not found
        """
        try:
            parsed = self._router.parse(f"show learning {entity_id}")
            response = self._api.execute(parsed)
            
            if response.success and response.data:
                skills = response.data.get("skills", {})
                if skill in skills:
                    return float(skills[skill])
            return None
        except Exception:
            return None
    
    def _execute_teaching(self, lesson: Lesson) -> tuple:
        """Execute teaching via Phase 16 pathway.
        
        CRITICAL: This uses the same pathway as 'teach entity ...' command.
        
        Args:
            lesson: Lesson to execute
            
        Returns:
            Tuple of (success: bool, error: Optional[str], new_value: Optional[float])
        """
        try:
            # Build teach command
            cmd = f'teach entity {lesson.target_entity} {lesson.skill} {lesson.delta} reason "{lesson.reason}"'
            
            # Parse and execute via Phase 16
            parsed = self._router.parse(cmd)
            response = self._api.execute(parsed)
            
            if response.success:
                new_value = response.data.get("new_value") if response.data else None
                return (True, None, new_value)
            else:
                error_msg = response.error.get("message") if response.error else "Unknown error"
                return (False, error_msg, None)
                
        except Exception as e:
            return (False, str(e), None)
    
    def dry_run(self, curriculum_id: str) -> CurriculumReport:
        """Perform dry-run validation.
        
        MUST NOT mutate state.
        
        Args:
            curriculum_id: Curriculum to validate
            
        Returns:
            CurriculumReport with validation results
        """
        report = create_report(curriculum_id, RunMode.DRY)
        
        # Get curriculum
        curriculum = self._curriculum_store.get(curriculum_id)
        if not curriculum:
            report.mark_completed(RunStatus.FAIL, f"Curriculum not found: {curriculum_id}")
            return report
        
        # Validate curriculum
        validation = self._validator.validate_curriculum(curriculum)
        if not validation.valid:
            error_msgs = [e.error.message for e in validation.errors]
            report.mark_completed(RunStatus.FAIL, "; ".join(error_msgs))
            return report
        
        # Dry-run each lesson (validation only)
        for lesson_id in curriculum.lessons:
            lesson = self._lesson_store.get(lesson_id)
            
            result = create_lesson_result(
                lesson_id=lesson.lesson_id,
                target_entity=lesson.target_entity,
                skill=lesson.skill,
                delta=lesson.delta
            )
            
            # Check current value if preconditions exist
            if lesson.preconditions:
                current_value = self._get_current_skill_value(
                    lesson.target_entity, lesson.skill
                )
                
                if current_value is not None:
                    result.previous_value = current_value
                    
                    pre_validation = validate_preconditions_against_state(
                        lesson, current_value
                    )
                    
                    if not pre_validation.valid:
                        error_msgs = [e.error.message for e in pre_validation.errors]
                        result.status = LessonStatus.FAIL
                        result.error = "; ".join(error_msgs)
                        report.add_lesson_result(result)
                        report.mark_completed(RunStatus.FAIL, f"Precondition failed for {lesson_id}")
                        return report
            
            # Mark as passed (dry-run validation)
            result.status = LessonStatus.PASS
            report.add_lesson_result(result)
        
        report.mark_completed(RunStatus.PASS)
        return report
    
    def live_run(self, curriculum_id: str) -> CurriculumReport:
        """Execute curriculum live.
        
        Executes lessons sequentially. Halts on first failure.
        
        Args:
            curriculum_id: Curriculum to execute
            
        Returns:
            CurriculumReport with execution results
        """
        report = create_report(curriculum_id, RunMode.LIVE)
        
        # Get curriculum
        curriculum = self._curriculum_store.get(curriculum_id)
        if not curriculum:
            report.mark_completed(RunStatus.FAIL, f"Curriculum not found: {curriculum_id}")
            return report
        
        # Validate curriculum first
        validation = self._validator.validate_curriculum(curriculum)
        if not validation.valid:
            error_msgs = [e.error.message for e in validation.errors]
            report.mark_completed(RunStatus.FAIL, "; ".join(error_msgs))
            return report
        
        # Execute each lesson in order
        for lesson_id in curriculum.lessons:
            lesson = self._lesson_store.get(lesson_id)
            
            result = create_lesson_result(
                lesson_id=lesson.lesson_id,
                target_entity=lesson.target_entity,
                skill=lesson.skill,
                delta=lesson.delta
            )
            
            # Get current value
            current_value = self._get_current_skill_value(
                lesson.target_entity, lesson.skill
            )
            result.previous_value = current_value
            
            # Check preconditions
            if lesson.preconditions and current_value is not None:
                pre_validation = validate_preconditions_against_state(
                    lesson, current_value
                )
                
                if not pre_validation.valid:
                    error_msgs = [e.error.message for e in pre_validation.errors]
                    result.status = LessonStatus.FAIL
                    result.error = "; ".join(error_msgs)
                    report.add_lesson_result(result)
                    report.mark_completed(RunStatus.FAIL, f"Precondition failed for {lesson_id}")
                    return report
            
            # Execute teaching via Phase 16
            success, error, new_value = self._execute_teaching(lesson)
            
            if success:
                result.status = LessonStatus.PASS
                result.new_value = new_value
            else:
                result.status = LessonStatus.FAIL
                result.error = error
                report.add_lesson_result(result)
                report.mark_completed(RunStatus.FAIL, f"Execution failed for {lesson_id}: {error}")
                return report
            
            report.add_lesson_result(result)
        
        report.mark_completed(RunStatus.PASS)
        return report
    
    def run(self, curriculum_id: str, dry: bool = False) -> CurriculumReport:
        """Run a curriculum.
        
        Args:
            curriculum_id: Curriculum to run
            dry: If True, perform dry-run (no mutation)
            
        Returns:
            CurriculumReport
        """
        if dry:
            return self.dry_run(curriculum_id)
        else:
            return self.live_run(curriculum_id)


def create_runner(
    interface_api,
    lesson_store: LessonStore,
    curriculum_store: CurriculumStore
) -> CurriculumRunner:
    """Factory function to create a curriculum runner.
    
    Args:
        interface_api: Phase 16 InterfaceAPI instance
        lesson_store: Store containing lessons
        curriculum_store: Store containing curricula
        
    Returns:
        CurriculumRunner instance
    """
    return CurriculumRunner(interface_api, lesson_store, curriculum_store)

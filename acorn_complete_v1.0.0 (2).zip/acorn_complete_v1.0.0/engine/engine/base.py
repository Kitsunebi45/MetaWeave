"""
Abstract engine contract for Acorn Engine Phase 3.
Defines the execution interface all engines must implement.
"""

from abc import ABC, abstractmethod
from console.schema import Packet, ExecutionContext, ExecutionResult


class BaseEngine(ABC):
    """
    Abstract base class for all engine implementations.
    
    Engines MUST:
    - Not raise exceptions (return ExecutionResult with error instead)
    - Not mutate packets
    - Not persist state
    - Not access identity storage
    """
    
    @abstractmethod
    def execute(
        self,
        packet: Packet,
        context: ExecutionContext
    ) -> ExecutionResult:
        """
        Execute a validated packet within an ephemeral context.
        
        Args:
            packet: Validated packet (immutable)
            context: Ephemeral execution context (frozen)
            
        Returns:
            ExecutionResult with status, output, and optional error
            
        MUST NOT:
            - Raise exceptions (catch internally, return error result)
            - Mutate packet or context
            - Access persistence or identity storage
            - Spawn threads or async tasks
        """
        pass


class UnknownPacketType(Exception):
    """
    Raised when engine encounters unsupported packet type.
    Executor will catch this and convert to structured error.
    """
    pass

"""engine.rule_engine

Phase 7: Rule evaluation engine.
Phase 7.1: Edge-triggered rules (false→true detection).

This module provides deterministic rule evaluation:
- Single-pass evaluation (no cascading)
- Events-only effects (no mutations)
- Deterministic ordering
- No hidden state
- Edge detection via ephemeral snapshot comparison

The RuleEngine evaluates enabled rules against world state and returns
events to be included in the ExecutionResult.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .parameters import ParametersView

from .rules import RULE_REGISTRY, Rule, EventSpec, RuleTriggerType
from .scenario import Condition


class RuleEngine:
    """Deterministic rule evaluation engine.
    
    Evaluates rules in a single pass, emitting events without mutating entities.
    Supports both level-triggered (Phase 7) and edge-triggered (Phase 7.1) rules.
    """
    
    @staticmethod
    def evaluate(
        current_world_state: Any,
        enabled_rule_ids: List[str],
        prev_world_state: Optional[Any] = None,
        parameters_view: Optional[ParametersView] = None,
    ) -> List[Dict[str, Any]]:
        """Evaluate enabled rules against current (and optionally previous) world state.
        
        Rules are evaluated in deterministic order (lexicographic by rule_id).
        Each rule's conditions are checked (AND semantics), and if all match,
        the rule's events are emitted.
        
        Phase 7.1: If prev_world_state is provided, EDGE rules check for
        false→true transitions. LEVEL rules ignore prev_world_state.
        
        Args:
            current_world_state: Current WorldState object
            enabled_rule_ids: List of rule IDs to evaluate
            prev_world_state: Previous WorldState snapshot (for edge detection)
            
        Returns:
            List of events (dictionaries) emitted by matching rules
            
        Raises:
            ValueError: If enabled_rule_ids references unknown rules
        """
        events: List[Dict[str, Any]] = []
        
        # Sort rule IDs for deterministic ordering
        sorted_rule_ids = sorted(enabled_rule_ids)
        
        for rule_id in sorted_rule_ids:
            # Validate rule exists
            if rule_id not in RULE_REGISTRY:
                # Fail loudly - don't silently skip unknown rules
                raise ValueError(f"Unknown rule ID: '{rule_id}'")
            
            rule = RULE_REGISTRY[rule_id]
            
            # Evaluate rule based on trigger type
            if rule.trigger == RuleTriggerType.LEVEL:
                # LEVEL: Fire whenever conditions are true (Phase 7 behavior)
                if RuleEngine._evaluate_conditions(rule, current_world_state, parameters_view):
                    events.extend(RuleEngine._emit_events(rule, current_world_state))
            
            elif rule.trigger == RuleTriggerType.EDGE:
                # EDGE: Fire only on false→true transition (Phase 7.1)
                current_match = RuleEngine._evaluate_conditions(rule, current_world_state, parameters_view)
                
                if current_match:
                    # Conditions are true now - check if they were false before
                    if prev_world_state is None:
                        # First command or no snapshot - treat as edge trigger
                        # (all conditions were "false" before world existed)
                        events.extend(RuleEngine._emit_events(rule, current_world_state))
                    else:
                        # Check if ANY condition was false in previous state
                        prev_match = RuleEngine._evaluate_conditions(rule, prev_world_state, parameters_view)
                        if not prev_match:
                            # False→True transition detected
                            events.extend(RuleEngine._emit_events(rule, current_world_state))
        
        return events
    
    @staticmethod
    def _evaluate_conditions(rule: Rule, world_state: Any, parameters_view: Optional[ParametersView]) -> bool:
        """Evaluate if all conditions in a rule match.
        
        Args:
            rule: Rule to evaluate
            world_state: WorldState to check against
            
        Returns:
            True if ALL conditions match (AND semantics), False otherwise
        """
        # Empty condition list is forbidden by Rule validation
        # But defensive check here
        if not rule.when_all:
            return False
        
        # AND semantics: all conditions must be true
        for condition in rule.when_all:
            # Phase 8: Parameter influence boundary (R11) - indirect influence only
            # Only applies to counter threshold rules and only adjusts a numeric threshold.
            if parameters_view is not None and rule.rule_id in ("counter_threshold", "counter_threshold_edge"):
                try:
                    if condition.entity_id == "counter_1" and condition.field == "value" and condition.operator == ">" and condition.value == 3:
                        # Replace literal threshold with bounded parameter value
                        threshold = parameters_view.get_int("counter_threshold", 3)
                        # Evaluate without mutating condition
                        if "counter_1" not in world_state.entities:
                            return False
                        entity = world_state.entities["counter_1"]
                        if "value" not in entity.state:
                            return False
                        actual_value = entity.state["value"]
                        if type(actual_value) is not int:
                            return False
                        if not (actual_value > threshold):
                            return False
                        # Condition satisfied; continue to next condition
                        continue
                except Exception:
                    return False
            try:
                if not condition.evaluate(world_state):
                    return False
            except (KeyError, TypeError, AttributeError):
                # Condition evaluation failed (missing entity/field, type mismatch)
                # Treat as non-match rather than error
                return False
        
        return True
    
    @staticmethod
    def _emit_events(rule: Rule, world_state: Any) -> List[Dict[str, Any]]:
        """Emit events from a matching rule.
        
        Args:
            rule: Rule whose events to emit
            world_state: Current world state (for dynamic payload values)
            
        Returns:
            List of event dictionaries
        """
        events: List[Dict[str, Any]] = []
        
        for event_spec in rule.emit:
            # For Phase 7.0, we emit static events
            # Future: could enhance EventSpec to support dynamic payload values
            event = event_spec.to_event()
            
            # Add dynamic value if event references counter_1
            # This preserves Phase 5 behavior exactly
            if event.get("entity") == "counter_1":
                entity = world_state.entities.get("counter_1")
                if entity:
                    event["value"] = entity.state.get("value")
            
            events.append(event)
        
        return events
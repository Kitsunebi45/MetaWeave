"""
Phase 12.1 Engine IO Bridge

Wrapper for Phase 11 IO components to be used by run_system.py
"""

from pathlib import Path
from threading import Thread
import time


class EngineIOBridge:
    """
    IO Bridge for engine-side file transport.
    
    Wraps Phase 11 IO processor in a managed lifecycle.
    """
    
    def __init__(self, engine, outbox_dir: Path, inbox_dir: Path):
        """
        Initialize IO bridge.
        
        Args:
            engine: Engine instance (not used in Phase 11 file-based mode)
            outbox_dir: Path to outbox directory
            inbox_dir: Path to inbox directory
        """
        self.outbox_dir = Path(outbox_dir)
        self.inbox_dir = Path(inbox_dir)
        self.runtime_io_dir = outbox_dir.parent
        
        self._processor = None
        self._thread = None
        self._running = False
    
    def start(self):
        """
        Start IO bridge in background thread.
        
        For Phase 11 file-based transport, this starts the
        engine IO processor loop.
        """
        # Import here to avoid circular dependencies
        from run_io import EngineIOProcessor
        
        self._processor = EngineIOProcessor(self.runtime_io_dir)
        self._running = True
        
        # Start polling loop in background thread
        self._thread = Thread(
            target=self._run_loop,
            daemon=True,
            name="IOBridge"
        )
        self._thread.start()
    
    def _run_loop(self):
        """Background polling loop."""
        poll_interval = 0.1  # 100ms
        
        while self._running:
            try:
                self._processor.run_once()
            except Exception as e:
                # Log but don't crash
                print(f"[IOBridge] Error: {e}")
            
            time.sleep(poll_interval)
    
    def stop(self):
        """Stop IO bridge."""
        self._running = False
        
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)

"""
Phase 11 Engine - Replay Guard

Tracks processed packet IDs to prevent duplicate execution.
"""

import json
from pathlib import Path
from typing import Set


class ReplayGuard:
    """
    Tracks processed packet IDs to prevent replay attacks.
    
    Uses simple JSONL log of seen packet IDs.
    """
    
    def __init__(self, seen_dir: Path):
        """
        Initialize replay guard.
        
        Args:
            seen_dir: Path to runtime_io/seen
        """
        self.seen_dir = Path(seen_dir)
        self.seen_dir.mkdir(parents=True, exist_ok=True)
        
        self.seen_log = self.seen_dir / "seen_packets.jsonl"
        
        # Load seen packet IDs into memory
        self._seen_ids: Set[str] = set()
        self._load_seen_ids()
    
    def _load_seen_ids(self) -> None:
        """Load seen packet IDs from disk."""
        if not self.seen_log.exists():
            return
        
        with open(self.seen_log, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                
                try:
                    entry = json.loads(line)
                    packet_id = entry.get('packet_id')
                    if packet_id:
                        self._seen_ids.add(packet_id)
                except json.JSONDecodeError:
                    # Skip malformed lines
                    continue
    
    def has_seen(self, packet_id: str) -> bool:
        """
        Check if packet ID has been seen before.
        
        Args:
            packet_id: Packet ID to check
            
        Returns:
            True if packet has been seen
        """
        return packet_id in self._seen_ids
    
    def mark_seen(self, packet_id: str) -> None:
        """
        Mark packet ID as seen.
        
        Args:
            packet_id: Packet ID to mark
        """
        if packet_id in self._seen_ids:
            return  # Already seen
        
        # Add to memory set
        self._seen_ids.add(packet_id)
        
        # Append to log
        entry = {
            'packet_id': packet_id,
            'timestamp': self._get_timestamp(),
        }
        
        with open(self.seen_log, 'a') as f:
            f.write(json.dumps(entry) + '\n')
    
    def _get_timestamp(self) -> str:
        """Get current UTC timestamp."""
        from datetime import datetime, timezone
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    
    def get_seen_count(self) -> int:
        """
        Get count of seen packet IDs.
        
        Returns:
            Number of unique packet IDs seen
        """
        return len(self._seen_ids)
    
    def clear(self) -> None:
        """
        Clear all seen packet IDs.
        
        WARNING: This allows replay of all previous packets.
        Use with caution.
        """
        self._seen_ids.clear()
        
        if self.seen_log.exists():
            self.seen_log.unlink()

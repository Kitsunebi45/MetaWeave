"""
Phase 11 Engine - Inbox Writer

Atomic response packet writing to inbox.
"""

import json
import os
from pathlib import Path

from io_bridge.io_schema import ResponsePacket, generate_packet_filename


class InboxWriter:
    """
    Writes response packets to inbox atomically.
    
    Uses same atomic pattern as console outbox writer:
    1. Write to temp file (.tmp)
    2. Fsync (if supported)
    3. Rename to final name
    """
    
    def __init__(self, inbox_dir: Path):
        """
        Initialize inbox writer.
        
        Args:
            inbox_dir: Path to runtime_io/inbox
        """
        self.inbox_dir = Path(inbox_dir)
        self.inbox_dir.mkdir(parents=True, exist_ok=True)
    
    def write_response(self, response: ResponsePacket) -> Path:
        """
        Write response packet atomically.
        
        Args:
            response: ResponsePacket to write
            
        Returns:
            Path to written file
            
        Raises:
            IOError: If write fails
        """
        # Validate response first
        response.validate()
        
        # Generate filename
        filename = generate_packet_filename("res", response.packet_id)
        final_path = self.inbox_dir / filename
        temp_path = self.inbox_dir / f"{filename}.tmp"
        
        try:
            # Write to temp file
            with open(temp_path, 'w') as f:
                f.write(response.to_json())
                f.flush()
                
                # Fsync if available
                if hasattr(os, 'fsync'):
                    os.fsync(f.fileno())
            
            # Atomic rename
            temp_path.replace(final_path)
            
            return final_path
            
        except Exception as e:
            # Clean up temp file on error
            if temp_path.exists():
                temp_path.unlink()
            raise IOError(f"Failed to write response packet: {e}")
    
    def has_response(self, packet_id: str) -> bool:
        """
        Check if response already exists.
        
        Args:
            packet_id: Packet ID to check
            
        Returns:
            True if response file exists
        """
        filename = generate_packet_filename("res", packet_id)
        response_path = self.inbox_dir / filename
        return response_path.exists()

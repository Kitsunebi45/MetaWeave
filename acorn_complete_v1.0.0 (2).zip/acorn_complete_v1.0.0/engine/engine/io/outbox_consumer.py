"""
Phase 11 Engine - Outbox Consumer

Polls outbox for request packets and loads them.
"""

import json
import os
from pathlib import Path
from typing import List, Optional

from io_bridge.io_schema import RequestPacket, is_request_file


class OutboxConsumer:
    """
    Polls and consumes request packets from outbox.
    """
    
    def __init__(self, outbox_dir: Path):
        """
        Initialize outbox consumer.
        
        Args:
            outbox_dir: Path to runtime_io/outbox
        """
        self.outbox_dir = Path(outbox_dir)
        self.outbox_dir.mkdir(parents=True, exist_ok=True)
    
    def poll(self) -> List[RequestPacket]:
        """
        Poll outbox for pending requests.
        
        Returns:
            List of RequestPacket objects
        """
        requests = []
        
        if not self.outbox_dir.exists():
            return requests
        
        # List all files in outbox
        for filename in os.listdir(self.outbox_dir):
            # Skip temp files and non-request files
            if filename.endswith('.tmp'):
                continue
            
            if not is_request_file(filename):
                continue
            
            # Try to load request
            try:
                request = self.load_request(filename)
                requests.append(request)
            except Exception:
                # Skip invalid requests
                # In production, log this
                continue
        
        return requests
    
    def load_request(self, filename: str) -> RequestPacket:
        """
        Load specific request by filename.
        
        Args:
            filename: Request filename (e.g., "req_<id>.json")
            
        Returns:
            RequestPacket
            
        Raises:
            ValueError: If request is invalid
            FileNotFoundError: If file doesn't exist
        """
        request_path = self.outbox_dir / filename
        
        if not request_path.exists():
            raise FileNotFoundError(f"Request not found: {filename}")
        
        with open(request_path, 'r') as f:
            data = json.load(f)
        
        return RequestPacket.from_dict(data)
    
    def delete_request(self, filename: str) -> bool:
        """
        Delete request packet after processing.
        
        Args:
            filename: Request filename to delete
            
        Returns:
            True if deleted, False if not found
        """
        request_path = self.outbox_dir / filename
        
        if request_path.exists():
            request_path.unlink()
            return True
        
        return False
    
    def get_pending_count(self) -> int:
        """
        Get count of pending requests.
        
        Returns:
            Number of request files in outbox
        """
        if not self.outbox_dir.exists():
            return 0
        
        count = 0
        for filename in os.listdir(self.outbox_dir):
            if is_request_file(filename) and not filename.endswith('.tmp'):
                count += 1
        
        return count

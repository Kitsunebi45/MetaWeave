"""
NoOpEngine - Reference implementation for Phase 3.
Minimal engine that echoes commands and validates wiring.
"""

from console.schema import Packet, ExecutionContext, ExecutionResult
from .base import BaseEngine, UnknownPacketType


class NoOpEngine(BaseEngine):
    """
    Reference engine implementation for Phase 3.
    
    Behavior:
        - Accepts "command" packet type
        - Echoes raw_input from payload
        - Returns success with simple output
        - Raises UnknownPacketType for other packet types
    
    Purpose:
        - Validate wiring
        - Prove determinism
        - Prevent logic creep
    """
    
    def execute(
        self,
        packet: Packet,
        context: ExecutionContext
    ) -> ExecutionResult:
        """
        Execute packet - echo command or reject unknown type.
        
        Args:
            packet: Validated packet
            context: Ephemeral execution context
            
        Returns:
            ExecutionResult with echoed command or error
            
        Raises:
            UnknownPacketType: For non-command packet types
        """
        # Only handle "command" packet type
        if packet.packet_type != "command":
            raise UnknownPacketType(
                f"NoOpEngine only handles 'command' packets, got '{packet.packet_type}'"
            )
        
        # Extract raw input from payload
        raw_input = packet.payload.get("raw_input", "")
        
        # Echo back with simple formatting
        output = f"Echo: {raw_input}"
        
        # Return success result
        return ExecutionResult(
            status="success",
            packet_id=packet.metadata.packet_id,
            output=output,
            error=None
        )

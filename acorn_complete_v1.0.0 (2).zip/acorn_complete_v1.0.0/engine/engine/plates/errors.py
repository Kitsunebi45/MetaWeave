"""Phase 13.1 Error Classes — Production Implementation.

All errors carry structured data and serialize to one-line JSON for stderr output.
Error classes conform to Phase 13 spec error taxonomy.
"""

from dataclasses import dataclass, asdict
from typing import Optional
import json


@dataclass(frozen=True)
class PlateError:
    """Structured error for plate validation failures.
    
    All errors MUST include:
    - error_class: One of SCHEMA_ERROR, SEMANTIC_ERROR, COMPAT_ERROR, INTEGRITY_ERROR, CONFLICT_ERROR
    - plate_id: Plate that caused error (if identifiable)
    - field_path: JSON path to offending field (if applicable)
    - message: Human-readable description
    """
    error_class: str
    plate_id: Optional[str]
    field_path: Optional[str]
    message: str
    
    def to_json(self) -> str:
        """Serialize to one-line JSON for stderr output."""
        return json.dumps(asdict(self), separators=(',', ':'))
    
    def __str__(self) -> str:
        return self.to_json()


class PlateValidationError(Exception):
    """Base exception for plate validation failures."""
    
    def __init__(self, error: PlateError):
        self.error = error
        super().__init__(error.message)
    
    def to_json(self) -> str:
        return self.error.to_json()


class SchemaError(PlateValidationError):
    """JSON schema validation failure.
    
    Raised when:
    - JSON parsing fails
    - Required fields are missing
    - Field types are incorrect
    - Enum values are invalid
    """
    pass


class SemanticError(PlateValidationError):
    """Semantic validation failure.
    
    Raised when:
    - References point to nonexistent IDs
    - world_ref doesn't match any WORLD plate
    - rule_id not in engine registry
    - template_id or region_id not found
    """
    pass


class CompatError(PlateValidationError):
    """Engine compatibility failure.
    
    Raised when:
    - engine_compat range not satisfied by current engine version
    """
    pass


class IntegrityError(PlateValidationError):
    """Checksum or hash mismatch.
    
    Raised when:
    - source.checksum doesn't match computed value
    - schema_hash on entity templates conflict
    """
    pass


class ConflictError(PlateValidationError):
    """Stacking conflict failure.
    
    Raised when:
    - resonance_key collision within stack
    - Incompatible topology modes in WORLD plates
    - Forbidden stacking conflicts
    """
    pass


# Error class constants for validation
ERROR_CLASSES = frozenset({
    "SCHEMA_ERROR",
    "SEMANTIC_ERROR", 
    "COMPAT_ERROR",
    "INTEGRITY_ERROR",
    "CONFLICT_ERROR"
})


def create_schema_error(plate_id: Optional[str], field_path: Optional[str], message: str) -> SchemaError:
    """Factory for SchemaError."""
    return SchemaError(PlateError(
        error_class="SCHEMA_ERROR",
        plate_id=plate_id,
        field_path=field_path,
        message=message
    ))


def create_semantic_error(plate_id: Optional[str], field_path: Optional[str], message: str) -> SemanticError:
    """Factory for SemanticError."""
    return SemanticError(PlateError(
        error_class="SEMANTIC_ERROR",
        plate_id=plate_id,
        field_path=field_path,
        message=message
    ))


def create_compat_error(plate_id: Optional[str], message: str) -> CompatError:
    """Factory for CompatError."""
    return CompatError(PlateError(
        error_class="COMPAT_ERROR",
        plate_id=plate_id,
        field_path="engine_compat",
        message=message
    ))


def create_integrity_error(plate_id: Optional[str], field_path: Optional[str], message: str) -> IntegrityError:
    """Factory for IntegrityError."""
    return IntegrityError(PlateError(
        error_class="INTEGRITY_ERROR",
        plate_id=plate_id,
        field_path=field_path,
        message=message
    ))


def create_conflict_error(plate_id: Optional[str], field_path: Optional[str], message: str) -> ConflictError:
    """Factory for ConflictError."""
    return ConflictError(PlateError(
        error_class="CONFLICT_ERROR",
        plate_id=plate_id,
        field_path=field_path,
        message=message
    ))

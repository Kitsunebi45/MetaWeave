"""Phase 13.1 PlateLoader — Production Implementation.

Performs:
- JSON parsing
- JSON Schema validation (jsonschema library)
- engine_compat SemVer range validation
- Optional checksum validation (source.checksum)

Hard-fails on:
- Malformed JSON
- Schema violations
- Engine incompatibility
- Checksum mismatch

No semantic validation here — that's the resolver's job.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional
import json
import hashlib
import re

try:
    import jsonschema
    from jsonschema import Draft202012Validator
    HAS_JSONSCHEMA = True
except ImportError:
    HAS_JSONSCHEMA = False

from .errors import (
    PlateError,
    SchemaError,
    CompatError,
    IntegrityError,
    create_schema_error,
    create_compat_error,
    create_integrity_error
)


@dataclass(frozen=True)
class Plate:
    """Immutable parsed plate.
    
    All fields are frozen after construction.
    raw_json preserved for checksum verification.
    """
    plate_id: str
    plate_type: str  # "WORLD" | "RULE" | "ENTITY" | "SCENARIO"
    name: str
    version: str
    engine_compat: str
    resonance_key: str
    created_at: str
    tags: tuple
    content: Dict[str, Any]
    source: Dict[str, Any]
    raw_json: str


# Valid plate types (Phase 13 scope)
VALID_PLATE_TYPES = frozenset({"WORLD", "RULE", "ENTITY", "SCENARIO"})

# Schema version for Phase 13
SCHEMA_VERSION = "1.0.0"


class PlateLoader:
    """Production plate loader with schema validation.
    
    Validates plates against JSON schemas shipped with the engine.
    Enforces engine_compat ranges.
    Optionally validates checksums.
    """
    
    def __init__(self, engine_version: str = "12.0.0", schema_dir: Optional[Path] = None):
        """Initialize loader.
        
        Args:
            engine_version: Current engine version for compatibility checking
            schema_dir: Directory containing JSON schemas (default: ./schemas relative to this file)
        """
        self._engine_version = engine_version
        self._engine_version_parts = self._parse_version(engine_version)
        
        # Locate schemas
        if schema_dir is None:
            schema_dir = Path(__file__).parent / "schemas"
        self._schema_dir = schema_dir
        
        # Load schemas
        self._schemas = self._load_schemas()
    
    def _parse_version(self, version: str) -> List[int]:
        """Parse version string to comparable list."""
        return [int(x) for x in version.split('.')[:3]]
    
    def _load_schemas(self) -> Dict[str, Any]:
        """Load all JSON schemas from schema directory."""
        schemas = {}
        
        schema_files = {
            "envelope": "plate.schema.v1.0.json",
            "world": "world.content.schema.v1.0.json",
            "rule": "rule.content.schema.v1.0.json",
            "entity": "entity.content.schema.v1.0.json",
            "scenario": "scenario.content.schema.v1.0.json"
        }
        
        for key, filename in schema_files.items():
            path = self._schema_dir / filename
            if path.exists():
                with open(path, 'r', encoding='utf-8') as f:
                    schemas[key] = json.load(f)
        
        return schemas
    
    def load(self, path: Path) -> Plate:
        """Load single plate from file.
        
        Performs:
        1. JSON parsing
        2. Schema validation (Choke Point #1)
        3. Engine compatibility validation
        4. Checksum validation (if present)
        
        Args:
            path: Path to plate JSON file
            
        Returns:
            Validated Plate object
            
        Raises:
            SchemaError: If JSON or schema validation fails
            CompatError: If engine compatibility fails
            IntegrityError: If checksum validation fails
            FileNotFoundError: If plate file doesn't exist
        """
        if not path.exists():
            raise FileNotFoundError(f"Plate file not found: {path}")
        
        raw_json = path.read_text(encoding='utf-8')
        return self._load_from_string(raw_json, str(path))
    
    def load_from_dict(self, data: Dict[str, Any]) -> Plate:
        """Load plate from dictionary (for testing).
        
        Args:
            data: Plate data as dictionary
            
        Returns:
            Validated Plate object
        """
        raw_json = json.dumps(data, sort_keys=True, separators=(',', ':'))
        return self._load_from_data(data, raw_json, "<dict>")
    
    def load_all(self, paths: List[Path]) -> List[Plate]:
        """Load multiple plates. Order is preserved.
        
        Fails fast on first validation error.
        
        Args:
            paths: Ordered list of plate file paths
            
        Returns:
            List of validated Plate objects in same order
        """
        return [self.load(path) for path in paths]
    
    def load_all_from_dicts(self, plates_data: List[Dict[str, Any]]) -> List[Plate]:
        """Load multiple plates from dictionaries (for testing)."""
        return [self.load_from_dict(data) for data in plates_data]
    
    def _load_from_string(self, raw_json: str, source_name: str) -> Plate:
        """Load plate from JSON string."""
        # Step 1: Parse JSON
        try:
            data = json.loads(raw_json)
        except json.JSONDecodeError as e:
            raise create_schema_error(
                plate_id=None,
                field_path=None,
                message=f"Invalid JSON in {source_name}: {e}"
            )
        
        return self._load_from_data(data, raw_json, source_name)
    
    def _load_from_data(self, data: Dict[str, Any], raw_json: str, source_name: str) -> Plate:
        """Load plate from parsed data."""
        plate_id = data.get("plate_id")
        
        # Step 2: Schema validation
        self._validate_schema(data, plate_id)
        
        # Step 3: Engine compatibility
        self._validate_engine_compat(data, plate_id)
        
        # Step 4: Checksum validation (if present)
        self._validate_checksum(data, raw_json, plate_id)
        
        # Construct immutable Plate
        return Plate(
            plate_id=data["plate_id"],
            plate_type=data["plate_type"],
            name=data["name"],
            version=data["version"],
            engine_compat=data["engine_compat"],
            resonance_key=data["resonance_key"],
            created_at=data["created_at"],
            tags=tuple(data.get("tags", [])),
            content=data["content"],
            source=data["source"],
            raw_json=raw_json
        )
    
    def _validate_schema(self, data: Dict[str, Any], plate_id: Optional[str]) -> None:
        """Validate against JSON schemas."""
        
        # If jsonschema is available, use it
        if HAS_JSONSCHEMA and "envelope" in self._schemas:
            try:
                jsonschema.validate(data, self._schemas["envelope"])
            except jsonschema.ValidationError as e:
                raise create_schema_error(
                    plate_id=plate_id,
                    field_path=e.json_path if hasattr(e, 'json_path') else str(list(e.absolute_path)),
                    message=str(e.message)
                )
        else:
            # Fallback: manual validation
            self._validate_envelope_manual(data, plate_id)
        
        # Validate content schema based on type
        plate_type = data.get("plate_type")
        content = data.get("content", {})
        
        if HAS_JSONSCHEMA:
            content_schema_key = plate_type.lower() if plate_type else None
            if content_schema_key and content_schema_key in self._schemas:
                try:
                    jsonschema.validate(content, self._schemas[content_schema_key])
                except jsonschema.ValidationError as e:
                    raise create_schema_error(
                        plate_id=plate_id,
                        field_path=f"content.{e.json_path}" if hasattr(e, 'json_path') else f"content.{list(e.absolute_path)}",
                        message=str(e.message)
                    )
        else:
            self._validate_content_manual(data, plate_id)
    
    def _validate_envelope_manual(self, data: Dict[str, Any], plate_id: Optional[str]) -> None:
        """Manual envelope validation (fallback when jsonschema unavailable)."""
        required_fields = [
            "schema_version", "plate_id", "plate_type", "name", "version",
            "resonance_key", "created_at", "tags", "content", "source", "engine_compat"
        ]
        
        for field in required_fields:
            if field not in data:
                raise create_schema_error(
                    plate_id=plate_id,
                    field_path=field,
                    message=f"Missing required field: {field}"
                )
        
        # Validate schema_version
        if data["schema_version"] != SCHEMA_VERSION:
            raise create_schema_error(
                plate_id=plate_id,
                field_path="schema_version",
                message=f"Invalid schema_version: {data['schema_version']} (expected {SCHEMA_VERSION})"
            )
        
        # Validate plate_type
        if data["plate_type"] not in VALID_PLATE_TYPES:
            raise create_schema_error(
                plate_id=plate_id,
                field_path="plate_type",
                message=f"Invalid plate_type: {data['plate_type']} (must be one of {sorted(VALID_PLATE_TYPES)})"
            )
        
        # Validate content is object
        if not isinstance(data.get("content"), dict):
            raise create_schema_error(
                plate_id=plate_id,
                field_path="content",
                message="content must be an object"
            )
        
        # Validate source is object with required fields
        source = data.get("source", {})
        if not isinstance(source, dict):
            raise create_schema_error(
                plate_id=plate_id,
                field_path="source",
                message="source must be an object"
            )
        if "author" not in source or "source_path" not in source:
            raise create_schema_error(
                plate_id=plate_id,
                field_path="source",
                message="source must contain 'author' and 'source_path'"
            )
    
    def _validate_content_manual(self, data: Dict[str, Any], plate_id: Optional[str]) -> None:
        """Manual content validation (fallback)."""
        plate_type = data["plate_type"]
        content = data["content"]
        
        if plate_type == "WORLD":
            required = ["world_id", "topology", "regions", "constraints"]
            for field in required:
                if field not in content:
                    raise create_schema_error(
                        plate_id=plate_id,
                        field_path=f"content.{field}",
                        message=f"WORLD plate missing required field: {field}"
                    )
            if "mode" not in content.get("topology", {}):
                raise create_schema_error(
                    plate_id=plate_id,
                    field_path="content.topology.mode",
                    message="WORLD topology must have mode"
                )
        
        elif plate_type == "RULE":
            required = ["rule_set_id", "enabled_rule_ids"]
            for field in required:
                if field not in content:
                    raise create_schema_error(
                        plate_id=plate_id,
                        field_path=f"content.{field}",
                        message=f"RULE plate missing required field: {field}"
                    )
        
        elif plate_type == "ENTITY":
            if "entity_templates" not in content:
                raise create_schema_error(
                    plate_id=plate_id,
                    field_path="content.entity_templates",
                    message="ENTITY plate missing required field: entity_templates"
                )
        
        elif plate_type == "SCENARIO":
            required = ["scenario_id", "world_ref", "initial_entities", "parameters"]
            for field in required:
                if field not in content:
                    raise create_schema_error(
                        plate_id=plate_id,
                        field_path=f"content.{field}",
                        message=f"SCENARIO plate missing required field: {field}"
                    )
    
    def _validate_engine_compat(self, data: Dict[str, Any], plate_id: Optional[str]) -> None:
        """Validate engine_compat range against current engine version."""
        compat_range = data.get("engine_compat", "")
        
        if not self._version_satisfies(compat_range):
            raise create_compat_error(
                plate_id=plate_id,
                message=f"Engine v{self._engine_version} does not satisfy {compat_range}"
            )
    
    def _version_satisfies(self, range_spec: str) -> bool:
        """Check if engine version satisfies range specification.
        
        Supports: >=X.Y.Z, >X.Y.Z, <=X.Y.Z, <X.Y.Z
        Combined with space for AND semantics.
        """
        if not range_spec.strip():
            return True
        
        constraints = range_spec.split()
        
        for constraint in constraints:
            constraint = constraint.strip()
            if not constraint:
                continue
                
            if constraint.startswith(">="):
                target = self._parse_version(constraint[2:])
                if self._engine_version_parts < target:
                    return False
            elif constraint.startswith(">"):
                target = self._parse_version(constraint[1:])
                if self._engine_version_parts <= target:
                    return False
            elif constraint.startswith("<="):
                target = self._parse_version(constraint[2:])
                if self._engine_version_parts > target:
                    return False
            elif constraint.startswith("<"):
                target = self._parse_version(constraint[1:])
                if self._engine_version_parts >= target:
                    return False
        
        return True
    
    def _validate_checksum(self, data: Dict[str, Any], raw_json: str, plate_id: Optional[str]) -> None:
        """Validate checksum if present in source block."""
        source = data.get("source", {})
        declared_checksum = source.get("checksum")
        
        if declared_checksum:
            # Compute canonical checksum (sorted keys, no extra whitespace)
            canonical = json.dumps(data, sort_keys=True, separators=(',', ':'))
            computed = hashlib.sha256(canonical.encode('utf-8')).hexdigest()
            
            if computed != declared_checksum:
                raise create_integrity_error(
                    plate_id=plate_id,
                    field_path="source.checksum",
                    message=f"Checksum mismatch: declared={declared_checksum[:16]}..., computed={computed[:16]}..."
                )

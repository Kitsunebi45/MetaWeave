"""Phase 13.1 PlateResolver — Production Implementation.

Deterministic resolver that enforces:
- Stack ordering rules (WORLD → RULE/ENTITY → SCENARIO)
- resonance_key uniqueness
- scenario.world_ref must match resolved WORLD world_id
- Rule IDs must exist in engine rule registry
- Entity capabilities are freeform (no registry)

Output:
- Immutable ResolvedConfig
- No engine state mutation

Connections:
- WORLD connections are bidirectional by default (v1.0)
"""

from dataclasses import dataclass
from typing import Any, Dict, FrozenSet, List, Optional, Set, Tuple
from datetime import datetime, timezone
import hashlib
import json

from .plate_loader import Plate
from .errors import (
    PlateError,
    SemanticError,
    ConflictError,
    create_semantic_error,
    create_conflict_error
)


# =============================================================================
# DATA CLASSES (Immutable)
# =============================================================================

@dataclass(frozen=True)
class Region:
    """Immutable region definition."""
    region_id: str
    name: str
    tags: Tuple[str, ...]
    properties: Dict[str, Any]


@dataclass(frozen=True)
class Connection:
    """Immutable connection definition.
    
    All connections are BIDIRECTIONAL in v1.0.
    from/to define endpoints, not direction.
    """
    from_region: str
    to_region: str
    connection_type: str
    properties: Dict[str, Any]


@dataclass(frozen=True)
class WorldConstraints:
    """Immutable world constraints."""
    max_entities: Optional[int]
    tick_rate_cap: Optional[float]
    authority_envelope_ref: Optional[str]


@dataclass(frozen=True)
class WorldConfig:
    """Immutable world configuration."""
    world_id: str
    topology_mode: str  # "graph" | "grid" | "continuous"
    regions: Tuple[Region, ...]
    connections: Tuple[Connection, ...]
    constraints: WorldConstraints


@dataclass(frozen=True)
class RuleConfig:
    """Immutable rule configuration."""
    rule_set_id: str
    enabled_rule_ids: FrozenSet[str]
    mode: str  # "allowlist" | "overlay"


@dataclass(frozen=True)
class EntityTemplate:
    """Immutable entity template."""
    template_id: str
    name: str
    tags: Tuple[str, ...]
    traits: Dict[str, Any]
    capabilities: Tuple[str, ...]  # Freeform, no registry validation
    limits: Dict[str, Any]
    schema_hash: Optional[str]


@dataclass(frozen=True)
class InitialEntity:
    """Immutable initial entity specification."""
    entity_id: str
    template_id: str
    region_id: str
    state: Dict[str, Any]


@dataclass(frozen=True)
class ScenarioConfig:
    """Immutable scenario configuration."""
    scenario_id: str
    world_ref: str
    initial_entities: Tuple[InitialEntity, ...]
    parameters: Dict[str, Any]


@dataclass(frozen=True)
class ResolvedConfig:
    """Immutable result of plate stack resolution.
    
    Determinism guarantee: Same plate stack + same order = identical ResolvedConfig
    """
    world_config: Optional[WorldConfig]
    rule_config: Optional[RuleConfig]
    entity_templates: Dict[str, EntityTemplate]
    scenario_config: Optional[ScenarioConfig]
    plate_ids: Tuple[str, ...]
    provenance: Dict[str, Tuple[str, ...]]  # field_path -> contributing plate_ids
    resolved_at: str
    checksum: str


# =============================================================================
# RESOLVER
# =============================================================================

class PlateResolver:
    """Deterministic plate stack resolver.
    
    Produces immutable ResolvedConfig from ordered plate stack.
    No engine state mutation.
    """
    
    def __init__(self, rule_registry: Set[str]):
        """Initialize resolver.
        
        Args:
            rule_registry: Set of valid rule IDs from engine
        """
        self._rule_registry = frozenset(rule_registry)
    
    def resolve(self, plates: List[Plate]) -> ResolvedConfig:
        """Resolve plate stack into configuration.
        
        Processing order:
        1. Validate ordering constraints
        2. Check resonance_key uniqueness
        3. Resolve WORLD plates
        4. Resolve RULE plates (validate rule IDs)
        5. Resolve ENTITY plates
        6. Resolve SCENARIO plates (validate refs)
        7. Build provenance map
        8. Compute deterministic checksum
        
        Args:
            plates: Ordered list of validated Plate objects
            
        Returns:
            Immutable ResolvedConfig
            
        Raises:
            SemanticError: On reference or logic failures
            ConflictError: On stacking conflicts
        """
        if not plates:
            return self._empty_config()
        
        # Step 1: Validate ordering constraints
        self._validate_ordering(plates)
        
        # Step 2: Check resonance_key uniqueness
        self._validate_resonance_keys(plates)
        
        # Step 3-6: Resolve by type
        world_config = self._resolve_worlds(plates)
        rule_config = self._resolve_rules(plates)
        entity_templates = self._resolve_entities(plates)
        scenario_config = self._resolve_scenario(plates, world_config, entity_templates)
        
        # Step 7: Build provenance
        provenance = self._build_provenance(plates)
        
        # Step 8: Compute deterministic checksum
        plate_ids = tuple(p.plate_id for p in plates)
        resolved_at = datetime.now(timezone.utc).isoformat()
        
        checksum_data = json.dumps({
            "plate_ids": plate_ids,
            "world_id": world_config.world_id if world_config else None,
            "rule_set_id": rule_config.rule_set_id if rule_config else None,
            "enabled_rules": sorted(rule_config.enabled_rule_ids) if rule_config else [],
            "template_ids": sorted(entity_templates.keys()),
            "scenario_id": scenario_config.scenario_id if scenario_config else None
        }, sort_keys=True, separators=(',', ':'))
        checksum = hashlib.sha256(checksum_data.encode('utf-8')).hexdigest()
        
        return ResolvedConfig(
            world_config=world_config,
            rule_config=rule_config,
            entity_templates=entity_templates,
            scenario_config=scenario_config,
            plate_ids=plate_ids,
            provenance=provenance,
            resolved_at=resolved_at,
            checksum=checksum
        )
    
    def _empty_config(self) -> ResolvedConfig:
        """Return empty configuration for empty stack."""
        return ResolvedConfig(
            world_config=None,
            rule_config=None,
            entity_templates={},
            scenario_config=None,
            plate_ids=(),
            provenance={},
            resolved_at=datetime.now(timezone.utc).isoformat(),
            checksum=hashlib.sha256(b"empty").hexdigest()
        )
    
    def _validate_ordering(self, plates: List[Plate]) -> None:
        """Validate plate type ordering constraints.
        
        Rules:
        - WORLD plates must be resolved before RULE and ENTITY plates
        - SCENARIO plates must be resolved last
        """
        # Find indices of each type
        world_indices = [i for i, p in enumerate(plates) if p.plate_type == "WORLD"]
        rule_indices = [i for i, p in enumerate(plates) if p.plate_type == "RULE"]
        entity_indices = [i for i, p in enumerate(plates) if p.plate_type == "ENTITY"]
        scenario_indices = [i for i, p in enumerate(plates) if p.plate_type == "SCENARIO"]
        
        # WORLD must come before RULE
        if world_indices and rule_indices:
            if max(world_indices) > min(rule_indices):
                raise create_semantic_error(
                    plate_id=plates[min(rule_indices)].plate_id,
                    field_path=None,
                    message="WORLD plates must be resolved before RULE plates"
                )
        
        # WORLD must come before ENTITY
        if world_indices and entity_indices:
            if max(world_indices) > min(entity_indices):
                raise create_semantic_error(
                    plate_id=plates[min(entity_indices)].plate_id,
                    field_path=None,
                    message="WORLD plates must be resolved before ENTITY plates"
                )
        
        # SCENARIO must be last (after all others)
        if scenario_indices:
            last_scenario = max(scenario_indices)
            all_other_indices = world_indices + rule_indices + entity_indices
            if all_other_indices and last_scenario < max(all_other_indices):
                raise create_semantic_error(
                    plate_id=plates[last_scenario].plate_id,
                    field_path=None,
                    message="SCENARIO plates must be resolved last"
                )
    
    def _validate_resonance_keys(self, plates: List[Plate]) -> None:
        """Check for resonance_key collisions.
        
        resonance_key MUST be unique within stack.
        Collision = hard fail.
        """
        seen_keys: Dict[str, str] = {}  # resonance_key -> plate_id
        
        for plate in plates:
            if plate.resonance_key in seen_keys:
                raise create_conflict_error(
                    plate_id=plate.plate_id,
                    field_path="resonance_key",
                    message=f"Resonance key collision: '{plate.resonance_key}' "
                            f"already used by plate '{seen_keys[plate.resonance_key]}'"
                )
            seen_keys[plate.resonance_key] = plate.plate_id
    
    def _resolve_worlds(self, plates: List[Plate]) -> Optional[WorldConfig]:
        """Resolve WORLD plates (last-write-wins)."""
        world_plates = [p for p in plates if p.plate_type == "WORLD"]
        
        if not world_plates:
            return None
        
        # Last world wins
        last_world = world_plates[-1]
        content = last_world.content
        
        # Build regions
        regions = tuple(
            Region(
                region_id=r["region_id"],
                name=r["name"],
                tags=tuple(r.get("tags", [])),
                properties=dict(r.get("properties", {}))
            )
            for r in content.get("regions", [])
        )
        
        # Build connections (BIDIRECTIONAL by default in v1.0)
        connections = tuple(
            Connection(
                from_region=c["from"],
                to_region=c["to"],
                connection_type=c.get("type", "path"),
                properties=dict(c.get("properties", {}))
            )
            for c in content.get("connections", [])
        )
        
        # Build constraints
        constraints_data = content.get("constraints", {})
        constraints = WorldConstraints(
            max_entities=constraints_data.get("max_entities"),
            tick_rate_cap=constraints_data.get("tick_rate_cap"),
            authority_envelope_ref=constraints_data.get("authority_envelope_ref")
        )
        
        return WorldConfig(
            world_id=content["world_id"],
            topology_mode=content["topology"]["mode"],
            regions=regions,
            connections=connections,
            constraints=constraints
        )
    
    def _resolve_rules(self, plates: List[Plate]) -> Optional[RuleConfig]:
        """Resolve RULE plates with registry validation.
        
        enabled_rule_ids MUST exist in engine rule registry.
        Unknown IDs = hard fail.
        """
        rule_plates = [p for p in plates if p.plate_type == "RULE"]
        
        if not rule_plates:
            return None
        
        # Collect enabled rule IDs
        enabled_ids: Set[str] = set()
        last_rule_set_id = None
        last_mode = "allowlist"
        
        for rule_plate in rule_plates:
            content = rule_plate.content
            last_rule_set_id = content["rule_set_id"]
            last_mode = content.get("mode", "allowlist")
            
            # Validate each rule ID exists in registry
            for rule_id in content["enabled_rule_ids"]:
                if rule_id not in self._rule_registry:
                    raise create_semantic_error(
                        plate_id=rule_plate.plate_id,
                        field_path="content.enabled_rule_ids",
                        message=f"Unknown rule_id: '{rule_id}' not in engine registry. "
                                f"Valid IDs: {sorted(self._rule_registry)}"
                    )
                enabled_ids.add(rule_id)
            
            # Handle disabled_rule_ids in overlay mode
            if last_mode == "overlay":
                for rule_id in content.get("disabled_rule_ids", []):
                    enabled_ids.discard(rule_id)
        
        return RuleConfig(
            rule_set_id=last_rule_set_id,
            enabled_rule_ids=frozenset(enabled_ids),
            mode=last_mode
        )
    
    def _resolve_entities(self, plates: List[Plate]) -> Dict[str, EntityTemplate]:
        """Resolve ENTITY plates (later overrides same template_id).
        
        capabilities are freeform strings (no registry validation).
        """
        templates: Dict[str, EntityTemplate] = {}
        
        for plate in plates:
            if plate.plate_type != "ENTITY":
                continue
            
            for tmpl in plate.content.get("entity_templates", []):
                templates[tmpl["template_id"]] = EntityTemplate(
                    template_id=tmpl["template_id"],
                    name=tmpl["name"],
                    tags=tuple(tmpl.get("tags", [])),
                    traits=dict(tmpl.get("traits", {})),
                    capabilities=tuple(tmpl.get("capabilities", [])),
                    limits=dict(tmpl.get("limits", {})),
                    schema_hash=tmpl.get("schema_hash")
                )
        
        return templates
    
    def _resolve_scenario(
        self,
        plates: List[Plate],
        world_config: Optional[WorldConfig],
        entity_templates: Dict[str, EntityTemplate]
    ) -> Optional[ScenarioConfig]:
        """Resolve SCENARIO plates with reference validation.
        
        Validates:
        - world_ref matches exactly one WORLD plate's world_id
        - template_id exists in resolved entity templates
        - region_id exists in resolved world regions
        """
        scenario_plates = [p for p in plates if p.plate_type == "SCENARIO"]
        
        if not scenario_plates:
            return None
        
        # Last scenario wins
        last_scenario = scenario_plates[-1]
        content = last_scenario.content
        
        # Validate world_ref
        world_ref = content["world_ref"]
        if world_config is None:
            raise create_semantic_error(
                plate_id=last_scenario.plate_id,
                field_path="content.world_ref",
                message=f"world_ref '{world_ref}' specified but no WORLD plates in stack"
            )
        
        if world_config.world_id != world_ref:
            raise create_semantic_error(
                plate_id=last_scenario.plate_id,
                field_path="content.world_ref",
                message=f"world_ref '{world_ref}' not found in resolved stack "
                        f"(available: '{world_config.world_id}')"
            )
        
        # Collect valid region IDs from resolved world
        valid_region_ids = {r.region_id for r in world_config.regions}
        
        # Validate and build initial entities
        initial_entities = []
        for i, entity in enumerate(content.get("initial_entities", [])):
            # Validate template_id
            template_id = entity["template_id"]
            if template_id not in entity_templates:
                raise create_semantic_error(
                    plate_id=last_scenario.plate_id,
                    field_path=f"content.initial_entities[{i}].template_id",
                    message=f"template_id '{template_id}' not found in resolved templates"
                )
            
            # Validate region_id
            region_id = entity["region_id"]
            if region_id not in valid_region_ids:
                raise create_semantic_error(
                    plate_id=last_scenario.plate_id,
                    field_path=f"content.initial_entities[{i}].region_id",
                    message=f"region_id '{region_id}' not found in world regions "
                            f"(available: {sorted(valid_region_ids)})"
                )
            
            initial_entities.append(InitialEntity(
                entity_id=entity["entity_id"],
                template_id=template_id,
                region_id=region_id,
                state=dict(entity.get("state", {}))
            ))
        
        return ScenarioConfig(
            scenario_id=content["scenario_id"],
            world_ref=world_ref,
            initial_entities=tuple(initial_entities),
            parameters=dict(content.get("parameters", {}))
        )
    
    def _build_provenance(self, plates: List[Plate]) -> Dict[str, Tuple[str, ...]]:
        """Build provenance map (field_path -> contributing plate_ids)."""
        provenance: Dict[str, List[str]] = {}
        
        for plate in plates:
            key = f"{plate.plate_type.lower()}_config"
            if key not in provenance:
                provenance[key] = []
            provenance[key].append(plate.plate_id)
        
        # Convert to tuples for immutability
        return {k: tuple(v) for k, v in provenance.items()}

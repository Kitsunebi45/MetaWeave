"""Phase 13.1 Plates Module — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module implements the Phase 13 Plate Contract (v1.0.0-final).          ║
║  Any changes require full regression testing against A-F acceptance tests.   ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-23                                                          ║
║  Spec: Phase13_Final_Locked_Complete.zip                                     ║
╚══════════════════════════════════════════════════════════════════════════════╝

Provides plate loading, validation, and stack resolution for Spore Engine v12.

Core Classes:
- PlateLoader: JSON schema validation and engine_compat checking
- PlateResolver: Deterministic stack resolution
- Plate: Immutable plate representation
- ResolvedConfig: Immutable resolution result

Error Classes:
- SchemaError: JSON/schema validation failures
- SemanticError: Reference and logic failures
- CompatError: Engine compatibility failures
- IntegrityError: Checksum mismatches
- ConflictError: Stacking conflicts

Usage:
    from engine.plates import PlateLoader, PlateResolver
    
    loader = PlateLoader(engine_version="12.0.0")
    resolver = PlateResolver(rule_registry=set(RULE_REGISTRY.keys()))
    
    plates = loader.load_all(plate_paths)
    config = resolver.resolve(plates)
"""

from .plate_loader import PlateLoader, Plate
from .plate_resolver import (
    PlateResolver,
    ResolvedConfig,
    WorldConfig,
    RuleConfig,
    EntityTemplate,
    ScenarioConfig,
    Region,
    Connection,
    InitialEntity
)
from .errors import (
    PlateError,
    PlateValidationError,
    SchemaError,
    SemanticError,
    CompatError,
    IntegrityError,
    ConflictError,
    ERROR_CLASSES
)

__all__ = [
    # Loader
    'PlateLoader',
    'Plate',
    
    # Resolver
    'PlateResolver',
    'ResolvedConfig',
    'WorldConfig',
    'RuleConfig',
    'EntityTemplate',
    'ScenarioConfig',
    'Region',
    'Connection',
    'InitialEntity',
    
    # Errors
    'PlateError',
    'PlateValidationError',
    'SchemaError',
    'SemanticError',
    'CompatError',
    'IntegrityError',
    'ConflictError',
    'ERROR_CLASSES'
]

__version__ = "13.1.0"

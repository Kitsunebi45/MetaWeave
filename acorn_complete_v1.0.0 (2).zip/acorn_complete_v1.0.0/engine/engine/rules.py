"""engine.rules

Phase 7: Declarative rule system.
Phase 7.1: Edge-triggered rules (false→true detection).

This module defines:
- RuleTriggerType: LEVEL vs EDGE triggering
- EventSpec: Declarative event definitions
- Rule: Declarative rule structure (conditions → events)
- RULE_REGISTRY: Static registry of all available rules
- WORLD_DEFAULT_RULE_IDS: Rules enabled by default (sandbox mode)

Conservative constraints:
- No user-loaded rules (hardcoded registry only)
- No code evaluation (declarative only)
- No mutations (events only)
- No cascading (single-pass evaluation)
- No randomness or time dependencies
- No persistent rule memory (snapshots are ephemeral)
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List

from .scenario import Condition


class RuleTriggerType(Enum):
    """Rule trigger type.
    
    LEVEL: Rule fires whenever conditions are true (Phase 7 behavior).
    EDGE: Rule fires only on false→true transition (Phase 7.1).
    """
    LEVEL = "level"
    EDGE = "edge"


@dataclass(frozen=True)
class EventSpec:
    """Declarative event specification.
    
    Events emitted by rules must be deterministic and JSON-serializable.
    """
    
    type: str
    payload: Dict[str, Any]
    
    def to_event(self) -> Dict[str, Any]:
        """Convert EventSpec to event dictionary.
        
        Returns:
            Dictionary with type and all payload fields merged
        """
        event = {"type": self.type}
        event.update(self.payload)
        return event


@dataclass(frozen=True)
class Rule:
    """Declarative rule definition.
    
    A rule evaluates conditions and emits events when ALL conditions match.
    Rules never mutate entities - they only observe state and emit events.
    
    Phase 7.1 adds trigger types:
    - LEVEL: Fires whenever conditions are true (original behavior)
    - EDGE: Fires only on false→true transition
    
    Attributes:
        rule_id: Unique identifier for this rule
        description: Human-readable description
        when_all: List of conditions (AND semantics - all must be true)
        emit: List of events to emit when conditions match
        trigger: Trigger type (LEVEL or EDGE), defaults to LEVEL
    """
    
    rule_id: str
    description: str
    when_all: List[Condition]
    emit: List[EventSpec]
    trigger: RuleTriggerType = RuleTriggerType.LEVEL
    
    def __post_init__(self):
        """Validate rule definition at construction."""
        if not self.rule_id:
            raise ValueError("rule_id cannot be empty")
        
        if not self.when_all:
            raise ValueError(f"Rule '{self.rule_id}' must have at least one condition")
        
        if not self.emit:
            raise ValueError(f"Rule '{self.rule_id}' must emit at least one event")


# ============================================================================
# RULE REGISTRY
# ============================================================================

# Static registry of all available rules (hardcoded, not loaded from files)
RULE_REGISTRY: Dict[str, Rule] = {
    "counter_threshold": Rule(
        rule_id="counter_threshold",
        description="Emit event when counter value exceeds 3",
        when_all=[
            Condition(
                entity_id="counter_1",
                field="value",
                operator=">",
                value=3
            )
        ],
        emit=[
            EventSpec(
                type="COUNTER_THRESHOLD_EXCEEDED",
                payload={
                    "entity": "counter_1",
                }
            )
        ],
        trigger=RuleTriggerType.LEVEL  # Explicit for clarity
    ),
    "counter_threshold_edge": Rule(
        rule_id="counter_threshold_edge",
        description="Emit event once when counter crosses above 3 (edge-triggered)",
        when_all=[
            Condition(
                entity_id="counter_1",
                field="value",
                operator=">",
                value=3
            )
        ],
        emit=[
            EventSpec(
                type="COUNTER_THRESHOLD_CROSSED",
                payload={
                    "entity": "counter_1",
                }
            )
        ],
        trigger=RuleTriggerType.EDGE  # Phase 7.1: Edge detection
    )
}


# Rules that are enabled by default in sandbox mode (no active scenario)
# This preserves Phase 5 behavior where counter_threshold was always active
WORLD_DEFAULT_RULE_IDS: List[str] = [
    "counter_threshold"
]


# ============================================================================
# VALIDATION
# ============================================================================

def validate_rule_registry() -> None:
    """Validate the rule registry at boot time.
    
    Checks:
    - All rules have valid structure
    - No duplicate rule IDs
    - All conditions are well-formed
    - All event specs are valid
    
    Raises:
        ValueError: If validation fails
    """
    if not RULE_REGISTRY:
        raise ValueError("RULE_REGISTRY cannot be empty")
    
    # Check for duplicate IDs (dict construction already prevents this, but explicit)
    rule_ids = list(RULE_REGISTRY.keys())
    if len(rule_ids) != len(set(rule_ids)):
        raise ValueError("Duplicate rule IDs in registry")
    
    # Validate each rule
    for rule_id, rule in RULE_REGISTRY.items():
        # Check ID matches key
        if rule.rule_id != rule_id:
            raise ValueError(
                f"Rule ID mismatch: key='{rule_id}', rule.rule_id='{rule.rule_id}'"
            )
        
        # Rule validation happens in Rule.__post_init__
        # Additional validation can be added here if needed
        
        # Validate conditions have required fields
        for condition in rule.when_all:
            if not condition.entity_id:
                raise ValueError(f"Rule '{rule_id}': condition missing entity_id")
            if not condition.field:
                raise ValueError(f"Rule '{rule_id}': condition missing field")
        
        # Validate events have required fields
        for event_spec in rule.emit:
            if not event_spec.type:
                raise ValueError(f"Rule '{rule_id}': event missing type")
            if not isinstance(event_spec.payload, dict):
                raise ValueError(f"Rule '{rule_id}': event payload must be dict")
    
    # Validate default rule IDs reference existing rules
    for rule_id in WORLD_DEFAULT_RULE_IDS:
        if rule_id not in RULE_REGISTRY:
            raise ValueError(
                f"WORLD_DEFAULT_RULE_IDS references unknown rule '{rule_id}'"
            )

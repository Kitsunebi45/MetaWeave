"""Phase 16 Interface Module — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module provides the text-based interface layer for Spore Engine.       ║
║  It allows humans to observe state, teach entities, and save/load.           ║
║                                                                              ║
║  Key constraints:                                                            ║
║  - Interface may request actions                                             ║
║  - Engine enforces all validation                                            ║
║  - No plate mutation                                                         ║
║  - No rule mutation                                                          ║
║  - Deterministic command execution                                           ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝

Usage:
    from engine.interface import REPL, create_repl
    from engine.learning import LearningManager
    from engine.save import SaveManager
    from engine.phase13_boot import validate_plate_stack
    
    # Load plates
    config = validate_plate_stack([...])
    
    # Create managers
    learning_mgr = LearningManager()
    save_mgr = SaveManager.from_resolved_config(config)
    
    # Create and run REPL
    repl = create_repl(
        learning_manager=learning_mgr,
        save_manager=save_mgr,
        resolved_config=config
    )
    repl.run()
"""

from .errors import (
    InterfaceError,
    InterfaceException,
    CommandParseError,
    CommandSchemaError,
    CommandNotFoundError
)

from .command_schemas import (
    CommandType,
    CommandArg,
    CommandSchema,
    COMMAND_REGISTRY,
    get_all_commands,
    get_read_commands,
    get_write_commands
)

from .command_router import (
    ParsedCommand,
    CommandRouter
)

from .interface_api import (
    InterfaceResponse,
    InterfaceAPI
)

from .repl import (
    REPL,
    create_repl
)

__all__ = [
    # Errors
    'InterfaceError',
    'InterfaceException',
    'CommandParseError',
    'CommandSchemaError',
    'CommandNotFoundError',
    
    # Schemas
    'CommandType',
    'CommandArg',
    'CommandSchema',
    'COMMAND_REGISTRY',
    'get_all_commands',
    'get_read_commands',
    'get_write_commands',
    
    # Router
    'ParsedCommand',
    'CommandRouter',
    
    # API
    'InterfaceResponse',
    'InterfaceAPI',
    
    # REPL
    'REPL',
    'create_repl'
]

__version__ = "16.0.0"

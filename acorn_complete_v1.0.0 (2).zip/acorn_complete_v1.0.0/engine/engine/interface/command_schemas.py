"""Phase 16 Command Schemas — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module defines explicit schemas for all interface commands.            ║
║  Every command maps to exactly one engine API call.                          ║
║  No implicit defaults — missing fields = schema error.                       ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
from enum import Enum


class CommandType(Enum):
    """Command type classification."""
    READ = "read"       # Does not mutate state
    WRITE = "write"     # May mutate runtime state (not plates)


@dataclass(frozen=True)
class CommandArg:
    """Command argument definition."""
    name: str
    arg_type: str  # "string", "float", "int", "quoted_string"
    required: bool = True
    description: str = ""


@dataclass(frozen=True)
class CommandSchema:
    """Schema for a single command."""
    name: str
    pattern: str  # Human-readable pattern
    command_type: CommandType
    args: tuple  # Tuple of CommandArg
    description: str
    engine_api: str  # Target engine API method
    
    def get_required_args(self) -> List[CommandArg]:
        """Get required arguments."""
        return [a for a in self.args if a.required]


# =============================================================================
# READ-ONLY COMMANDS
# =============================================================================

SHOW_WORLD = CommandSchema(
    name="show_world",
    pattern="show world",
    command_type=CommandType.READ,
    args=(),
    description="Display current world state",
    engine_api="get_world_state"
)

SHOW_ENTITIES = CommandSchema(
    name="show_entities",
    pattern="show entities",
    command_type=CommandType.READ,
    args=(),
    description="List all entities",
    engine_api="get_entities"
)

SHOW_ENTITY = CommandSchema(
    name="show_entity",
    pattern="show entity <entity_id>",
    command_type=CommandType.READ,
    args=(
        CommandArg("entity_id", "string", True, "Entity ID to inspect"),
    ),
    description="Display entity details",
    engine_api="get_entity"
)

SHOW_LEARNING = CommandSchema(
    name="show_learning",
    pattern="show learning <entity_id>",
    command_type=CommandType.READ,
    args=(
        CommandArg("entity_id", "string", True, "Entity ID to inspect learning for"),
    ),
    description="Display entity learning state",
    engine_api="get_learning_state"
)

SHOW_RULES = CommandSchema(
    name="show_rules",
    pattern="show rules",
    command_type=CommandType.READ,
    args=(),
    description="List enabled rules",
    engine_api="get_rules"
)

SHOW_SCENARIO = CommandSchema(
    name="show_scenario",
    pattern="show scenario",
    command_type=CommandType.READ,
    args=(),
    description="Display current scenario state",
    engine_api="get_scenario"
)

SHOW_STATUS = CommandSchema(
    name="show_status",
    pattern="show status",
    command_type=CommandType.READ,
    args=(),
    description="Display engine status (tick, running, etc.)",
    engine_api="get_status"
)

# =============================================================================
# WRITE COMMANDS (Bounded)
# =============================================================================

START_SCENARIO = CommandSchema(
    name="start_scenario",
    pattern="start scenario <scenario_id>",
    command_type=CommandType.WRITE,
    args=(
        CommandArg("scenario_id", "string", True, "Scenario ID to start"),
    ),
    description="Start a scenario",
    engine_api="start_scenario"
)

STOP_SCENARIO = CommandSchema(
    name="stop_scenario",
    pattern="stop scenario",
    command_type=CommandType.WRITE,
    args=(),
    description="Stop current scenario",
    engine_api="stop_scenario"
)

TEACH_ENTITY = CommandSchema(
    name="teach_entity",
    pattern='teach entity <entity_id> <skill> <delta> reason "<reason>"',
    command_type=CommandType.WRITE,
    args=(
        CommandArg("entity_id", "string", True, "Target entity ID"),
        CommandArg("skill", "string", True, "Skill name"),
        CommandArg("delta", "float", True, "Skill change value"),
        CommandArg("reason", "quoted_string", True, "Reason for teaching"),
    ),
    description="Apply teaching event to entity",
    engine_api="apply_teaching"
)

RESET_LEARNING = CommandSchema(
    name="reset_learning",
    pattern="reset learning <entity_id>",
    command_type=CommandType.WRITE,
    args=(
        CommandArg("entity_id", "string", True, "Entity ID to reset learning for"),
    ),
    description="Reset learning state for entity",
    engine_api="reset_learning"
)

SAVE = CommandSchema(
    name="save",
    pattern="save",
    command_type=CommandType.WRITE,
    args=(),
    description="Save current state",
    engine_api="save_state"
)

SAVE_AS = CommandSchema(
    name="save_as",
    pattern="save as <filename>",
    command_type=CommandType.WRITE,
    args=(
        CommandArg("filename", "string", True, "Save file name"),
    ),
    description="Save current state to specific file",
    engine_api="save_state_as"
)

LOAD = CommandSchema(
    name="load",
    pattern="load",
    command_type=CommandType.WRITE,
    args=(),
    description="Load most recent save",
    engine_api="load_state"
)

LOAD_FROM = CommandSchema(
    name="load_from",
    pattern="load from <filename>",
    command_type=CommandType.WRITE,
    args=(
        CommandArg("filename", "string", True, "Save file to load"),
    ),
    description="Load state from specific file",
    engine_api="load_state_from"
)

TICK = CommandSchema(
    name="tick",
    pattern="tick",
    command_type=CommandType.WRITE,
    args=(),
    description="Advance engine by one tick",
    engine_api="tick"
)

TICK_N = CommandSchema(
    name="tick_n",
    pattern="tick <count>",
    command_type=CommandType.WRITE,
    args=(
        CommandArg("count", "int", True, "Number of ticks to advance"),
    ),
    description="Advance engine by N ticks",
    engine_api="tick_n"
)

HELP = CommandSchema(
    name="help",
    pattern="help",
    command_type=CommandType.READ,
    args=(),
    description="Show available commands",
    engine_api="help"
)

QUIT = CommandSchema(
    name="quit",
    pattern="quit",
    command_type=CommandType.READ,
    args=(),
    description="Exit the interface",
    engine_api="quit"
)


# =============================================================================
# CURRICULUM COMMANDS (Phase 19)
# =============================================================================

LOAD_CURRICULUM = CommandSchema(
    name="load_curriculum",
    pattern="load curriculum <path>",
    command_type=CommandType.WRITE,
    args=(
        CommandArg("path", "string", True, "Path to curriculum directory or file"),
    ),
    description="Load curriculum and lessons from path",
    engine_api="load_curriculum"
)

SHOW_CURRICULUM = CommandSchema(
    name="show_curriculum",
    pattern="show curriculum <curriculum_id>",
    command_type=CommandType.READ,
    args=(
        CommandArg("curriculum_id", "string", True, "Curriculum ID to display"),
    ),
    description="Display curriculum details",
    engine_api="get_curriculum"
)

SHOW_LESSON = CommandSchema(
    name="show_lesson",
    pattern="show lesson <lesson_id>",
    command_type=CommandType.READ,
    args=(
        CommandArg("lesson_id", "string", True, "Lesson ID to display"),
    ),
    description="Display lesson details",
    engine_api="get_lesson"
)

RUN_CURRICULUM = CommandSchema(
    name="run_curriculum",
    pattern="run curriculum <curriculum_id>",
    command_type=CommandType.WRITE,
    args=(
        CommandArg("curriculum_id", "string", True, "Curriculum ID to run"),
    ),
    description="Run curriculum (live mode)",
    engine_api="run_curriculum"
)

RUN_CURRICULUM_DRY = CommandSchema(
    name="run_curriculum_dry",
    pattern="run curriculum <curriculum_id> dry",
    command_type=CommandType.READ,
    args=(
        CommandArg("curriculum_id", "string", True, "Curriculum ID to dry-run"),
    ),
    description="Run curriculum in dry-run mode (no mutation)",
    engine_api="run_curriculum_dry"
)


# =============================================================================
# COMMAND REGISTRY
# =============================================================================

# All commands in order of pattern matching priority
COMMAND_REGISTRY: Dict[str, CommandSchema] = {
    # Read commands
    "show_world": SHOW_WORLD,
    "show_entities": SHOW_ENTITIES,
    "show_entity": SHOW_ENTITY,
    "show_learning": SHOW_LEARNING,
    "show_rules": SHOW_RULES,
    "show_scenario": SHOW_SCENARIO,
    "show_status": SHOW_STATUS,
    "show_curriculum": SHOW_CURRICULUM,
    "show_lesson": SHOW_LESSON,
    
    # Write commands
    "start_scenario": START_SCENARIO,
    "stop_scenario": STOP_SCENARIO,
    "teach_entity": TEACH_ENTITY,
    "reset_learning": RESET_LEARNING,
    "save": SAVE,
    "save_as": SAVE_AS,
    "load": LOAD,
    "load_from": LOAD_FROM,
    "load_curriculum": LOAD_CURRICULUM,
    "run_curriculum": RUN_CURRICULUM,
    "run_curriculum_dry": RUN_CURRICULUM_DRY,
    "tick": TICK,
    "tick_n": TICK_N,
    
    # Meta commands
    "help": HELP,
    "quit": QUIT,
}


def get_all_commands() -> List[CommandSchema]:
    """Get all registered commands."""
    return list(COMMAND_REGISTRY.values())


def get_read_commands() -> List[CommandSchema]:
    """Get read-only commands."""
    return [c for c in COMMAND_REGISTRY.values() if c.command_type == CommandType.READ]


def get_write_commands() -> List[CommandSchema]:
    """Get write commands."""
    return [c for c in COMMAND_REGISTRY.values() if c.command_type == CommandType.WRITE]

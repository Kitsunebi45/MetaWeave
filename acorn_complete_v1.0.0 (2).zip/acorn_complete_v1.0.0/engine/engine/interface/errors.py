"""Phase 16 Interface Errors — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module defines error classes for the interface layer.                  ║
║  Engine errors pass through unchanged — interface MUST NOT reinterpret.      ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from dataclasses import dataclass, asdict
from typing import Optional
import json


@dataclass(frozen=True)
class InterfaceError:
    """Structured interface error."""
    error_class: str
    field_path: Optional[str]
    message: str
    
    def to_json(self) -> str:
        """Serialize to one-line JSON."""
        return json.dumps(asdict(self), separators=(',', ':'))
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return asdict(self)


class InterfaceException(Exception):
    """Base exception for interface errors."""
    
    def __init__(self, error: InterfaceError):
        self.error = error
        super().__init__(error.message)
    
    def to_json(self) -> str:
        return self.error.to_json()
    
    def to_dict(self) -> dict:
        return self.error.to_dict()


class CommandParseError(InterfaceException):
    """Command parsing failure."""
    pass


class CommandSchemaError(InterfaceException):
    """Command schema validation failure."""
    pass


class CommandNotFoundError(InterfaceException):
    """Unknown command."""
    pass


# Error factories
def create_parse_error(field_path: Optional[str], message: str) -> CommandParseError:
    """Create a parse error."""
    return CommandParseError(InterfaceError(
        error_class="PARSE_ERROR",
        field_path=field_path,
        message=message
    ))


def create_schema_error(field_path: Optional[str], message: str) -> CommandSchemaError:
    """Create a schema error."""
    return CommandSchemaError(InterfaceError(
        error_class="SCHEMA_ERROR",
        field_path=field_path,
        message=message
    ))


def create_not_found_error(command: str) -> CommandNotFoundError:
    """Create a command not found error."""
    return CommandNotFoundError(InterfaceError(
        error_class="NOT_FOUND_ERROR",
        field_path="command",
        message=f"Unknown command: {command}"
    ))

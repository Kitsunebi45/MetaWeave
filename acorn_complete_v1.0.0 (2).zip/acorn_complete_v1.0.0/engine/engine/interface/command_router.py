"""Phase 16 Command Router — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module parses and validates user commands.                             ║
║  It MUST NOT mutate engine state or execute logic.                           ║
║  It only tokenizes, matches schemas, and rejects invalid commands.           ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import re
import shlex

from .errors import (
    create_parse_error,
    create_schema_error,
    create_not_found_error
)
from .command_schemas import (
    CommandSchema,
    CommandArg,
    COMMAND_REGISTRY,
    get_all_commands
)


@dataclass(frozen=True)
class ParsedCommand:
    """Result of parsing a command."""
    schema: CommandSchema
    args: Dict[str, Any]
    raw_input: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "command": self.schema.name,
            "args": dict(self.args),
            "raw_input": self.raw_input
        }


class CommandRouter:
    """Parses and validates user commands.
    
    Responsibilities:
    - Tokenize input
    - Match against command schemas
    - Reject invalid commands before engine call
    
    Prohibitions:
    - MUST NOT mutate engine state
    - MUST NOT execute logic
    """
    
    def __init__(self):
        """Initialize router with command registry."""
        self._commands = COMMAND_REGISTRY
        self._patterns = self._build_patterns()
    
    def _build_patterns(self) -> List[Tuple[re.Pattern, CommandSchema]]:
        """Build regex patterns for command matching."""
        patterns = []
        
        # Order matters - more specific patterns first
        ordered_schemas = [
            # Multi-word prefixes first
            self._commands.get("show_world"),
            self._commands.get("show_entities"),
            self._commands.get("show_entity"),
            self._commands.get("show_learning"),
            self._commands.get("show_rules"),
            self._commands.get("show_scenario"),
            self._commands.get("show_status"),
            self._commands.get("start_scenario"),
            self._commands.get("stop_scenario"),
            self._commands.get("teach_entity"),
            self._commands.get("reset_learning"),
            self._commands.get("save_as"),
            self._commands.get("save"),
            self._commands.get("load_from"),
            self._commands.get("load"),
            self._commands.get("tick_n"),
            self._commands.get("tick"),
            self._commands.get("help"),
            self._commands.get("quit"),
        ]
        
        for schema in ordered_schemas:
            if schema is None:
                continue
            pattern = self._schema_to_pattern(schema)
            patterns.append((pattern, schema))
        
        return patterns
    
    def _schema_to_pattern(self, schema: CommandSchema) -> re.Pattern:
        """Convert command schema to regex pattern."""
        pattern_str = schema.pattern
        
        # Replace argument placeholders with capture groups
        # <entity_id> -> (?P<entity_id>\S+)
        # <delta> -> (?P<delta>-?\d+\.?\d*)
        # "<text>" -> "(?P<text>[^"]*)"
        
        for arg in schema.args:
            placeholder = f"<{arg.name}>"
            if arg.arg_type == "float":
                pattern_str = pattern_str.replace(placeholder, f"(?P<{arg.name}>-?\\d+\\.?\\d*)")
            elif arg.arg_type == "int":
                pattern_str = pattern_str.replace(placeholder, f"(?P<{arg.name}>-?\\d+)")
            elif arg.arg_type == "quoted_string":
                # Handle quoted string - the placeholder is inside quotes in the pattern
                # Pattern: reason "<text>" -> reason "(?P<text>[^"]*)"
                pattern_str = pattern_str.replace(f'"{placeholder}"', f'"(?P<{arg.name}>[^"]*)"')
            else:  # string
                pattern_str = pattern_str.replace(placeholder, f"(?P<{arg.name}>\\S+)")
        
        # Escape any remaining special characters
        # pattern_str = re.escape(pattern_str)  # Don't escape - we built it
        
        return re.compile(f"^{pattern_str}$", re.IGNORECASE)
    
    def parse(self, input_str: str) -> ParsedCommand:
        """Parse user input into a command.
        
        Args:
            input_str: Raw user input
            
        Returns:
            ParsedCommand with schema and validated args
            
        Raises:
            CommandParseError: If input cannot be parsed
            CommandSchemaError: If args don't match schema
            CommandNotFoundError: If command not found
        """
        # Normalize input
        input_str = input_str.strip()
        
        if not input_str:
            raise create_parse_error(None, "Empty command")
        
        # Try each pattern
        for pattern, schema in self._patterns:
            match = pattern.match(input_str)
            if match:
                # Extract and validate args
                args = self._extract_args(match, schema)
                return ParsedCommand(
                    schema=schema,
                    args=args,
                    raw_input=input_str
                )
        
        # No match found
        # Try to identify the command prefix for better error
        first_words = input_str.split()[:2]
        raise create_not_found_error(" ".join(first_words))
    
    def _extract_args(self, match: re.Match, schema: CommandSchema) -> Dict[str, Any]:
        """Extract and validate arguments from match."""
        args = {}
        
        for arg in schema.args:
            raw_value = match.group(arg.name) if arg.name in match.groupdict() else None
            
            if raw_value is None:
                if arg.required:
                    raise create_schema_error(
                        arg.name,
                        f"Missing required argument: {arg.name}"
                    )
                continue
            
            # Type conversion
            try:
                if arg.arg_type == "float":
                    args[arg.name] = float(raw_value)
                elif arg.arg_type == "int":
                    args[arg.name] = int(raw_value)
                else:  # string or quoted_string
                    args[arg.name] = raw_value
            except ValueError:
                raise create_schema_error(
                    arg.name,
                    f"Invalid {arg.arg_type} value for {arg.name}: {raw_value}"
                )
        
        return args
    
    def get_help(self) -> str:
        """Generate help text for all commands."""
        lines = ["Available commands:", ""]
        
        # Read commands
        lines.append("Read commands (do not modify state):")
        for name, schema in self._commands.items():
            if schema.command_type.value == "read":
                lines.append(f"  {schema.pattern}")
                lines.append(f"    {schema.description}")
        
        lines.append("")
        
        # Write commands
        lines.append("Write commands (may modify runtime state):")
        for name, schema in self._commands.items():
            if schema.command_type.value == "write":
                lines.append(f"  {schema.pattern}")
                lines.append(f"    {schema.description}")
        
        return "\n".join(lines)
    
    def validate_command(self, input_str: str) -> bool:
        """Check if input is a valid command (without executing).
        
        Returns:
            True if valid, False otherwise
        """
        try:
            self.parse(input_str)
            return True
        except Exception:
            return False

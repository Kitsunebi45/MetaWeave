"""Phase 16 Interface API — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module provides the translation layer between interface commands       ║
║  and engine APIs. It uses existing Phase 13-15 entry points.                 ║
║                                                                              ║
║  DO NOT invent new engine APIs. Use existing entry points.                   ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
import json

from .command_router import ParsedCommand, CommandRouter
from .errors import InterfaceError, InterfaceException


@dataclass
class InterfaceResponse:
    """Structured response from interface."""
    success: bool
    command: str
    data: Optional[Dict[str, Any]] = None
    error: Optional[Dict[str, Any]] = None
    
    def to_json(self) -> str:
        result = {"success": self.success, "command": self.command}
        if self.data is not None:
            result["data"] = self.data
        if self.error is not None:
            result["error"] = self.error
        return json.dumps(result, indent=2, default=str)
    
    def to_dict(self) -> Dict[str, Any]:
        result = {"success": self.success, "command": self.command}
        if self.data is not None:
            result["data"] = self.data
        if self.error is not None:
            result["error"] = self.error
        return result


class InterfaceAPI:
    """Translation layer between interface commands and engine APIs.
    
    Uses existing Phase 13-15 entry points:
    - Phase 13: Plate stack (read-only)
    - Phase 14: Save/load
    - Phase 15: Learning manager
    
    Authority preservation:
    - Interface may request actions
    - Engine enforces all validation and execution
    """
    
    def __init__(
        self,
        learning_manager=None,
        save_manager=None,
        resolved_config=None,
        save_dir: Optional[Path] = None,
        lesson_store=None,
        curriculum_store=None
    ):
        """Initialize interface API.
        
        Args:
            learning_manager: Phase 15 LearningManager instance
            save_manager: Phase 14 SaveManager instance
            resolved_config: Phase 13 ResolvedConfig
            save_dir: Directory for save files
            lesson_store: Phase 19 LessonStore instance
            curriculum_store: Phase 19 CurriculumStore instance
        """
        self._learning_manager = learning_manager
        self._save_manager = save_manager
        self._resolved_config = resolved_config
        self._save_dir = save_dir or Path("./saves")
        
        # Phase 19 curriculum stores
        self._lesson_store = lesson_store
        self._curriculum_store = curriculum_store
        self._curriculum_runner = None
        
        # Runtime state
        self._tick = 0
        self._running = False
        self._scenario_id: Optional[str] = None
        self._entities: Dict[str, Dict[str, Any]] = {}
        
        # Router for help
        self._router = CommandRouter()
    
    def execute(self, parsed: ParsedCommand) -> InterfaceResponse:
        """Execute a parsed command.
        
        Args:
            parsed: ParsedCommand from router
            
        Returns:
            InterfaceResponse with result or error
        """
        try:
            # Dispatch to handler
            handler_name = f"_handle_{parsed.schema.name}"
            handler = getattr(self, handler_name, None)
            
            if handler is None:
                return InterfaceResponse(
                    success=False,
                    command=parsed.schema.name,
                    error={"message": f"No handler for command: {parsed.schema.name}"}
                )
            
            result = handler(parsed.args)
            return InterfaceResponse(
                success=True,
                command=parsed.schema.name,
                data=result
            )
            
        except InterfaceException as e:
            return InterfaceResponse(
                success=False,
                command=parsed.schema.name,
                error=e.to_dict()
            )
        except Exception as e:
            # Engine errors pass through unchanged
            return InterfaceResponse(
                success=False,
                command=parsed.schema.name,
                error={
                    "error_class": type(e).__name__,
                    "message": str(e)
                }
            )
    
    # =========================================================================
    # READ HANDLERS
    # =========================================================================
    
    def _handle_show_world(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: show world"""
        if self._resolved_config is None:
            return {"world": None, "message": "No plate stack loaded"}
        
        wc = self._resolved_config.world_config
        if wc is None:
            return {"world": None, "message": "No world in plate stack"}
        
        return {
            "world_id": wc.world_id,
            "topology_mode": wc.topology_mode,
            "regions": [
                {"region_id": r.region_id, "name": r.name}
                for r in wc.regions
            ],
            "connections": [
                {"from": c.from_region, "to": c.to_region}
                for c in wc.connections
            ]
        }
    
    def _handle_show_entities(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: show entities"""
        return {
            "count": len(self._entities),
            "entities": list(self._entities.keys())
        }
    
    def _handle_show_entity(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: show entity <entity_id>"""
        entity_id = args["entity_id"]
        
        if entity_id not in self._entities:
            return {"entity_id": entity_id, "found": False}
        
        return {
            "entity_id": entity_id,
            "found": True,
            "state": self._entities[entity_id]
        }
    
    def _handle_show_learning(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: show learning <entity_id>"""
        entity_id = args["entity_id"]
        
        if self._learning_manager is None:
            return {"error": "Learning manager not initialized"}
        
        learning = self._learning_manager.get_entity_learning(entity_id)
        return {
            "entity_id": entity_id,
            "skills": dict(learning.skills),
            "metrics": dict(learning.metrics),
            "history_count": len(learning.history),
            "history": [h.to_dict() for h in learning.history[-10:]]  # Last 10
        }
    
    def _handle_show_rules(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: show rules"""
        if self._resolved_config is None:
            return {"rules": None, "message": "No plate stack loaded"}
        
        rc = self._resolved_config.rule_config
        if rc is None:
            return {"rules": None, "message": "No rules in plate stack"}
        
        return {
            "rule_set_id": rc.rule_set_id,
            "mode": rc.mode,
            "enabled_rule_ids": sorted(rc.enabled_rule_ids)
        }
    
    def _handle_show_scenario(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: show scenario"""
        if self._resolved_config is None:
            return {"scenario": None, "message": "No plate stack loaded"}
        
        sc = self._resolved_config.scenario_config
        if sc is None:
            return {"scenario": None, "message": "No scenario in plate stack"}
        
        return {
            "scenario_id": sc.scenario_id,
            "world_ref": sc.world_ref,
            "initial_entities": [
                {
                    "entity_id": e.entity_id,
                    "template_id": e.template_id,
                    "region_id": e.region_id
                }
                for e in sc.initial_entities
            ],
            "parameters": dict(sc.parameters)
        }
    
    def _handle_show_status(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: show status"""
        return {
            "tick": self._tick,
            "running": self._running,
            "scenario_id": self._scenario_id,
            "entity_count": len(self._entities),
            "config_loaded": self._resolved_config is not None,
            "learning_enabled": self._learning_manager is not None,
            "save_enabled": self._save_manager is not None
        }
    
    def _handle_help(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: help"""
        return {"help": self._router.get_help()}
    
    def _handle_quit(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: quit"""
        return {"action": "quit"}
    
    # =========================================================================
    # WRITE HANDLERS
    # =========================================================================
    
    def _handle_start_scenario(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: start scenario <scenario_id>"""
        scenario_id = args["scenario_id"]
        
        if self._resolved_config is None:
            raise InterfaceException(InterfaceError(
                error_class="CONFIG_ERROR",
                field_path=None,
                message="No plate stack loaded"
            ))
        
        sc = self._resolved_config.scenario_config
        if sc is None or sc.scenario_id != scenario_id:
            raise InterfaceException(InterfaceError(
                error_class="SCENARIO_ERROR",
                field_path="scenario_id",
                message=f"Scenario not found: {scenario_id}"
            ))
        
        # Initialize entities from scenario
        self._entities = {}
        for e in sc.initial_entities:
            self._entities[e.entity_id] = {
                "template_id": e.template_id,
                "region_id": e.region_id,
                "state": dict(e.state)
            }
        
        self._running = True
        self._scenario_id = scenario_id
        self._tick = 0
        
        return {
            "started": True,
            "scenario_id": scenario_id,
            "entity_count": len(self._entities)
        }
    
    def _handle_stop_scenario(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: stop scenario"""
        was_running = self._running
        self._running = False
        
        return {
            "stopped": True,
            "was_running": was_running,
            "final_tick": self._tick
        }
    
    def _handle_teach_entity(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: teach entity <entity_id> <skill> <delta> reason "<text>" """
        if self._learning_manager is None:
            raise InterfaceException(InterfaceError(
                error_class="LEARNING_ERROR",
                field_path=None,
                message="Learning manager not initialized"
            ))
        
        entity_id = args["entity_id"]
        skill = args["skill"]
        delta = args["delta"]
        reason = args["reason"]
        
        # Import teaching event from Phase 15
        from ..learning import SkillUpdateEvent, HistoryAppendEvent
        
        # Apply skill update
        self._learning_manager.apply_teaching_event(SkillUpdateEvent(
            entity_id=entity_id,
            tick=self._tick,
            skill=skill,
            delta=delta
        ))
        
        # Record in history
        self._learning_manager.apply_teaching_event(HistoryAppendEvent(
            entity_id=entity_id,
            tick=self._tick,
            event_name=f"taught_{skill}",
            data={"delta": delta, "reason": reason}
        ))
        
        # Get updated value
        new_value = self._learning_manager.get_skill(entity_id, skill)
        
        return {
            "entity_id": entity_id,
            "skill": skill,
            "delta": delta,
            "new_value": new_value,
            "reason": reason
        }
    
    def _handle_reset_learning(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: reset learning <entity_id>"""
        if self._learning_manager is None:
            raise InterfaceException(InterfaceError(
                error_class="LEARNING_ERROR",
                field_path=None,
                message="Learning manager not initialized"
            ))
        
        entity_id = args["entity_id"]
        self._learning_manager.reset_entity(entity_id)
        
        return {
            "entity_id": entity_id,
            "reset": True
        }
    
    def _handle_save(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: save"""
        return self._do_save(None)
    
    def _handle_save_as(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: save as <filename>"""
        return self._do_save(args["filename"])
    
    def _do_save(self, filename: Optional[str]) -> Dict[str, Any]:
        """Perform save operation."""
        if self._save_manager is None:
            raise InterfaceException(InterfaceError(
                error_class="SAVE_ERROR",
                field_path=None,
                message="Save manager not initialized"
            ))
        
        # Determine save path
        self._save_dir.mkdir(parents=True, exist_ok=True)
        if filename:
            save_path = self._save_dir / filename
        else:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = self._save_dir / f"save_{timestamp}.json"
        
        # Build runtime state
        from ..save import create_runtime_state
        
        learning_state = {}
        if self._learning_manager:
            learning_state = self._learning_manager.get_state_dict()
        
        runtime_state = create_runtime_state(
            world_state={"tick": self._tick, "running": self._running},
            entities=self._entities,
            systems={"learning": learning_state}
        )
        
        # Save
        envelope = self._save_manager.save_state(
            path=save_path,
            tick=self._tick,
            state=runtime_state,
            metadata={"scenario_id": self._scenario_id}
        )
        
        return {
            "saved": True,
            "path": str(save_path),
            "save_id": envelope.save_id,
            "tick": envelope.tick
        }
    
    def _handle_load(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: load"""
        # Find most recent save
        if not self._save_dir.exists():
            raise InterfaceException(InterfaceError(
                error_class="LOAD_ERROR",
                field_path=None,
                message="No save directory found"
            ))
        
        saves = sorted(self._save_dir.glob("*.json"), reverse=True)
        if not saves:
            raise InterfaceException(InterfaceError(
                error_class="LOAD_ERROR",
                field_path=None,
                message="No save files found"
            ))
        
        return self._do_load(saves[0])
    
    def _handle_load_from(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: load from <filename>"""
        save_path = self._save_dir / args["filename"]
        return self._do_load(save_path)
    
    def _do_load(self, save_path: Path) -> Dict[str, Any]:
        """Perform load operation."""
        if self._save_manager is None:
            raise InterfaceException(InterfaceError(
                error_class="LOAD_ERROR",
                field_path=None,
                message="Save manager not initialized"
            ))
        
        # Load envelope
        envelope = self._save_manager.load_state(save_path)
        
        # Restore state
        self._tick = envelope.tick
        self._entities = dict(envelope.state.entities)
        
        world_state = envelope.state.world_state
        self._running = world_state.get("running", False)
        
        # Restore learning state
        if self._learning_manager:
            learning_state = envelope.state.systems.get("learning", {})
            if learning_state:
                self._learning_manager.load_state_dict(learning_state)
        
        # Restore scenario ID from metadata
        self._scenario_id = envelope.metadata.get("scenario_id")
        
        return {
            "loaded": True,
            "path": str(save_path),
            "save_id": envelope.save_id,
            "tick": envelope.tick
        }
    
    def _handle_tick(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: tick"""
        return self._do_tick(1)
    
    def _handle_tick_n(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: tick <count>"""
        return self._do_tick(args["count"])
    
    def _do_tick(self, count: int) -> Dict[str, Any]:
        """Advance simulation by N ticks."""
        if count < 1:
            raise InterfaceException(InterfaceError(
                error_class="TICK_ERROR",
                field_path="count",
                message="Tick count must be positive"
            ))
        
        start_tick = self._tick
        self._tick += count
        
        return {
            "ticks_advanced": count,
            "start_tick": start_tick,
            "end_tick": self._tick
        }
    
    # =========================================================================
    # CURRICULUM HANDLERS (Phase 19)
    # =========================================================================
    
    def _get_curriculum_runner(self):
        """Get or create curriculum runner (lazy initialization)."""
        if self._curriculum_runner is None:
            if self._lesson_store is None or self._curriculum_store is None:
                return None
            
            from ..curriculum import create_runner
            self._curriculum_runner = create_runner(
                self,
                self._lesson_store,
                self._curriculum_store
            )
        return self._curriculum_runner
    
    def _handle_load_curriculum(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: load curriculum <path>"""
        path_str = args["path"]
        path = Path(path_str)
        
        if self._lesson_store is None or self._curriculum_store is None:
            raise InterfaceException(InterfaceError(
                error_class="CURRICULUM_ERROR",
                field_path=None,
                message="Curriculum system not initialized"
            ))
        
        from ..curriculum import (
            load_lesson_from_file, load_curriculum_from_file,
            SchemaError, SemanticError
        )
        
        lessons_loaded = 0
        curricula_loaded = 0
        
        try:
            if path.is_file():
                # Load single file
                if path.suffix == ".json":
                    with open(path, 'r') as f:
                        data = json.load(f)
                    
                    if "lesson_id" in data:
                        from ..curriculum import load_lesson
                        lesson = load_lesson(data)
                        self._lesson_store.add(lesson)
                        lessons_loaded = 1
                    elif "curriculum_id" in data:
                        from ..curriculum import load_curriculum
                        curriculum = load_curriculum(data)
                        self._curriculum_store.add(curriculum)
                        curricula_loaded = 1
                    else:
                        raise InterfaceException(InterfaceError(
                            error_class="CURRICULUM_ERROR",
                            field_path="path",
                            message="File is not a valid lesson or curriculum"
                        ))
            elif path.is_dir():
                # Load directory
                for json_file in path.glob("*.json"):
                    with open(json_file, 'r') as f:
                        data = json.load(f)
                    
                    if "lesson_id" in data:
                        from ..curriculum import load_lesson
                        lesson = load_lesson(data)
                        self._lesson_store.add(lesson)
                        lessons_loaded += 1
                    elif "curriculum_id" in data:
                        from ..curriculum import load_curriculum
                        curriculum = load_curriculum(data)
                        self._curriculum_store.add(curriculum)
                        curricula_loaded += 1
            else:
                raise InterfaceException(InterfaceError(
                    error_class="CURRICULUM_ERROR",
                    field_path="path",
                    message=f"Path not found: {path_str}"
                ))
            
            return {
                "loaded": True,
                "path": str(path),
                "lessons": lessons_loaded,
                "curricula": curricula_loaded
            }
            
        except (SchemaError, SemanticError) as e:
            raise InterfaceException(InterfaceError(
                error_class=e.error.error_class,
                field_path=e.error.field_path,
                message=e.error.message
            ))
    
    def _handle_show_curriculum(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: show curriculum <curriculum_id>"""
        curriculum_id = args["curriculum_id"]
        
        if self._curriculum_store is None:
            return {"curriculum": None, "message": "Curriculum system not initialized"}
        
        curriculum = self._curriculum_store.get(curriculum_id)
        if curriculum is None:
            return {"curriculum_id": curriculum_id, "found": False}
        
        return {
            "curriculum_id": curriculum.curriculum_id,
            "found": True,
            "name": curriculum.name,
            "description": curriculum.description,
            "lesson_count": len(curriculum.lessons),
            "lessons": list(curriculum.lessons)
        }
    
    def _handle_show_lesson(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: show lesson <lesson_id>"""
        lesson_id = args["lesson_id"]
        
        if self._lesson_store is None:
            return {"lesson": None, "message": "Curriculum system not initialized"}
        
        lesson = self._lesson_store.get(lesson_id)
        if lesson is None:
            return {"lesson_id": lesson_id, "found": False}
        
        result = {
            "lesson_id": lesson.lesson_id,
            "found": True,
            "target_entity": lesson.target_entity,
            "skill": lesson.skill,
            "delta": lesson.delta,
            "reason": lesson.reason
        }
        
        if lesson.preconditions:
            result["preconditions"] = {
                "min_value": lesson.preconditions.min_value,
                "max_value": lesson.preconditions.max_value
            }
        
        return result
    
    def _handle_run_curriculum(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: run curriculum <curriculum_id>"""
        curriculum_id = args["curriculum_id"]
        
        runner = self._get_curriculum_runner()
        if runner is None:
            raise InterfaceException(InterfaceError(
                error_class="CURRICULUM_ERROR",
                field_path=None,
                message="Curriculum system not initialized"
            ))
        
        report = runner.run(curriculum_id, dry=False)
        return report.to_dict()
    
    def _handle_run_curriculum_dry(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Handle: run curriculum <curriculum_id> dry"""
        curriculum_id = args["curriculum_id"]
        
        runner = self._get_curriculum_runner()
        if runner is None:
            raise InterfaceException(InterfaceError(
                error_class="CURRICULUM_ERROR",
                field_path=None,
                message="Curriculum system not initialized"
            ))
        
        report = runner.run(curriculum_id, dry=True)
        return report.to_dict()

"""Phase 16 REPL — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module implements the deterministic REPL loop.                         ║
║  One command processed at a time. No background tasks. No state caching.     ║
║                                                                              ║
║  Output format: Structured JSON only. No colors, emojis, or formatting.      ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from pathlib import Path
from typing import Optional
import sys

from .command_router import CommandRouter, ParsedCommand
from .interface_api import InterfaceAPI, InterfaceResponse
from .errors import InterfaceException


class REPL:
    """Deterministic Read-Eval-Print Loop.
    
    Rules:
    - One command processed at a time
    - No background tasks
    - No state caching in interface
    - Structured JSON output only
    """
    
    def __init__(
        self,
        learning_manager=None,
        save_manager=None,
        resolved_config=None,
        save_dir: Optional[Path] = None,
        prompt: str = "> ",
        output_stream=None
    ):
        """Initialize REPL.
        
        Args:
            learning_manager: Phase 15 LearningManager
            save_manager: Phase 14 SaveManager
            resolved_config: Phase 13 ResolvedConfig
            save_dir: Directory for save files
            prompt: Command prompt string
            output_stream: Stream for output (default: stdout)
        """
        self._router = CommandRouter()
        self._api = InterfaceAPI(
            learning_manager=learning_manager,
            save_manager=save_manager,
            resolved_config=resolved_config,
            save_dir=save_dir
        )
        self._prompt = prompt
        self._output = output_stream or sys.stdout
        self._running = True
    
    def run(self) -> None:
        """Run the REPL loop.
        
        Exits when user enters 'quit' or EOF.
        """
        self._output.write("Spore Engine Interface v16.0.0\n")
        self._output.write("Type 'help' for available commands.\n")
        self._output.write("\n")
        
        while self._running:
            try:
                # Read
                self._output.write(self._prompt)
                self._output.flush()
                
                line = input()
                
                # Skip empty lines
                if not line.strip():
                    continue
                
                # Eval + Print
                response = self.execute_line(line)
                self._output.write(response.to_json())
                self._output.write("\n")
                
                # Check for quit
                if response.data and response.data.get("action") == "quit":
                    self._running = False
                    
            except EOFError:
                self._running = False
            except KeyboardInterrupt:
                self._output.write("\n")
                self._running = False
        
        self._output.write("Goodbye.\n")
    
    def execute_line(self, line: str) -> InterfaceResponse:
        """Execute a single command line.
        
        Args:
            line: Raw command input
            
        Returns:
            InterfaceResponse with result or error
        """
        try:
            # Parse command
            parsed = self._router.parse(line)
            
            # Execute
            return self._api.execute(parsed)
            
        except InterfaceException as e:
            return InterfaceResponse(
                success=False,
                command="unknown",
                error=e.to_dict()
            )
        except Exception as e:
            return InterfaceResponse(
                success=False,
                command="unknown",
                error={
                    "error_class": type(e).__name__,
                    "message": str(e)
                }
            )
    
    def execute_commands(self, commands: list) -> list:
        """Execute multiple commands in order.
        
        Args:
            commands: List of command strings
            
        Returns:
            List of InterfaceResponse objects
        """
        results = []
        for cmd in commands:
            if cmd.strip():
                results.append(self.execute_line(cmd))
        return results
    
    def stop(self) -> None:
        """Stop the REPL loop."""
        self._running = False


def create_repl(
    learning_manager=None,
    save_manager=None,
    resolved_config=None,
    save_dir: Optional[Path] = None
) -> REPL:
    """Factory function to create a REPL instance."""
    return REPL(
        learning_manager=learning_manager,
        save_manager=save_manager,
        resolved_config=resolved_config,
        save_dir=save_dir
    )

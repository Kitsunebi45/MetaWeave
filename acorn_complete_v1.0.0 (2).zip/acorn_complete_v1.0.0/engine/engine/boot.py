"""
Engine boot orchestrator with state-aware identity management.
This module enforces identity-first initialization with hard abort on tamper.
"""

import sys
import uuid
from pathlib import Path
from typing import Optional

from identity.engine_identity import EngineIdentity
from identity.identity_storage import IdentityStorage
from identity.exceptions import (
    IdentityError,
    IdentityMissingError,
    IdentityCorruptError,
    IdentityTamperError
)


class BootOrchestrator:
    """
    Manages engine boot sequence with identity-first enforcement.
    """
    
    def __init__(self, identity_dir: Path):
        """
        Initialize boot orchestrator.
        
        Args:
            identity_dir: Directory for identity storage
        """
        self.storage = IdentityStorage(identity_dir)
    
    def boot(self) -> EngineIdentity:
        """
        Execute state-aware boot sequence.
        
        Boot logic:
        - If identity directory does not exist → first boot (create new identity)
        - If identity directory exists but file missing → hard abort (tamper)
        - Otherwise → subsequent boot (verify existing identity)
        
        Returns:
            Verified EngineIdentity instance
            
        Raises:
            SystemExit: On any identity integrity failure (exit code 1)
        """
        try:
            # State-aware routing using directory existence as anchor
            if not self.storage.directory_exists():
                # Fresh install - no previous state
                return self._first_boot()
            
            elif not self.storage.exists():
                # Directory exists but identity file missing - likely tamper
                raise IdentityMissingError(
                    f"Identity directory exists but identity file is missing. "
                    f"This indicates identity deletion or tampering. "
                    f"Expected file: {self.storage.identity_file}"
                )
            
            else:
                # Normal subsequent boot
                return self._subsequent_boot()
                
        except IdentityError as e:
            self._abort_startup(str(e))
        except Exception as e:
            self._abort_startup(f"Unexpected identity verification failure: {e}")
    
    def _first_boot(self) -> EngineIdentity:
        """
        First boot: Create new persistent identity with atomic write.
        
        Returns:
            Newly created EngineIdentity
        """
        # Generate UUIDv4
        engine_uuid = str(uuid.uuid4())
        
        # Atomically write with read-only enforcement
        self.storage.write_identity(engine_uuid)
        
        # Return identity instance (validates UUIDv4)
        return EngineIdentity(engine_uuid)
    
    def _subsequent_boot(self) -> EngineIdentity:
        """
        Subsequent boot: Load and verify existing identity.
        
        Returns:
            Verified EngineIdentity from storage
            
        Raises:
            IdentityCorruptError: If identity content is invalid
            IdentityTamperError: If identity permissions are compromised
        """
        # Read with validation (checks 0-byte ghost, permissions, content)
        stored_uuid = self.storage.read_identity()
        
        # Return identity instance (validates UUIDv4 format/version)
        return EngineIdentity(stored_uuid)
    
    def _abort_startup(self, error_message: str) -> None:
        """
        Hard abort on identity integrity failure.
        
        Args:
            error_message: Description of failure
        """
        print(f"ENGINE BOOT FAILED: {error_message}", file=sys.stderr)
        print("Identity integrity is required. Cannot proceed.", file=sys.stderr)
        print("No silent recovery. No regeneration. Manual intervention required.", file=sys.stderr)
        sys.exit(1)


def boot_engine(identity_dir: Optional[Path] = None) -> EngineIdentity:
    """
    Main entry point for engine boot.
    
    Args:
        identity_dir: Directory for identity storage (default: ./engine_data/identity)
        
    Returns:
        Verified EngineIdentity instance
        
    Raises:
        SystemExit: On any identity integrity failure
    """
    if identity_dir is None:
        identity_dir = Path("./engine_data/identity")
    
    orchestrator = BootOrchestrator(identity_dir)
    return orchestrator.boot()


def boot_engine_with_console(identity_dir: Optional[Path] = None):
    """
    Complete boot sequence: Identity → Console → Engine → Executor → Packet Routing.
    Console does not exist if identity fails.
    
    This is the Phase 1 + Phase 2 + Phase 3 combined boot sequence.
    
    Args:
        identity_dir: Directory for identity storage (default: ./engine_data/identity)
        
    Returns:
        Tuple of (EngineIdentity, Console, EventDispatcher, Executor)
        
    Raises:
        SystemExit: On identity, console, or engine initialization failure
    """
    # PHASE 1: Identity (FIRST, IMMUTABLE)
    # boot_engine() already handles identity failure with stderr + sys.exit(1)
    identity = boot_engine(identity_dir)
    
    # PHASE 7: Validate rule registry at boot
    try:
        from .rules import validate_rule_registry
        validate_rule_registry()
    except Exception as e:
        print(f"RULE REGISTRY VALIDATION FAILED: {e}", file=sys.stderr)
        sys.exit(1)
    
    # PHASE 2 + PHASE 3 + PHASE 4 + PHASE 7.2: Console + Engine + Executor + Preview
    try:
        # Import Phase 2 modules (deferred to avoid circular imports)
        from console import Console, PacketRouter, PacketValidator, EventDispatcher
        
        # Import Phase 3 modules
        from .executor import Executor

        # Phase 6 engine (default)
        from .scenario_engine import ScenarioEngine

        # Phase 8: Parameter store + learning observer
        from .parameters import ParameterStore, ParameterDef
        from .learning.observer import LearningObserver
        
        # Phase 7.2: Import preview executor
        from console.preview import PreviewExecutor
        
        # Create packet infrastructure
        validator = PacketValidator()
        
        # PHASE 6: Create scenario-enabled deterministic engine
        parameter_store = ParameterStore(
            parameters_version="8.0",
            schema={
                "counter_threshold": ParameterDef(
                    name="counter_threshold",
                    type="int",
                    default=3,
                    min_value=0,
                    max_value=100,
                    description="Threshold for counter rules (indirect influence only)"
                )
            }
        )
        learning_observer = LearningObserver(parameter_store)

        engine = ScenarioEngine(parameter_store=parameter_store)
        executor = Executor(engine)
        
        # PHASE 7.2: Create preview executor
        preview_executor = PreviewExecutor(engine, learning_observer=learning_observer, parameter_store=parameter_store)
        
        # Create router with validator, executor, and preview executor
        router = PacketRouter(validator, executor, preview_executor, learning_observer=learning_observer, parameter_store=parameter_store)
        
        # Create console with injected dependencies
        console = Console(identity, router)
        
        # Create event dispatcher with console reference
        dispatcher = EventDispatcher(console)
        
        # Return identity, console, dispatcher, and executor
        # (dispatcher for Phase 2 compatibility, executor for Phase 3)
        return identity, console, dispatcher, executor
        
    except Exception as e:
        # Any Phase 2/3 failure is also fatal (but distinct from identity failure)
        print(f"CONSOLE/ENGINE INITIALIZATION FAILED: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)

"""Phase 14 Save Module — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module implements Phase 14 runtime state persistence.                  ║
║  Saves capture MUTABLE STATE ONLY — plates remain immutable.                 ║
║                                                                              ║
║  Key invariants:                                                             ║
║  - Plates = immutable substrate (Phase 13)                                   ║
║  - Saves = mutable runtime state (Phase 14)                                  ║
║  - They MUST NOT overlap                                                     ║
║  - Cold-load only (no hot-reload)                                            ║
║  - Any validation failure aborts load                                        ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-23                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝

Usage:
    from engine.save import SaveManager, RuntimeState, create_runtime_state
    
    # Create manager from resolved plate config
    save_mgr = SaveManager.from_resolved_config(resolved_config)
    
    # Save current state
    state = create_runtime_state(
        world_state={"counter": 42},
        entities={"e1": {"health": 100}},
        systems={"rule_engine": {"last_tick": 1000}}
    )
    envelope = save_mgr.save_state(Path("save.json"), tick=1000, state=state)
    
    # Load saved state
    envelope = save_mgr.load_state(Path("save.json"))
    # envelope.state contains RuntimeState
    # envelope.tick contains tick count
"""

from .save_manager import (
    # Manager
    SaveManager,
    
    # Data classes
    SaveEnvelope,
    RuntimeState,
    
    # Errors
    SaveError,
    SaveValidationError,
    SaveSchemaError,
    SaveCompatError,
    SaveIntegrityError,
    
    # Convenience
    create_runtime_state,
    compute_plate_stack_hash,
    
    # Constants
    SAVE_SCHEMA_VERSION,
    ENGINE_VERSION
)

__all__ = [
    # Manager
    'SaveManager',
    
    # Data classes
    'SaveEnvelope',
    'RuntimeState',
    
    # Errors
    'SaveError',
    'SaveValidationError',
    'SaveSchemaError',
    'SaveCompatError',
    'SaveIntegrityError',
    
    # Convenience
    'create_runtime_state',
    'compute_plate_stack_hash',
    
    # Constants
    'SAVE_SCHEMA_VERSION',
    'ENGINE_VERSION'
]

__version__ = "14.0.0"

"""Phase 14 Save Manager — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module implements Phase 14 runtime state persistence.                  ║
║  Saves capture MUTABLE STATE ONLY — plates remain immutable.                 ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-23                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝

Key invariants:
- Plates = immutable substrate (defined by Phase 13)
- Saves = mutable runtime state (defined by Phase 14)
- They MUST NOT overlap
- Cold-load only (no hot-reload)
- Any validation failure aborts load
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Optional, Set
from datetime import datetime, timezone
import hashlib
import json
import os
import tempfile
import uuid

from ..plates import ResolvedConfig


# =============================================================================
# CONSTANTS
# =============================================================================

SAVE_SCHEMA_VERSION = "1.0.0"
ENGINE_VERSION = "12.0.0"


# =============================================================================
# ERROR CLASSES
# =============================================================================

@dataclass(frozen=True)
class SaveError:
    """Structured save/load error."""
    error_class: str
    save_id: Optional[str]
    field_path: Optional[str]
    message: str
    
    def to_json(self) -> str:
        return json.dumps(asdict(self), separators=(',', ':'))


class SaveValidationError(Exception):
    """Base exception for save validation failures."""
    
    def __init__(self, error: SaveError):
        self.error = error
        super().__init__(error.message)


class SaveSchemaError(SaveValidationError):
    """Save envelope schema validation failure."""
    pass


class SaveCompatError(SaveValidationError):
    """Save compatibility failure (version/hash mismatch)."""
    pass


class SaveIntegrityError(SaveValidationError):
    """Save integrity failure (missing references)."""
    pass


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass(frozen=True)
class RuntimeState:
    """Immutable snapshot of runtime state.
    
    Contains ONLY mutable state — NOT plate definitions.
    """
    world_state: Dict[str, Any]
    entities: Dict[str, Dict[str, Any]]
    systems: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "world_state": dict(self.world_state),
            "entities": {k: dict(v) for k, v in self.entities.items()},
            "systems": dict(self.systems)
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'RuntimeState':
        return cls(
            world_state=data.get("world_state", {}),
            entities=data.get("entities", {}),
            systems=data.get("systems", {})
        )


@dataclass(frozen=True)
class SaveEnvelope:
    """Immutable save envelope.
    
    Contains:
    - Identity (save_id, timestamps)
    - Compatibility (engine_version, plate_stack_hash)
    - State (runtime state snapshot)
    """
    schema_version: str
    save_id: str
    engine_version: str
    plate_stack_hash: str
    created_at: str
    tick: int
    state: RuntimeState
    metadata: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "save_id": self.save_id,
            "engine_version": self.engine_version,
            "plate_stack_hash": self.plate_stack_hash,
            "created_at": self.created_at,
            "tick": self.tick,
            "state": self.state.to_dict(),
            "metadata": dict(self.metadata)
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SaveEnvelope':
        return cls(
            schema_version=data["schema_version"],
            save_id=data["save_id"],
            engine_version=data["engine_version"],
            plate_stack_hash=data["plate_stack_hash"],
            created_at=data["created_at"],
            tick=data["tick"],
            state=RuntimeState.from_dict(data.get("state", {})),
            metadata=data.get("metadata", {})
        )


# =============================================================================
# SAVE MANAGER
# =============================================================================

class SaveManager:
    """Manages runtime state persistence.
    
    Enforces:
    - Plate stack hash validation
    - Engine version validation
    - Atomic writes (temp file → rename)
    - Strict failure mode
    """
    
    def __init__(self, plate_stack_hash: str, engine_version: str = ENGINE_VERSION):
        """Initialize save manager.
        
        Args:
            plate_stack_hash: SHA256 hash of active plate stack
            engine_version: Current engine version
        """
        self._plate_stack_hash = plate_stack_hash
        self._engine_version = engine_version
    
    @classmethod
    def from_resolved_config(cls, config: ResolvedConfig) -> 'SaveManager':
        """Create SaveManager from ResolvedConfig.
        
        Uses the config's checksum as the plate_stack_hash.
        """
        return cls(plate_stack_hash=config.checksum)
    
    def save_state(
        self,
        path: Path,
        tick: int,
        state: RuntimeState,
        metadata: Optional[Dict[str, Any]] = None
    ) -> SaveEnvelope:
        """Save current runtime state to file.
        
        Performs:
        1. Create save envelope
        2. Serialize to JSON
        3. Write atomically (temp file → rename)
        
        Args:
            path: Output file path
            tick: Current engine tick
            state: Runtime state to save
            metadata: Optional metadata
            
        Returns:
            SaveEnvelope that was written
            
        Raises:
            OSError: If write fails
        """
        envelope = SaveEnvelope(
            schema_version=SAVE_SCHEMA_VERSION,
            save_id=str(uuid.uuid4()),
            engine_version=self._engine_version,
            plate_stack_hash=self._plate_stack_hash,
            created_at=datetime.now(timezone.utc).isoformat(),
            tick=tick,
            state=state,
            metadata=metadata or {}
        )
        
        # Serialize to JSON
        json_data = json.dumps(envelope.to_dict(), indent=2, sort_keys=True)
        
        # Atomic write: temp file → rename
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        fd, temp_path = tempfile.mkstemp(
            dir=path.parent,
            prefix=".save_",
            suffix=".tmp"
        )
        try:
            os.write(fd, json_data.encode('utf-8'))
            os.close(fd)
            os.replace(temp_path, path)
        except:
            os.close(fd)
            if os.path.exists(temp_path):
                os.unlink(temp_path)
            raise
        
        return envelope
    
    def load_state(self, path: Path) -> SaveEnvelope:
        """Load and validate save file.
        
        Performs:
        1. Read JSON
        2. Validate schema
        3. Validate plate_stack_hash matches
        4. Validate engine_version matches
        5. Return envelope
        
        Args:
            path: Save file path
            
        Returns:
            Validated SaveEnvelope
            
        Raises:
            SaveSchemaError: If schema validation fails
            SaveCompatError: If compatibility check fails
            FileNotFoundError: If file doesn't exist
        """
        if not path.exists():
            raise FileNotFoundError(f"Save file not found: {path}")
        
        # Read JSON
        try:
            raw_json = path.read_text(encoding='utf-8')
            data = json.loads(raw_json)
        except json.JSONDecodeError as e:
            raise SaveSchemaError(SaveError(
                error_class="SAVE_SCHEMA_ERROR",
                save_id=None,
                field_path=None,
                message=f"Invalid JSON: {e}"
            ))
        
        # Validate schema
        self._validate_schema(data)
        
        # Parse envelope
        envelope = SaveEnvelope.from_dict(data)
        
        # Validate compatibility
        self._validate_compatibility(envelope)
        
        return envelope
    
    def _validate_schema(self, data: Dict[str, Any]) -> None:
        """Validate save envelope schema."""
        save_id = data.get("save_id")
        
        # Required fields
        required = [
            "schema_version", "save_id", "engine_version",
            "plate_stack_hash", "created_at", "tick", "state"
        ]
        for field in required:
            if field not in data:
                raise SaveSchemaError(SaveError(
                    error_class="SAVE_SCHEMA_ERROR",
                    save_id=save_id,
                    field_path=field,
                    message=f"Missing required field: {field}"
                ))
        
        # Validate schema_version
        if data["schema_version"] != SAVE_SCHEMA_VERSION:
            raise SaveSchemaError(SaveError(
                error_class="SAVE_SCHEMA_ERROR",
                save_id=save_id,
                field_path="schema_version",
                message=f"Invalid schema_version: {data['schema_version']} (expected {SAVE_SCHEMA_VERSION})"
            ))
        
        # Validate tick is non-negative integer
        if not isinstance(data["tick"], int) or data["tick"] < 0:
            raise SaveSchemaError(SaveError(
                error_class="SAVE_SCHEMA_ERROR",
                save_id=save_id,
                field_path="tick",
                message=f"tick must be non-negative integer, got: {data['tick']}"
            ))
        
        # Validate state is object
        if not isinstance(data.get("state"), dict):
            raise SaveSchemaError(SaveError(
                error_class="SAVE_SCHEMA_ERROR",
                save_id=save_id,
                field_path="state",
                message="state must be an object"
            ))
    
    def _validate_compatibility(self, envelope: SaveEnvelope) -> None:
        """Validate save compatibility with current engine state."""
        
        # Check plate_stack_hash
        if envelope.plate_stack_hash != self._plate_stack_hash:
            raise SaveCompatError(SaveError(
                error_class="SAVE_COMPAT_ERROR",
                save_id=envelope.save_id,
                field_path="plate_stack_hash",
                message=f"Plate stack mismatch: save has {envelope.plate_stack_hash[:16]}..., "
                        f"current stack is {self._plate_stack_hash[:16]}..."
            ))
        
        # Check engine_version
        if envelope.engine_version != self._engine_version:
            raise SaveCompatError(SaveError(
                error_class="SAVE_COMPAT_ERROR",
                save_id=envelope.save_id,
                field_path="engine_version",
                message=f"Engine version mismatch: save has {envelope.engine_version}, "
                        f"current engine is {self._engine_version}"
            ))


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def create_runtime_state(
    world_state: Optional[Dict[str, Any]] = None,
    entities: Optional[Dict[str, Dict[str, Any]]] = None,
    systems: Optional[Dict[str, Any]] = None
) -> RuntimeState:
    """Create RuntimeState from optional components."""
    return RuntimeState(
        world_state=world_state or {},
        entities=entities or {},
        systems=systems or {}
    )


def compute_plate_stack_hash(config: ResolvedConfig) -> str:
    """Compute hash for a resolved plate stack.
    
    Uses the ResolvedConfig's checksum directly.
    """
    return config.checksum

"""Acorn Engine Console Socket Server.

Handles TCP socket connections from external consoles.
JSON line protocol (newline-delimited JSON).

Usage:
    from engine.console_socket import start_console_server
    
    # In main.py, BEFORE engine.run():
    server = start_console_server(on_message=handle_console_message)
"""

import socket
import threading
import json
from typing import Any, Callable, Dict, List, Optional

from .simulation import get_simulation, SimulationWorld


# Default port for console connections
DEFAULT_PORT = 17778


class ConsoleServer:
    """TCP server for console connections."""
    
    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = DEFAULT_PORT,
        on_message: Optional[Callable[[Dict[str, Any], 'ClientConnection'], None]] = None,
        on_connect: Optional[Callable[['ClientConnection'], None]] = None,
        on_disconnect: Optional[Callable[['ClientConnection'], None]] = None
    ):
        self.host = host
        self.port = port
        self.on_message = on_message
        self.on_connect = on_connect
        self.on_disconnect = on_disconnect
        
        self._server_sock: Optional[socket.socket] = None
        self._clients: List['ClientConnection'] = []
        self._clients_lock = threading.Lock()
        self._running = False
        self._accept_thread: Optional[threading.Thread] = None
    
    def start(self) -> bool:
        """Start the server.
        
        Returns:
            True if started successfully
        """
        try:
            self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_sock.bind((self.host, self.port))
            self._server_sock.listen(5)
            self._server_sock.settimeout(1.0)
            
            self._running = True
            self._accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
            self._accept_thread.start()
            
            print(f"[engine] Console socket listening on {self.host}:{self.port}")
            return True
            
        except Exception as e:
            print(f"[engine] Failed to start console socket: {e}")
            return False
    
    def stop(self) -> None:
        """Stop the server."""
        self._running = False
        
        with self._clients_lock:
            for client in self._clients:
                client.close()
            self._clients.clear()
        
        if self._server_sock:
            try:
                self._server_sock.close()
            except Exception:
                pass
            self._server_sock = None
    
    def broadcast(self, message: Dict[str, Any]) -> None:
        """Broadcast a message to all connected consoles."""
        with self._clients_lock:
            disconnected = []
            for client in self._clients:
                if not client.send(message):
                    disconnected.append(client)
            
            for client in disconnected:
                self._remove_client(client)
    
    def client_count(self) -> int:
        """Get number of connected clients."""
        with self._clients_lock:
            return len(self._clients)
    
    def _accept_loop(self) -> None:
        """Accept incoming connections."""
        while self._running:
            try:
                conn, addr = self._server_sock.accept()
                client = ClientConnection(conn, addr, self._handle_message, self._handle_disconnect)
                
                with self._clients_lock:
                    self._clients.append(client)
                
                print(f"[engine] Console connected from {addr}")
                
                if self.on_connect:
                    self.on_connect(client)
                    
            except socket.timeout:
                continue
            except Exception:
                if self._running:
                    continue
    
    def _handle_message(self, message: Dict[str, Any], client: 'ClientConnection') -> None:
        """Handle received message."""
        if self.on_message:
            self.on_message(message, client)
    
    def _handle_disconnect(self, client: 'ClientConnection') -> None:
        """Handle client disconnect."""
        self._remove_client(client)
    
    def _remove_client(self, client: 'ClientConnection') -> None:
        """Remove a client from the list."""
        with self._clients_lock:
            if client in self._clients:
                self._clients.remove(client)
                print(f"[engine] Console disconnected: {client.addr}")
                
                if self.on_disconnect:
                    self.on_disconnect(client)


class ClientConnection:
    """Represents a single console connection."""
    
    def __init__(
        self,
        sock: socket.socket,
        addr: tuple,
        on_message: Callable[[Dict[str, Any], 'ClientConnection'], None],
        on_disconnect: Callable[['ClientConnection'], None]
    ):
        self.sock = sock
        self.addr = addr
        self._on_message = on_message
        self._on_disconnect = on_disconnect
        
        self._recv_buffer = b""
        self._running = True
        
        self.sock.settimeout(0.1)
        
        self._recv_thread = threading.Thread(target=self._recv_loop, daemon=True)
        self._recv_thread.start()
    
    def send(self, message: Dict[str, Any]) -> bool:
        """Send a message to this client."""
        if not self._running:
            return False
        
        try:
            data = json.dumps(message).encode("utf-8") + b"\n"
            self.sock.sendall(data)
            return True
        except Exception:
            self.close()
            return False
    
    def close(self) -> None:
        """Close the connection."""
        self._running = False
        try:
            self.sock.close()
        except Exception:
            pass
    
    def _recv_loop(self) -> None:
        """Receive loop for this client."""
        while self._running:
            try:
                data = self.sock.recv(4096)
                if not data:
                    self._running = False
                    self._on_disconnect(self)
                    break
                
                self._recv_buffer += data
                self._process_buffer()
                
            except socket.timeout:
                continue
            except Exception:
                self._running = False
                self._on_disconnect(self)
                break
    
    def _process_buffer(self) -> None:
        """Process receive buffer for complete messages."""
        while b"\n" in self._recv_buffer:
            line, self._recv_buffer = self._recv_buffer.split(b"\n", 1)
            if not line:
                continue
            
            try:
                message = json.loads(line.decode("utf-8"))
                self._on_message(message, self)
            except json.JSONDecodeError:
                pass


# Global server instance
_console_server: Optional[ConsoleServer] = None


def default_message_handler(message: Dict[str, Any], client: ClientConnection) -> None:
    """Default message handler.
    
    Handles console protocol with simulation integration.
    """
    msg_type = message.get("type", "unknown")
    sim = get_simulation()
    
    if msg_type == "hello":
        print(f"[engine] Console handshake: {message.get('client')} v{message.get('version')}")
        client.send({
            "type": "hello_ack",
            "engine": "Acorn Engine",
            "version": "12.19.0"
        })
        # Send current state
        client.send(sim.get_state())
    
    elif msg_type == "command":
        payload = message.get("payload", {})
        command = payload.get("command", "")
        args = payload.get("args", {})
        
        # Handle via simulation
        result = sim.handle_command(command, args)
        client.send({
            "type": "command_result",
            "command": command,
            **result
        })
    
    elif msg_type == "user_text":
        payload = message.get("payload", {})
        text = payload.get("text", "").strip()
        text_lower = text.lower()
        
        # Parse user text as commands
        if text_lower in ("begin", "run", "start"):
            result = sim.handle_command("begin")
            print(f"[engine] User command '{text}': {result.get('message')}")
            client.send({"type": "command_result", "command": "begin", **result})
        
        elif text_lower in ("pause", "stop"):
            result = sim.handle_command("pause")
            print(f"[engine] User command '{text}': {result.get('message')}")
            client.send({"type": "command_result", "command": "pause", **result})
        
        elif text_lower in ("step", "tick"):
            result = sim.handle_command("step")
            print(f"[engine] User command '{text}': {result.get('message')}")
            client.send({"type": "command_result", "command": "step", **result})
        
        elif text_lower == "status":
            client.send(sim.get_state())
        
        # Avatar commands
        elif text_lower.startswith("avatar"):
            parts = text_lower.split()
            if len(parts) >= 2:
                value = parts[1] in ("true", "on", "yes", "1")
            else:
                value = True  # Toggle on by default
            result = sim.handle_command("avatar", {"value": value})
            print(f"[engine] Avatar command: {result.get('message')}")
            client.send({"type": "command_result", "command": "avatar", **result})
        
        # Look command
        elif text_lower in ("look", "l", "examine"):
            result = sim.handle_command("look")
            client.send({"type": "command_result", "command": "look", **result})
        
        # Movement commands
        elif text_lower in ("n", "north", "s", "south", "e", "east", "w", "west",
                            "ne", "nw", "se", "sw", "up", "down", "u", "d"):
            result = sim.handle_command("move", {"direction": text_lower})
            client.send({"type": "command_result", "command": "move", **result})
        
        # Go/move with direction
        elif text_lower.startswith(("go ", "move ", "walk ")):
            parts = text_lower.split(maxsplit=1)
            direction = parts[1] if len(parts) > 1 else "forward"
            result = sim.handle_command("move", {"direction": direction})
            client.send({"type": "command_result", "command": "move", **result})
        
        # Say command
        elif text_lower.startswith("say ") or text_lower.startswith("'"):
            speech = text[4:] if text_lower.startswith("say ") else text[1:]
            result = sim.handle_command("say", {"text": speech})
            client.send({"type": "command_result", "command": "say", **result})
        
        else:
            print(f"[engine] User text: {text}")
    
    else:
        print(f"[engine] Unknown message type: {msg_type}")


def start_console_server(
    on_message: Optional[Callable[[Dict[str, Any], ClientConnection], None]] = None,
    port: int = DEFAULT_PORT,
    host: str = "127.0.0.1"
) -> ConsoleServer:
    """Start the console server.
    
    Args:
        on_message: Custom message handler (uses default if None)
        port: Listen port (default: 17778)
        host: Bind address (default: 127.0.0.1)
        
    Returns:
        ConsoleServer instance
    """
    global _console_server
    
    if on_message is None:
        on_message = default_message_handler
    
    _console_server = ConsoleServer(
        host=host,
        port=port,
        on_message=on_message
    )
    _console_server.start()
    
    # Wire simulation to broadcast state changes to all consoles
    sim = get_simulation()
    sim.on_state_change = lambda state: broadcast_to_consoles(state)
    sim.on_event = lambda event_type, data: broadcast_to_consoles({
        "type": "event",
        "event": event_type,
        **data
    })
    
    return _console_server


def get_console_server() -> Optional[ConsoleServer]:
    """Get the global console server instance."""
    return _console_server


def broadcast_to_consoles(message: Dict[str, Any]) -> None:
    """Broadcast a message to all connected consoles.
    
    Convenience function for engine code to send updates.
    """
    if _console_server:
        _console_server.broadcast(message)

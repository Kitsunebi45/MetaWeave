"""Phase 18 Visualization Application — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module provides the visualization application.                         ║
║                                                                              ║
║  MODES:                                                                      ║
║  - Text mode: Console-based visualization (always available)                 ║
║  - GUI mode: Desktop window visualization (requires tkinter)                 ║
║                                                                              ║
║  CRITICAL CONSTRAINTS:                                                       ║
║  - Single-process                                                            ║
║  - No browser                                                                ║
║  - No embedded server                                                        ║
║  - No multi-user support                                                     ║
║  - Local-only                                                                ║
║  - Deterministic                                                             ║
║  - Non-networked                                                             ║
║                                                                              ║
║  READ-ONLY: No editing controls, no teaching, no scenario control.           ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from typing import Optional
import sys

from .adapter import VisualizationAdapter
from .renderer import TextRenderer
from .models import VisualizationSnapshot
from .views import WorldView, EntityView, LearningView, RuleView


class VisualizationApp:
    """Main visualization application.
    
    This application provides a read-only view of engine state.
    
    CRITICAL: This app MUST NOT:
    - Mutate engine state
    - Cache data persistently
    - Perform any write operations
    - Open network connections
    - Run background tasks
    
    Update model: Pull-based refresh only.
    """
    
    def __init__(self, interface_api, mode: str = "text"):
        """Initialize visualization app.
        
        Args:
            interface_api: Phase 16 InterfaceAPI instance
            mode: "text" for console, "gui" for desktop window
        """
        self._api = interface_api
        self._mode = mode
        
        # Create adapter (the ONLY data path)
        self._adapter = VisualizationAdapter(interface_api)
        
        # Create renderer
        self._renderer = TextRenderer(width=80)
        
        # Create views (all read-only)
        self._world_view = WorldView(self._renderer)
        self._entity_view = EntityView(self._renderer)
        self._learning_view = LearningView(self._renderer)
        self._rule_view = RuleView(self._renderer)
        
        # Current snapshot (ephemeral, no persistence)
        self._snapshot: Optional[VisualizationSnapshot] = None
    
    def refresh(self) -> VisualizationSnapshot:
        """Refresh data from engine via Phase 16 APIs.
        
        This is the ONLY data path. Refresh MUST NOT:
        - Trigger engine logic
        - Mutate state
        - Cache persistently
        
        Returns:
            Fresh VisualizationSnapshot
        """
        self._snapshot = self._adapter.get_snapshot()
        return self._snapshot
    
    def get_snapshot(self) -> Optional[VisualizationSnapshot]:
        """Get current snapshot (may be stale).
        
        Call refresh() for fresh data.
        """
        return self._snapshot
    
    # =========================================================================
    # TEXT MODE RENDERING
    # =========================================================================
    
    def render_status(self) -> str:
        """Render status view."""
        if self._snapshot is None:
            self.refresh()
        return self._renderer.render_status(self._snapshot.status)
    
    def render_world(self) -> str:
        """Render world view."""
        if self._snapshot is None:
            self.refresh()
        return self._world_view.render(self._snapshot.world)
    
    def render_entities(self) -> str:
        """Render entity view."""
        if self._snapshot is None:
            self.refresh()
        return self._entity_view.render(self._snapshot.entities)
    
    def render_learning(self, entity_id: str) -> str:
        """Render learning view for an entity."""
        learning = self._adapter.get_learning(entity_id)
        return self._learning_view.render(learning)
    
    def render_rules(self) -> str:
        """Render rules view."""
        if self._snapshot is None:
            self.refresh()
        return self._rule_view.render(self._snapshot.rules)
    
    def render_scenario(self) -> str:
        """Render scenario view."""
        if self._snapshot is None:
            self.refresh()
        return self._renderer.render_scenario(self._snapshot.scenario)
    
    def render_full(self) -> str:
        """Render complete visualization."""
        if self._snapshot is None:
            self.refresh()
        return self._renderer.render_snapshot(self._snapshot)
    
    # =========================================================================
    # TEXT MODE INTERACTIVE LOOP
    # =========================================================================
    
    def run_text_mode(self, output_stream=None) -> None:
        """Run text-mode interactive visualization.
        
        Commands:
        - refresh: Update data from engine
        - status: Show engine status
        - world: Show world view
        - entities: Show entity list
        - learning <id>: Show learning for entity
        - rules: Show rules view
        - scenario: Show scenario view
        - full: Show complete snapshot
        - quit: Exit visualization
        
        Args:
            output_stream: Output stream (default: stdout)
        """
        output = output_stream or sys.stdout
        
        output.write("=" * 60 + "\n")
        output.write("Spore Engine Visualization v18.0.0\n")
        output.write("=" * 60 + "\n")
        output.write("READ-ONLY visualization. Type 'help' for commands.\n")
        output.write("\n")
        
        self.refresh()
        running = True
        
        while running:
            try:
                output.write("vis> ")
                output.flush()
                
                line = input().strip()
                
                if not line:
                    continue
                
                parts = line.split()
                cmd = parts[0].lower()
                
                if cmd == "help":
                    output.write(self._get_help())
                elif cmd == "refresh":
                    self.refresh()
                    output.write("Data refreshed.\n")
                elif cmd == "status":
                    output.write(self.render_status())
                elif cmd == "world":
                    output.write(self.render_world())
                elif cmd == "entities":
                    output.write(self.render_entities())
                elif cmd == "learning":
                    if len(parts) < 2:
                        output.write("Usage: learning <entity_id>\n")
                    else:
                        output.write(self.render_learning(parts[1]))
                elif cmd == "rules":
                    output.write(self.render_rules())
                elif cmd == "scenario":
                    output.write(self.render_scenario())
                elif cmd == "full":
                    output.write(self.render_full())
                elif cmd == "quit" or cmd == "exit":
                    running = False
                else:
                    output.write(f"Unknown command: {cmd}\n")
                    output.write("Type 'help' for available commands.\n")
                
                output.write("\n")
                
            except EOFError:
                running = False
            except KeyboardInterrupt:
                output.write("\n")
                running = False
        
        output.write("Visualization closed. Engine state unchanged.\n")
    
    def _get_help(self) -> str:
        """Get help text."""
        return """
Available Commands (READ-ONLY):

  refresh         Update data from engine
  status          Show engine status
  world           Show world topology
  entities        Show entity list
  learning <id>   Show learning state for entity
  rules           Show rule configuration
  scenario        Show scenario status
  full            Show complete snapshot
  help            Show this help
  quit            Exit visualization

NOTE: This is a READ-ONLY visualization.
No commands will modify engine state.
"""
    
    # =========================================================================
    # GUI MODE (Tkinter)
    # =========================================================================
    
    def run_gui_mode(self) -> None:
        """Run GUI-mode desktop visualization.
        
        Requires tkinter to be available.
        
        Raises:
            ImportError: If tkinter is not available
        """
        try:
            import tkinter as tk
            from tkinter import ttk, scrolledtext
        except ImportError:
            raise ImportError(
                "tkinter is not available. "
                "Use run_text_mode() instead or install tkinter."
            )
        
        # Create main window
        root = tk.Tk()
        root.title("Spore Engine Visualization v18.0.0 [READ-ONLY]")
        root.geometry("900x700")
        
        # Create notebook for tabs
        notebook = ttk.Notebook(root)
        notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create text widgets for each view
        status_text = self._create_tab(notebook, "Status")
        world_text = self._create_tab(notebook, "World")
        entities_text = self._create_tab(notebook, "Entities")
        learning_text = self._create_tab(notebook, "Learning")
        rules_text = self._create_tab(notebook, "Rules")
        scenario_text = self._create_tab(notebook, "Scenario")
        
        # Entity ID input for learning view
        learning_frame = learning_text.master
        entity_frame = ttk.Frame(learning_frame)
        entity_frame.pack(fill=tk.X, padx=5, pady=2)
        ttk.Label(entity_frame, text="Entity ID:").pack(side=tk.LEFT)
        entity_entry = ttk.Entry(entity_frame, width=30)
        entity_entry.pack(side=tk.LEFT, padx=5)
        
        def update_learning():
            entity_id = entity_entry.get().strip()
            if entity_id:
                learning_text.config(state=tk.NORMAL)
                learning_text.delete(1.0, tk.END)
                learning_text.insert(tk.END, self.render_learning(entity_id))
                learning_text.config(state=tk.DISABLED)
        
        ttk.Button(entity_frame, text="Show", command=update_learning).pack(side=tk.LEFT)
        
        # Refresh button
        button_frame = ttk.Frame(root)
        button_frame.pack(fill=tk.X, padx=5, pady=5)
        
        def refresh_all():
            self.refresh()
            
            status_text.config(state=tk.NORMAL)
            status_text.delete(1.0, tk.END)
            status_text.insert(tk.END, self.render_status())
            status_text.config(state=tk.DISABLED)
            
            world_text.config(state=tk.NORMAL)
            world_text.delete(1.0, tk.END)
            world_text.insert(tk.END, self.render_world())
            world_text.config(state=tk.DISABLED)
            
            entities_text.config(state=tk.NORMAL)
            entities_text.delete(1.0, tk.END)
            entities_text.insert(tk.END, self.render_entities())
            entities_text.config(state=tk.DISABLED)
            
            rules_text.config(state=tk.NORMAL)
            rules_text.delete(1.0, tk.END)
            rules_text.insert(tk.END, self.render_rules())
            rules_text.config(state=tk.DISABLED)
            
            scenario_text.config(state=tk.NORMAL)
            scenario_text.delete(1.0, tk.END)
            scenario_text.insert(tk.END, self.render_scenario())
            scenario_text.config(state=tk.DISABLED)
        
        refresh_btn = ttk.Button(button_frame, text="Refresh", command=refresh_all)
        refresh_btn.pack(side=tk.LEFT, padx=5)
        
        ttk.Label(
            button_frame, 
            text="[READ-ONLY] No modifications to engine state",
            foreground="gray"
        ).pack(side=tk.RIGHT, padx=5)
        
        # Initial refresh
        refresh_all()
        
        # Run main loop
        root.mainloop()
    
    def _create_tab(self, notebook, title: str):
        """Create a tab with scrolled text widget.
        
        Args:
            notebook: Parent notebook
            title: Tab title
            
        Returns:
            ScrolledText widget
        """
        import tkinter as tk
        from tkinter import ttk, scrolledtext
        
        frame = ttk.Frame(notebook)
        notebook.add(frame, text=title)
        
        text = scrolledtext.ScrolledText(
            frame,
            wrap=tk.WORD,
            font=("Courier", 10),
            state=tk.DISABLED  # Read-only
        )
        text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        return text
    
    # =========================================================================
    # ENTRY POINT
    # =========================================================================
    
    def run(self) -> None:
        """Run the visualization application.
        
        Automatically selects mode based on initialization or environment.
        """
        if self._mode == "gui":
            try:
                self.run_gui_mode()
            except ImportError as e:
                print(f"GUI mode unavailable: {e}")
                print("Falling back to text mode.")
                self.run_text_mode()
        else:
            self.run_text_mode()


def create_visualization_app(interface_api, mode: str = "text") -> VisualizationApp:
    """Factory function to create a visualization app.
    
    Args:
        interface_api: Phase 16 InterfaceAPI instance
        mode: "text" or "gui"
        
    Returns:
        VisualizationApp instance
    """
    return VisualizationApp(interface_api, mode=mode)

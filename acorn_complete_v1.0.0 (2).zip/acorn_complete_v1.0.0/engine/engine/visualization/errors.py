"""Phase 18 Visualization Errors — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module defines error classes for the visualization layer.              ║
║  Visualization errors are NON-FATAL — engine continues running.              ║
║  Engine errors pass through unchanged.                                       ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from dataclasses import dataclass, asdict
from typing import Optional
import json


@dataclass(frozen=True)
class VisualizationError:
    """Structured visualization error."""
    error_class: str
    component: Optional[str]
    message: str
    
    def to_json(self) -> str:
        """Serialize to one-line JSON."""
        return json.dumps(asdict(self), separators=(',', ':'))
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return asdict(self)


class VisualizationException(Exception):
    """Base exception for visualization errors.
    
    These are NON-FATAL. Engine continues running.
    """
    
    def __init__(self, error: VisualizationError):
        self.error = error
        super().__init__(error.message)
    
    def to_json(self) -> str:
        return self.error.to_json()
    
    def to_dict(self) -> dict:
        return self.error.to_dict()


class AdapterError(VisualizationException):
    """Error in adapter layer."""
    pass


class RenderError(VisualizationException):
    """Error during rendering."""
    pass


class ViewError(VisualizationException):
    """Error in a specific view."""
    pass


# Error factories
def create_adapter_error(component: Optional[str], message: str) -> AdapterError:
    """Create an adapter error."""
    return AdapterError(VisualizationError(
        error_class="ADAPTER_ERROR",
        component=component,
        message=message
    ))


def create_render_error(component: Optional[str], message: str) -> RenderError:
    """Create a render error."""
    return RenderError(VisualizationError(
        error_class="RENDER_ERROR",
        component=component,
        message=message
    ))


def create_view_error(component: str, message: str) -> ViewError:
    """Create a view error."""
    return ViewError(VisualizationError(
        error_class="VIEW_ERROR",
        component=component,
        message=message
    ))

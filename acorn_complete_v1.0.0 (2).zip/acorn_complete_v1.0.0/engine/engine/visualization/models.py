"""Phase 18 Visualization Models — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module defines visualization-friendly data models.                     ║
║  Models provide STABLE SHAPE for rendering without mutating meaning.         ║
║  All models are IMMUTABLE (frozen dataclasses).                              ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from enum import Enum


# =============================================================================
# ENUMS
# =============================================================================

class ViewState(Enum):
    """State of a view component."""
    READY = "ready"
    LOADING = "loading"
    ERROR = "error"
    STALE = "stale"


# =============================================================================
# WORLD MODELS
# =============================================================================

@dataclass(frozen=True)
class RegionModel:
    """Visualization model for a region."""
    region_id: str
    name: str
    properties: Dict[str, Any] = field(default_factory=dict)
    is_active: bool = False  # Has entities present
    entity_count: int = 0


@dataclass(frozen=True)
class ConnectionModel:
    """Visualization model for a connection.
    
    Connections are BIDIRECTIONAL per Phase 13 lock.
    """
    from_region: str
    to_region: str
    bidirectional: bool = True  # Always True per Phase 13


@dataclass(frozen=True)
class WorldModel:
    """Visualization model for the world."""
    world_id: str
    topology_mode: str
    regions: tuple  # Tuple of RegionModel
    connections: tuple  # Tuple of ConnectionModel
    
    @property
    def region_count(self) -> int:
        return len(self.regions)
    
    @property
    def connection_count(self) -> int:
        return len(self.connections)


# =============================================================================
# ENTITY MODELS
# =============================================================================

@dataclass(frozen=True)
class EntityModel:
    """Visualization model for an entity."""
    entity_id: str
    template_id: Optional[str]
    region_id: Optional[str]
    capabilities: tuple = ()  # Tuple of capability names
    has_learning: bool = False  # Learning badge


@dataclass(frozen=True)
class EntityListModel:
    """Visualization model for entity list."""
    entities: tuple  # Tuple of EntityModel
    total_count: int
    
    def by_region(self, region_id: str) -> tuple:
        """Get entities in a specific region."""
        return tuple(e for e in self.entities if e.region_id == region_id)


# =============================================================================
# LEARNING MODELS
# =============================================================================

@dataclass(frozen=True)
class SkillEnvelopeModel:
    """Visualization model for a skill envelope."""
    skill_name: str
    current_value: float
    min_value: float
    max_value: float
    delta_per_event: float
    
    @property
    def normalized(self) -> float:
        """Value normalized to [0, 1] range."""
        range_size = self.max_value - self.min_value
        if range_size == 0:
            return 0.5
        return (self.current_value - self.min_value) / range_size


@dataclass(frozen=True)
class HistoryEntryModel:
    """Visualization model for a history entry."""
    tick: int
    event: str
    data: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class LearningModel:
    """Visualization model for entity learning state."""
    entity_id: str
    skills: tuple  # Tuple of SkillEnvelopeModel
    metrics: Dict[str, float] = field(default_factory=dict)
    history: tuple = ()  # Tuple of HistoryEntryModel (most recent)
    history_total: int = 0


# =============================================================================
# RULE MODELS
# =============================================================================

@dataclass(frozen=True)
class RuleModel:
    """Visualization model for a rule."""
    rule_id: str
    is_enabled: bool
    parameters: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RuleSetModel:
    """Visualization model for rule set."""
    rule_set_id: str
    mode: str
    rules: tuple  # Tuple of RuleModel
    enabled_count: int
    disabled_count: int


# =============================================================================
# SCENARIO MODELS
# =============================================================================

@dataclass(frozen=True)
class ScenarioModel:
    """Visualization model for scenario state."""
    scenario_id: Optional[str]
    world_ref: Optional[str]
    is_running: bool
    current_tick: int
    entity_count: int
    parameters: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# STATUS MODELS
# =============================================================================

@dataclass(frozen=True)
class EngineStatusModel:
    """Visualization model for engine status."""
    tick: int
    running: bool
    scenario_id: Optional[str]
    entity_count: int
    config_loaded: bool
    learning_enabled: bool
    save_enabled: bool


# =============================================================================
# COMPOSITE MODELS
# =============================================================================

@dataclass(frozen=True)
class VisualizationSnapshot:
    """Complete snapshot for visualization.
    
    This is the top-level model containing all data needed for a full render.
    """
    status: EngineStatusModel
    world: Optional[WorldModel]
    entities: EntityListModel
    scenario: Optional[ScenarioModel]
    rules: Optional[RuleSetModel]
    timestamp: str  # ISO-8601 when snapshot was taken

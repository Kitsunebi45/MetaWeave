"""Phase 18 Learning View — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  Learning View displays (Phase 15 Bridge):                                   ║
║  - Skills                                                                    ║
║  - Current values                                                            ║
║  - Min / max / delta envelope                                                ║
║  - Bounded learning history                                                  ║
║                                                                              ║
║  Visual forms allowed:                                                       ║
║  - Tables                                                                    ║
║  - Bars                                                                      ║
║  - Simple timelines                                                          ║
║                                                                              ║
║  NO EDITING CONTROLS.                                                        ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from typing import Optional

from ..models import LearningModel
from ..renderer import TextRenderer


class LearningView:
    """View for entity learning state.
    
    Displays:
    - Skills with current values
    - Envelope bounds (min/max/delta)
    - Metrics
    - History timeline
    
    This view is READ-ONLY. NO EDITING CONTROLS.
    """
    
    def __init__(self, renderer: TextRenderer):
        """Initialize learning view.
        
        Args:
            renderer: TextRenderer instance
        """
        self._renderer = renderer
    
    def render(self, learning: Optional[LearningModel]) -> str:
        """Render the learning view.
        
        Args:
            learning: LearningModel to render (or None)
            
        Returns:
            Rendered text
        """
        return self._renderer.render_learning(learning)
    
    def render_skills_table(self, learning: LearningModel) -> str:
        """Render skills as a table.
        
        Args:
            learning: LearningModel to render
            
        Returns:
            Rendered table
        """
        if not learning.skills:
            return "No skills"
        
        lines = [
            "┌────────────────────┬───────────┬───────────┬───────────┬───────────┐",
            "│ Skill              │ Current   │ Min       │ Max       │ Delta     │",
            "├────────────────────┼───────────┼───────────┼───────────┼───────────┤",
        ]
        
        for skill in learning.skills:
            lines.append(
                f"│ {skill.skill_name:18} │ {skill.current_value:9.3f} │ "
                f"{skill.min_value:9.2f} │ {skill.max_value:9.2f} │ "
                f"{skill.delta_per_event:9.3f} │"
            )
        
        lines.append("└────────────────────┴───────────┴───────────┴───────────┴───────────┘")
        return "\n".join(lines)
    
    def render_history_timeline(self, learning: LearningModel, max_entries: int = 10) -> str:
        """Render history as a simple timeline.
        
        Args:
            learning: LearningModel to render
            max_entries: Maximum entries to show
            
        Returns:
            Rendered timeline
        """
        if not learning.history:
            return "No history"
        
        entries = learning.history[-max_entries:]
        
        lines = [f"History ({len(entries)}/{learning.history_total} total):"]
        for entry in entries:
            lines.append(f"  [{entry.tick:6}] {entry.event}")
        
        return "\n".join(lines)

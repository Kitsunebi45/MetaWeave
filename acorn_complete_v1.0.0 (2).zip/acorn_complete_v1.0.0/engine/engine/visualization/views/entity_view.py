"""Phase 18 Entity View — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  Entity View displays:                                                       ║
║  - Entity ID                                                                 ║
║  - Current region / position                                                 ║
║  - Capabilities                                                              ║
║  - Learning summary badge (presence only)                                    ║
║                                                                              ║
║  Does NOT display:                                                           ║
║  - Rule internals                                                            ║
║  - Hidden engine systems                                                     ║
║  - Level 60 data                                                             ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from typing import Optional

from ..models import EntityListModel, EntityModel
from ..renderer import TextRenderer


class EntityView:
    """View for entities.
    
    Displays:
    - Entity ID
    - Current region / position
    - Capabilities
    - Learning badge (presence only)
    
    This view is READ-ONLY.
    """
    
    def __init__(self, renderer: TextRenderer):
        """Initialize entity view.
        
        Args:
            renderer: TextRenderer instance
        """
        self._renderer = renderer
        self._selected_entity: Optional[str] = None
    
    def render(self, entities: EntityListModel) -> str:
        """Render the entity list view.
        
        Args:
            entities: EntityListModel to render
            
        Returns:
            Rendered text
        """
        return self._renderer.render_entities(entities)
    
    def render_detail(self, entity: Optional[EntityModel]) -> str:
        """Render detail view for a single entity.
        
        Args:
            entity: EntityModel to render (or None)
            
        Returns:
            Rendered text
        """
        if entity is None:
            return "Entity not found"
        
        lines = [
            f"Entity: {entity.entity_id}",
            f"  Template:     {entity.template_id or '(none)'}",
            f"  Region:       {entity.region_id or '(none)'}",
            f"  Has Learning: {'YES' if entity.has_learning else 'NO'}",
            f"  Capabilities: {', '.join(entity.capabilities) or '(none)'}",
        ]
        return "\n".join(lines)
    
    def select_entity(self, entity_id: Optional[str]) -> None:
        """Select an entity for highlighting.
        
        Args:
            entity_id: Entity to select (or None to deselect)
        """
        self._selected_entity = entity_id
    
    @property
    def selected_entity(self) -> Optional[str]:
        """Get currently selected entity."""
        return self._selected_entity

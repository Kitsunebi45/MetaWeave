"""Phase 18 Rule View — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  Rule View displays:                                                         ║
║  - Active rules                                                              ║
║  - Disabled rules                                                            ║
║  - Envelope violations (if any)                                              ║
║                                                                              ║
║  Purpose: Transparency, Debugging, Trust                                     ║
║                                                                              ║
║  NO EDITING CONTROLS.                                                        ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from typing import Optional

from ..models import RuleSetModel
from ..renderer import TextRenderer


class RuleView:
    """View for rules and envelopes.
    
    Displays:
    - Active rules
    - Disabled rules
    - Rule set configuration
    
    Purpose: Transparency, Debugging, Trust
    
    This view is READ-ONLY. NO EDITING CONTROLS.
    """
    
    def __init__(self, renderer: TextRenderer):
        """Initialize rule view.
        
        Args:
            renderer: TextRenderer instance
        """
        self._renderer = renderer
    
    def render(self, rules: Optional[RuleSetModel]) -> str:
        """Render the rule view.
        
        Args:
            rules: RuleSetModel to render (or None)
            
        Returns:
            Rendered text
        """
        return self._renderer.render_rules(rules)
    
    def render_enabled_only(self, rules: RuleSetModel) -> str:
        """Render only enabled rules.
        
        Args:
            rules: RuleSetModel to render
            
        Returns:
            Rendered text for enabled rules
        """
        if not rules.rules:
            return "No rules"
        
        enabled = [r for r in rules.rules if r.is_enabled]
        
        if not enabled:
            return "No enabled rules"
        
        lines = [f"Enabled Rules ({len(enabled)}):"]
        for rule in enabled:
            lines.append(f"  ✓ {rule.rule_id}")
        
        return "\n".join(lines)
    
    def render_disabled_only(self, rules: RuleSetModel) -> str:
        """Render only disabled rules.
        
        Args:
            rules: RuleSetModel to render
            
        Returns:
            Rendered text for disabled rules
        """
        if not rules.rules:
            return "No rules"
        
        disabled = [r for r in rules.rules if not r.is_enabled]
        
        if not disabled:
            return "No disabled rules"
        
        lines = [f"Disabled Rules ({len(disabled)}):"]
        for rule in disabled:
            lines.append(f"  ✗ {rule.rule_id}")
        
        return "\n".join(lines)
    
    def render_summary(self, rules: RuleSetModel) -> str:
        """Render a brief summary of rule status.
        
        Args:
            rules: RuleSetModel to render
            
        Returns:
            Summary string
        """
        return f"Rules: {rules.enabled_count} enabled, {rules.disabled_count} disabled ({rules.mode} mode)"

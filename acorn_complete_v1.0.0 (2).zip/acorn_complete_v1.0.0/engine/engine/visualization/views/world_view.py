"""Phase 18 World View — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  World View displays:                                                        ║
║  - Regions / nodes                                                           ║
║  - Connections (bidirectional per Phase 13 lock)                             ║
║  - Active scenario region(s)                                                 ║
║                                                                              ║
║  NO interaction beyond hover/select.                                         ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from typing import Optional

from ..models import WorldModel
from ..renderer import TextRenderer


class WorldView:
    """View for world topology.
    
    Displays:
    - Regions / nodes
    - Connections (bidirectional)
    - Activity overlay from engine state
    
    This view is READ-ONLY.
    """
    
    def __init__(self, renderer: TextRenderer):
        """Initialize world view.
        
        Args:
            renderer: TextRenderer instance
        """
        self._renderer = renderer
        self._selected_region: Optional[str] = None
    
    def render(self, world: Optional[WorldModel]) -> str:
        """Render the world view.
        
        Args:
            world: WorldModel to render (or None)
            
        Returns:
            Rendered text
        """
        return self._renderer.render_world(world)
    
    def select_region(self, region_id: Optional[str]) -> None:
        """Select a region for highlighting.
        
        Args:
            region_id: Region to select (or None to deselect)
        """
        self._selected_region = region_id
    
    @property
    def selected_region(self) -> Optional[str]:
        """Get currently selected region."""
        return self._selected_region

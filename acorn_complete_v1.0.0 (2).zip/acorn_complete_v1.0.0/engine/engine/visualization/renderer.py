"""Phase 18 Visualization Renderer — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module provides text-based rendering for visualization.                ║
║  Rendering is DETERMINISTIC — same state produces same output.               ║
║  Renderer holds NO persistent state.                                         ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from typing import List, Optional

from .models import (
    WorldModel, EntityListModel, LearningModel,
    RuleSetModel, ScenarioModel, EngineStatusModel,
    VisualizationSnapshot
)


class TextRenderer:
    """Text-based renderer for visualization.
    
    Produces deterministic text output from visualization models.
    Holds NO persistent state.
    """
    
    def __init__(self, width: int = 80):
        """Initialize renderer.
        
        Args:
            width: Output width in characters
        """
        self._width = width
    
    def _header(self, title: str) -> str:
        """Create a header line."""
        return f"{'=' * self._width}\n{title.center(self._width)}\n{'=' * self._width}"
    
    def _subheader(self, title: str) -> str:
        """Create a subheader line."""
        return f"\n{'-' * self._width}\n{title}\n{'-' * self._width}"
    
    def _progress_bar(self, value: float, width: int = 20) -> str:
        """Create a text progress bar."""
        filled = int(value * width)
        empty = width - filled
        return f"[{'█' * filled}{'░' * empty}]"
    
    # =========================================================================
    # VIEW RENDERERS
    # =========================================================================
    
    def render_status(self, status: EngineStatusModel) -> str:
        """Render engine status."""
        lines = [
            self._header("ENGINE STATUS"),
            "",
            f"  Tick:           {status.tick}",
            f"  Running:        {'YES' if status.running else 'NO'}",
            f"  Scenario:       {status.scenario_id or '(none)'}",
            f"  Entity Count:   {status.entity_count}",
            f"  Config Loaded:  {'YES' if status.config_loaded else 'NO'}",
            f"  Learning:       {'ENABLED' if status.learning_enabled else 'DISABLED'}",
            f"  Save System:    {'ENABLED' if status.save_enabled else 'DISABLED'}",
            ""
        ]
        return "\n".join(lines)
    
    def render_world(self, world: Optional[WorldModel]) -> str:
        """Render world view."""
        if world is None:
            return self._header("WORLD") + "\n\n  (no world loaded)\n"
        
        lines = [
            self._header("WORLD"),
            "",
            f"  World ID:       {world.world_id}",
            f"  Topology:       {world.topology_mode}",
            f"  Regions:        {world.region_count}",
            f"  Connections:    {world.connection_count}",
            self._subheader("Regions"),
        ]
        
        for region in world.regions:
            active = " ★" if region.is_active else ""
            count = f" ({region.entity_count} entities)" if region.entity_count > 0 else ""
            lines.append(f"  [{region.region_id}] {region.name}{active}{count}")
        
        lines.append(self._subheader("Connections (bidirectional)"))
        
        for conn in world.connections:
            lines.append(f"  {conn.from_region} <-> {conn.to_region}")
        
        lines.append("")
        return "\n".join(lines)
    
    def render_entities(self, entities: EntityListModel) -> str:
        """Render entity list view."""
        lines = [
            self._header("ENTITIES"),
            "",
            f"  Total: {entities.total_count}",
            self._subheader("Entity List"),
        ]
        
        if not entities.entities:
            lines.append("  (no entities)")
        else:
            for entity in entities.entities:
                learning_badge = " [L]" if entity.has_learning else ""
                location = f"@ {entity.region_id}" if entity.region_id else "(no location)"
                template = f"({entity.template_id})" if entity.template_id else ""
                lines.append(f"  {entity.entity_id}{learning_badge} {template} {location}")
        
        lines.append("")
        return "\n".join(lines)
    
    def render_learning(self, learning: Optional[LearningModel]) -> str:
        """Render learning view for an entity."""
        if learning is None:
            return self._header("LEARNING") + "\n\n  (no learning data)\n"
        
        lines = [
            self._header(f"LEARNING: {learning.entity_id}"),
            self._subheader("Skills"),
        ]
        
        if not learning.skills:
            lines.append("  (no skills)")
        else:
            for skill in learning.skills:
                bar = self._progress_bar(skill.normalized, 15)
                lines.append(f"  {skill.skill_name:15} {bar} {skill.current_value:.3f}")
                lines.append(f"                  min={skill.min_value:.2f} max={skill.max_value:.2f} delta={skill.delta_per_event:.3f}")
        
        lines.append(self._subheader("Metrics"))
        
        if not learning.metrics:
            lines.append("  (no metrics)")
        else:
            for name, value in learning.metrics.items():
                lines.append(f"  {name:20} {value}")
        
        lines.append(self._subheader(f"History (showing {len(learning.history)}/{learning.history_total})"))
        
        if not learning.history:
            lines.append("  (no history)")
        else:
            for entry in learning.history[-5:]:  # Last 5
                lines.append(f"  tick {entry.tick:6}: {entry.event}")
        
        lines.append("")
        return "\n".join(lines)
    
    def render_rules(self, rules: Optional[RuleSetModel]) -> str:
        """Render rule view."""
        if rules is None:
            return self._header("RULES") + "\n\n  (no rules loaded)\n"
        
        lines = [
            self._header("RULES"),
            "",
            f"  Rule Set:  {rules.rule_set_id}",
            f"  Mode:      {rules.mode}",
            f"  Enabled:   {rules.enabled_count}",
            f"  Disabled:  {rules.disabled_count}",
            self._subheader("Rule Status"),
        ]
        
        for rule in rules.rules:
            status = "✓ ENABLED" if rule.is_enabled else "✗ DISABLED"
            lines.append(f"  {rule.rule_id:30} {status}")
        
        lines.append("")
        return "\n".join(lines)
    
    def render_scenario(self, scenario: Optional[ScenarioModel]) -> str:
        """Render scenario view."""
        if scenario is None:
            return self._header("SCENARIO") + "\n\n  (no scenario loaded)\n"
        
        lines = [
            self._header("SCENARIO"),
            "",
            f"  Scenario ID:  {scenario.scenario_id or '(none)'}",
            f"  World Ref:    {scenario.world_ref or '(none)'}",
            f"  Running:      {'YES' if scenario.is_running else 'NO'}",
            f"  Current Tick: {scenario.current_tick}",
            f"  Entities:     {scenario.entity_count}",
            self._subheader("Parameters"),
        ]
        
        if not scenario.parameters:
            lines.append("  (no parameters)")
        else:
            for key, value in scenario.parameters.items():
                lines.append(f"  {key}: {value}")
        
        lines.append("")
        return "\n".join(lines)
    
    def render_snapshot(self, snapshot: VisualizationSnapshot) -> str:
        """Render complete snapshot."""
        lines = [
            self._header("VISUALIZATION SNAPSHOT"),
            f"  Timestamp: {snapshot.timestamp}",
            "",
            self.render_status(snapshot.status),
            self.render_world(snapshot.world),
            self.render_entities(snapshot.entities),
            self.render_scenario(snapshot.scenario),
            self.render_rules(snapshot.rules),
        ]
        return "\n".join(lines)
    
    def render_error(self, error_class: str, message: str) -> str:
        """Render an error display."""
        lines = [
            self._header("ERROR"),
            "",
            f"  Type:    {error_class}",
            f"  Message: {message}",
            ""
        ]
        return "\n".join(lines)

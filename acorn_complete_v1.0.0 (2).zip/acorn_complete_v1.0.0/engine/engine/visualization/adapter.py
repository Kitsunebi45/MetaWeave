"""Phase 18 Visualization Adapter — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module translates Phase 16 read responses into visualization models.   ║
║                                                                              ║
║  CRITICAL RULES:                                                             ║
║  - Adapter MUST NOT cache data                                               ║
║  - Adapter MUST NOT normalize or transform semantics                         ║
║  - Adapter MUST NOT infer missing data                                       ║
║  - Adapter MUST ONLY consume Phase 16 read-only APIs                         ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .models import (
    WorldModel, RegionModel, ConnectionModel,
    EntityModel, EntityListModel,
    LearningModel, SkillEnvelopeModel, HistoryEntryModel,
    RuleModel, RuleSetModel,
    ScenarioModel, EngineStatusModel,
    VisualizationSnapshot
)
from .errors import create_adapter_error


class VisualizationAdapter:
    """Translates Phase 16 responses into visualization models.
    
    This adapter:
    - Consumes ONLY Phase 16 read-only APIs
    - Does NOT cache data
    - Does NOT normalize or transform semantics
    - Does NOT infer missing data
    - Provides stable shape for rendering
    """
    
    def __init__(self, interface_api):
        """Initialize adapter with Phase 16 InterfaceAPI.
        
        Args:
            interface_api: Phase 16 InterfaceAPI instance
        """
        self._api = interface_api
        self._router = None
        
        # Import router for command execution
        from ..interface.command_router import CommandRouter
        self._router = CommandRouter()
    
    def _execute_read(self, command: str) -> Dict[str, Any]:
        """Execute a read-only command via Phase 16.
        
        Returns the data portion of the response, or empty dict on error.
        """
        try:
            parsed = self._router.parse(command)
            response = self._api.execute(parsed)
            
            if response.success and response.data:
                return response.data
            return {}
        except Exception:
            return {}
    
    # =========================================================================
    # WORLD ADAPTER
    # =========================================================================
    
    def get_world(self) -> Optional[WorldModel]:
        """Get world model from Phase 16."""
        data = self._execute_read("show world")
        
        if not data or data.get("world") is None:
            world_id = data.get("world_id")
            if not world_id:
                return None
        else:
            return None
        
        # Build region models
        regions = []
        entity_data = self._execute_read("show entities")
        entity_ids = entity_data.get("entities", [])
        
        # Get entity locations for activity overlay
        entity_regions = {}
        for eid in entity_ids:
            e_data = self._execute_read(f"show entity {eid}")
            if e_data.get("found") and e_data.get("state", {}).get("region_id"):
                region_id = e_data["state"]["region_id"]
                entity_regions[region_id] = entity_regions.get(region_id, 0) + 1
        
        for r in data.get("regions", []):
            region_id = r.get("region_id", "")
            regions.append(RegionModel(
                region_id=region_id,
                name=r.get("name", region_id),
                properties=r.get("properties", {}),
                is_active=region_id in entity_regions,
                entity_count=entity_regions.get(region_id, 0)
            ))
        
        # Build connection models (bidirectional per Phase 13)
        connections = []
        for c in data.get("connections", []):
            connections.append(ConnectionModel(
                from_region=c.get("from", ""),
                to_region=c.get("to", ""),
                bidirectional=True  # Always True per Phase 13 lock
            ))
        
        return WorldModel(
            world_id=data.get("world_id", ""),
            topology_mode=data.get("topology_mode", "graph"),
            regions=tuple(regions),
            connections=tuple(connections)
        )
    
    # =========================================================================
    # ENTITY ADAPTER
    # =========================================================================
    
    def get_entities(self) -> EntityListModel:
        """Get entity list model from Phase 16."""
        data = self._execute_read("show entities")
        entity_ids = data.get("entities", [])
        
        entities = []
        for eid in entity_ids:
            e_data = self._execute_read(f"show entity {eid}")
            
            if e_data.get("found"):
                state = e_data.get("state", {})
                
                # Check if entity has learning
                learning_data = self._execute_read(f"show learning {eid}")
                has_learning = bool(learning_data.get("skills", {}))
                
                entities.append(EntityModel(
                    entity_id=eid,
                    template_id=state.get("template_id"),
                    region_id=state.get("region_id"),
                    capabilities=tuple(state.get("capabilities", [])),
                    has_learning=has_learning
                ))
            else:
                entities.append(EntityModel(
                    entity_id=eid,
                    template_id=None,
                    region_id=None,
                    capabilities=(),
                    has_learning=False
                ))
        
        return EntityListModel(
            entities=tuple(entities),
            total_count=data.get("count", len(entities))
        )
    
    def get_entity(self, entity_id: str) -> Optional[EntityModel]:
        """Get single entity model."""
        data = self._execute_read(f"show entity {entity_id}")
        
        if not data.get("found"):
            return None
        
        state = data.get("state", {})
        learning_data = self._execute_read(f"show learning {entity_id}")
        has_learning = bool(learning_data.get("skills", {}))
        
        return EntityModel(
            entity_id=entity_id,
            template_id=state.get("template_id"),
            region_id=state.get("region_id"),
            capabilities=tuple(state.get("capabilities", [])),
            has_learning=has_learning
        )
    
    # =========================================================================
    # LEARNING ADAPTER
    # =========================================================================
    
    def get_learning(self, entity_id: str, envelopes: Optional[Dict] = None) -> Optional[LearningModel]:
        """Get learning model for an entity.
        
        Args:
            entity_id: Entity to get learning for
            envelopes: Optional dict of skill envelopes for min/max/delta
        """
        data = self._execute_read(f"show learning {entity_id}")
        
        if "error" in data:
            return None
        
        # Build skill models
        skills = []
        for skill_name, value in data.get("skills", {}).items():
            # Get envelope if available
            env = envelopes.get(skill_name, {}) if envelopes else {}
            skills.append(SkillEnvelopeModel(
                skill_name=skill_name,
                current_value=float(value),
                min_value=float(env.get("min", 0.0)),
                max_value=float(env.get("max", 1.0)),
                delta_per_event=float(env.get("delta_per_event", 0.05))
            ))
        
        # Build history models
        history = []
        for h in data.get("history", []):
            history.append(HistoryEntryModel(
                tick=h.get("tick", 0),
                event=h.get("event", ""),
                data={k: v for k, v in h.items() if k not in ("tick", "event")}
            ))
        
        return LearningModel(
            entity_id=entity_id,
            skills=tuple(skills),
            metrics=data.get("metrics", {}),
            history=tuple(history),
            history_total=data.get("history_count", len(history))
        )
    
    # =========================================================================
    # RULE ADAPTER
    # =========================================================================
    
    def get_rules(self) -> Optional[RuleSetModel]:
        """Get rule set model from Phase 16."""
        data = self._execute_read("show rules")
        
        if data.get("rules") is None and not data.get("rule_set_id"):
            return None
        
        # Build rule models
        rules = []
        enabled_ids = set(data.get("enabled_rule_ids", []))
        
        # All rules from registry
        from ..rules import RULE_REGISTRY
        for rule_id in RULE_REGISTRY.keys():
            rules.append(RuleModel(
                rule_id=rule_id,
                is_enabled=rule_id in enabled_ids,
                parameters={}
            ))
        
        enabled_count = len(enabled_ids)
        disabled_count = len(rules) - enabled_count
        
        return RuleSetModel(
            rule_set_id=data.get("rule_set_id", "default"),
            mode=data.get("mode", "strict"),
            rules=tuple(rules),
            enabled_count=enabled_count,
            disabled_count=disabled_count
        )
    
    # =========================================================================
    # SCENARIO ADAPTER
    # =========================================================================
    
    def get_scenario(self) -> Optional[ScenarioModel]:
        """Get scenario model from Phase 16."""
        data = self._execute_read("show scenario")
        status = self._execute_read("show status")
        
        if data.get("scenario") is None and not data.get("scenario_id"):
            return None
        
        return ScenarioModel(
            scenario_id=data.get("scenario_id"),
            world_ref=data.get("world_ref"),
            is_running=status.get("running", False),
            current_tick=status.get("tick", 0),
            entity_count=status.get("entity_count", 0),
            parameters=data.get("parameters", {})
        )
    
    # =========================================================================
    # STATUS ADAPTER
    # =========================================================================
    
    def get_status(self) -> EngineStatusModel:
        """Get engine status model from Phase 16."""
        data = self._execute_read("show status")
        
        return EngineStatusModel(
            tick=data.get("tick", 0),
            running=data.get("running", False),
            scenario_id=data.get("scenario_id"),
            entity_count=data.get("entity_count", 0),
            config_loaded=data.get("config_loaded", False),
            learning_enabled=data.get("learning_enabled", False),
            save_enabled=data.get("save_enabled", False)
        )
    
    # =========================================================================
    # SNAPSHOT
    # =========================================================================
    
    def get_snapshot(self) -> VisualizationSnapshot:
        """Get complete visualization snapshot.
        
        This is the main entry point for rendering.
        """
        return VisualizationSnapshot(
            status=self.get_status(),
            world=self.get_world(),
            entities=self.get_entities(),
            scenario=self.get_scenario(),
            rules=self.get_rules(),
            timestamp=datetime.now(timezone.utc).isoformat()
        )

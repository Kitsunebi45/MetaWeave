"""Phase 18 Visualization Module — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module provides READ-ONLY visualization of Spore Engine state.         ║
║                                                                              ║
║  CRITICAL CONSTRAINTS:                                                       ║
║  - Observer-only: MUST NOT mutate engine state                               ║
║  - Read-path purity: ONLY consumes Phase 16 read APIs                        ║
║  - Deterministic: No prediction, smoothing, extrapolation                    ║
║  - Isolation: No persistent state                                            ║
║  - Offline only: No networking, telemetry, or remote dashboards              ║
║                                                                              ║
║  DATA PATH:                                                                  ║
║    Engine Core → Phase 16 Read APIs → Adapter → Visualization UI             ║
║                                                                              ║
║  NO OTHER DATA PATHS ARE PERMITTED.                                          ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝

Usage:
    from engine.interface import InterfaceAPI
    from engine.visualization import create_visualization_app
    
    # Create interface API
    api = InterfaceAPI(learning_manager=..., resolved_config=...)
    
    # Create and run visualization
    app = create_visualization_app(api, mode="text")
    app.run()
"""

from .errors import (
    VisualizationError,
    VisualizationException,
    AdapterError,
    RenderError,
    ViewError
)

from .models import (
    ViewState,
    RegionModel,
    ConnectionModel,
    WorldModel,
    EntityModel,
    EntityListModel,
    SkillEnvelopeModel,
    HistoryEntryModel,
    LearningModel,
    RuleModel,
    RuleSetModel,
    ScenarioModel,
    EngineStatusModel,
    VisualizationSnapshot
)

from .adapter import VisualizationAdapter

from .renderer import TextRenderer

from .views import (
    WorldView,
    EntityView,
    LearningView,
    RuleView
)

from .app import (
    VisualizationApp,
    create_visualization_app
)

__all__ = [
    # Errors
    'VisualizationError',
    'VisualizationException',
    'AdapterError',
    'RenderError',
    'ViewError',
    
    # Models
    'ViewState',
    'RegionModel',
    'ConnectionModel',
    'WorldModel',
    'EntityModel',
    'EntityListModel',
    'SkillEnvelopeModel',
    'HistoryEntryModel',
    'LearningModel',
    'RuleModel',
    'RuleSetModel',
    'ScenarioModel',
    'EngineStatusModel',
    'VisualizationSnapshot',
    
    # Adapter
    'VisualizationAdapter',
    
    # Renderer
    'TextRenderer',
    
    # Views
    'WorldView',
    'EntityView',
    'LearningView',
    'RuleView',
    
    # App
    'VisualizationApp',
    'create_visualization_app'
]

__version__ = "18.0.0"


"""engine.parameters

Phase 8: Bounded Parameter Store (finite, typed, auditable).

Conservative constraints:
- Finite schema (no dynamic parameter creation)
- Typed values: int | float | bool
- Bounded: min/max enforced
- Versioned for replayability
- Resettable to defaults
- Global disable switch (learning can be disabled without breaking system)

This module provides:
- ParameterDef: immutable parameter definition
- ParameterSet: versioned snapshot of values
- ParameterStore: current parameter state + controls
- ParametersView: read-only access for evaluation paths (rules only)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Union, Literal, Any


ParamType = Literal["int", "float", "bool"]
ParamValue = Union[int, float, bool]


@dataclass(frozen=True)
class ParameterDef:
    name: str
    type: ParamType
    default: ParamValue
    min_value: Optional[ParamValue] = None
    max_value: Optional[ParamValue] = None
    description: str = ""

    def validate_value(self, value: ParamValue) -> None:
        # Type validation (strict)
        if self.type == "int":
            if type(value) is not int:
                raise TypeError(f"Parameter '{self.name}' expects int, got {type(value).__name__}")
        elif self.type == "float":
            if type(value) is not float:
                raise TypeError(f"Parameter '{self.name}' expects float, got {type(value).__name__}")
        elif self.type == "bool":
            if type(value) is not bool:
                raise TypeError(f"Parameter '{self.name}' expects bool, got {type(value).__name__}")
        else:
            raise ValueError(f"Unknown parameter type: {self.type}")

        # Bounds validation (only for numeric)
        if self.type in ("int", "float"):
            if self.min_value is not None and value < self.min_value:  # type: ignore[operator]
                raise ValueError(f"Parameter '{self.name}' below min ({value} < {self.min_value})")
            if self.max_value is not None and value > self.max_value:  # type: ignore[operator]
                raise ValueError(f"Parameter '{self.name}' above max ({value} > {self.max_value})")


@dataclass(frozen=True)
class ParameterSet:
    """Versioned snapshot of parameter values."""
    parameters_version: str
    values: Dict[str, ParamValue]


class ParametersView:
    """Read-only accessor used by evaluation paths (rules)."""

    def __init__(self, param_set: ParameterSet, schema: Dict[str, ParameterDef]):
        self._set = param_set
        self._schema = schema

    @property
    def parameters_version(self) -> str:
        return self._set.parameters_version

    def get_int(self, name: str, default: int) -> int:
        if name not in self._schema:
            return default
        val = self._set.values.get(name, self._schema[name].default)
        return int(val)  # safe after schema validation

    def get_float(self, name: str, default: float) -> float:
        if name not in self._schema:
            return default
        val = self._set.values.get(name, self._schema[name].default)
        return float(val)

    def get_bool(self, name: str, default: bool) -> bool:
        if name not in self._schema:
            return default
        val = self._set.values.get(name, self._schema[name].default)
        return bool(val)


class ParameterStore:
    """Holds current ParameterSet. All writes are controlled by Phase 8 only."""

    def __init__(self, *, parameters_version: str, schema: Dict[str, ParameterDef]):
        if not parameters_version:
            raise ValueError("parameters_version cannot be empty")
        if not schema:
            raise ValueError("Parameter schema cannot be empty")
        self._schema = dict(schema)
        self._parameters_version = parameters_version

        # Initialize to defaults (validated)
        default_values: Dict[str, ParamValue] = {}
        for name, pdef in self._schema.items():
            pdef.validate_value(pdef.default)
            default_values[name] = pdef.default

        self._current = ParameterSet(parameters_version=self._parameters_version, values=default_values)

        # Global learning enable/disable switch (default disabled to preserve Phase 7 behavior)
        self.learning_enabled: bool = False

    @property
    def schema(self) -> Dict[str, ParameterDef]:
        return dict(self._schema)

    @property
    def parameters_version(self) -> str:
        return self._parameters_version

    def snapshot(self) -> ParameterSet:
        return ParameterSet(parameters_version=self._current.parameters_version, values=dict(self._current.values))

    def view(self) -> ParametersView:
        return ParametersView(self.snapshot(), self._schema)

    def reset_to_defaults(self) -> None:
        # Reset values to defaults, keeping schema version constant (R1)
        values: Dict[str, ParamValue] = {}
        for name, pdef in self._schema.items():
            pdef.validate_value(pdef.default)
            values[name] = pdef.default
        self._current = ParameterSet(parameters_version=self._parameters_version, values=values)

    def _validate_full_set(self, candidate: Dict[str, ParamValue]) -> None:
        # Must contain only known parameters
        for name in candidate.keys():
            if name not in self._schema:
                raise KeyError(f"Unknown parameter '{name}'")
        # Must contain all defined parameters
        for name in self._schema.keys():
            if name not in candidate:
                raise KeyError(f"Missing parameter '{name}'")
        # Validate each value
        for name, val in candidate.items():
            self._schema[name].validate_value(val)

    def commit(self, new_values: Dict[str, ParamValue]) -> None:
        """Atomic commit of a full parameter set (Phase 8 only)."""
        self._validate_full_set(new_values)
        self._current = ParameterSet(parameters_version=self._parameters_version, values=dict(new_values))

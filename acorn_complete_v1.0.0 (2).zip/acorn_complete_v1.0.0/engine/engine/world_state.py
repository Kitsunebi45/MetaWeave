"""engine.world_state

Phase 5: Deterministic, in-memory WorldState.

WorldState is RAM-only, resettable, and fully explicit.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

from .entity import Entity, normalize_entity_state, validate_entity


EntityID = str


@dataclass(frozen=True)
class EntityConfig:
    """Baseline entity configuration used for world bootstrap and resets."""

    entity_type: str
    state: Optional[Dict[str, Any]] = None


@dataclass
class WorldState:
    """In-memory world state container (Phase 5.0 + Phase 6.0).
    
    Phase 6 adds:
    - mode: Current world mode (sandbox, scenario_active, scenario_complete)
    - active_scenario_id: ID of currently active scenario (if any)
    """

    schema_version: str
    boot_id: str
    baseline_entities: Dict[EntityID, EntityConfig]
    entities: Dict[EntityID, Entity]
    rules_version: str
    mode: str = "sandbox"  # Phase 6: sandbox | scenario_active | scenario_complete
    active_scenario_id: Optional[str] = None  # Phase 6: active scenario ID

    def reset_to_baseline(self) -> None:
        """Reset current entities to the baseline loadout (in-place)."""
        self.entities = {}
        for entity_id, cfg in self.baseline_entities.items():
            state = normalize_entity_state(cfg.entity_type, cfg.state)
            entity = Entity(entity_id=entity_id, entity_type=cfg.entity_type, state=state)
            # Validate to enforce schema + bounds
            validate_entity(entity)
            self.entities[entity_id] = entity

    def to_dict(self) -> Dict[str, Any]:
        """Stable, JSON-serializable representation with deterministic key order."""

        entities_dict: Dict[str, Any] = {}
        for entity_id in sorted(self.entities.keys()):
            e = self.entities[entity_id]
            entities_dict[entity_id] = {
                "entity_id": e.entity_id,
                "entity_type": e.entity_type,
                "state": _stable_state_dict(e.state),
            }

        return {
            "schema_version": self.schema_version,
            "boot_id": self.boot_id,
            "rules_version": self.rules_version,
            "mode": self.mode,  # Phase 6
            "active_scenario_id": self.active_scenario_id,  # Phase 6
            "entities": entities_dict,
        }


def _stable_state_dict(state: Dict[str, Any]) -> Dict[str, Any]:
    """Return a deterministically ordered dict for nested state."""

    out: Dict[str, Any] = {}
    for k in sorted(state.keys()):
        v = state[k]
        if isinstance(v, dict):
            out[k] = _stable_state_dict(v)
        elif isinstance(v, list):
            # Lists keep order; items are primitives in Phase 5.0
            out[k] = list(v)
        else:
            out[k] = v
    return out


"""engine.learning.schema

Phase 8: Audit and schema types for learning.

LearningRecords are immutable artifacts (not commands, not events).
They are used for:
- Audit logs
- Preview explanations
- Replay validation (future)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional, TypedDict


LearningStatus = Literal["accepted", "rejected"]


@dataclass(frozen=True)
class ParameterDelta:
    name: str
    old: Any
    new: Any


@dataclass(frozen=True)
class LearningRecord:
    parameters_version: str
    learning_rule_id: str
    affected_parameters: List[ParameterDelta]
    triggering_events: List[Dict[str, Any]]
    correlation_ids: List[str]
    aggregation_window: Dict[str, Any]
    explanation: str
    status: LearningStatus


@dataclass(frozen=True)
class LearningCycleResult:
    """Result of a single learning cycle (at most once per execution)."""
    status: LearningStatus
    dry_run: bool
    records: List[LearningRecord]

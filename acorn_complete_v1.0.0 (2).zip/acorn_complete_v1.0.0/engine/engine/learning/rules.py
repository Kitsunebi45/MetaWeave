
"""engine.learning.rules

Phase 8: Finite set of deterministic learning rules.

Constraints:
- Static registry (no dynamic registration)
- Single-writer per parameter (enforced at boot)
- Deterministic (no randomness, no time dependency)
- Bounded updates only
- Qualified events only (no wildcards)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

from ..parameters import ParameterDef, ParameterSet, ParamValue
from .schema import LearningRecord, ParameterDelta


@dataclass(frozen=True)
class LearningRuleSpec:
    learning_rule_id: str
    observed_event_types: List[str]
    affected_parameters: List[str]
    aggregation_window: Dict[str, Any]  # {"type":"single_execution"} or {"type":"fixed_count","count":N}
    min_delta: Optional[float]
    explanation_template: str
    max_consecutive_rejections: Optional[int] = None

    def validate_static(self) -> None:
        if not self.learning_rule_id:
            raise ValueError("learning_rule_id cannot be empty")
        if not self.observed_event_types:
            raise ValueError(f"{self.learning_rule_id}: observed_event_types cannot be empty")
        if not self.affected_parameters:
            raise ValueError(f"{self.learning_rule_id}: affected_parameters cannot be empty")
        if "type" not in self.aggregation_window:
            raise ValueError(f"{self.learning_rule_id}: aggregation_window must declare type")


# ---- Concrete rule implementations (pure, deterministic) ----

def lr_counter_threshold_nudge(events: Sequence[Dict[str, Any]], params: ParameterSet) -> Dict[str, ParamValue]:
    """Adjust counter_threshold based on whether threshold events occurred.

    Observed event types:
      - COUNTER_THRESHOLD_EXCEEDED
      - COUNTER_THRESHOLD_CROSSED

    Behavior (deterministic, bounded elsewhere):
      - If any observed event occurs in this execution: threshold += 1
      - Else if threshold > default: threshold -= 1
      - Else: no change

    This is intentionally conservative and non-agentic: it only shifts a numeric threshold.
    """
    current = int(params.values["counter_threshold"])
    default = 3
    saw = any(e.get("type") in ("COUNTER_THRESHOLD_EXCEEDED", "COUNTER_THRESHOLD_CROSSED") for e in events)

    new_val = current
    if saw:
        new_val = current + 1
    elif current > default:
        new_val = current - 1

    return {"counter_threshold": new_val}


LEARNING_RULES: Dict[str, Dict[str, Any]] = {
    # Registry item includes static spec plus apply function reference
    "lr_counter_threshold_nudge": {
        "spec": LearningRuleSpec(
            learning_rule_id="lr_counter_threshold_nudge",
            observed_event_types=["COUNTER_THRESHOLD_EXCEEDED", "COUNTER_THRESHOLD_CROSSED"],
            affected_parameters=["counter_threshold"],
            aggregation_window={"type": "single_execution"},
            min_delta=1.0,
            explanation_template="Adjusted counter_threshold because {reason}.",
            max_consecutive_rejections=None,
        ),
        "apply": lr_counter_threshold_nudge,
    }
}

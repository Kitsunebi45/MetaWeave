
"""engine.learning.observer

Phase 8: LearningObserver orchestrates a single, post-execution learning cycle.

Constraints enforced:
- Runs only after execution completes (caller responsibility)
- One cycle per execution (no cascade)
- Qualified events only (per rule spec)
- Single-writer per parameter (validated at init)
- Atomic updates: all-or-nothing per cycle
- Dry-run mode when disabled (records still produced)
- Failure -> rejected, no update applied
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

from ..parameters import ParameterStore, ParameterSet, ParamValue
from .schema import LearningCycleResult, LearningRecord, ParameterDelta
from .rules import LEARNING_RULES, LearningRuleSpec


class LearningObserver:
    def __init__(self, parameter_store: ParameterStore):
        self._store = parameter_store
        self._disabled_learning_rule_ids: set[str] = set()
        self._consecutive_rejections: Dict[str, int] = {}

        # Validate static registry + single-writer constraint
        self._validate_registry()

    def _validate_registry(self) -> None:
        seen: Dict[str, str] = {}
        for rule_id, item in LEARNING_RULES.items():
            spec: LearningRuleSpec = item["spec"]
            spec.validate_static()
            for p in spec.affected_parameters:
                if p in seen and seen[p] != rule_id:
                    raise ValueError(f"Single-writer violation: parameter '{p}' is modified by both '{seen[p]}' and '{rule_id}'")
                seen[p] = rule_id

    def run_cycle(
        self,
        *,
        events: Sequence[Dict[str, Any]],
        correlation_id: str,
        dry_run: bool,
    ) -> Tuple[LearningCycleResult, Optional[ParameterSet]]:
        """Run one learning cycle. Returns (cycle_result, new_param_set_if_applied)."""
        current = self._store.snapshot()
        records: List[LearningRecord] = []

        # Evaluate each learning rule in deterministic order
        candidate_values = dict(current.values)

        # if learning rules are auto-disabled due to rejections, skip them but still deterministic
        for rule_id in sorted(LEARNING_RULES.keys()):
            if rule_id in self._disabled_learning_rule_ids:
                continue

            spec: LearningRuleSpec = LEARNING_RULES[rule_id]["spec"]
            apply_fn = LEARNING_RULES[rule_id]["apply"]

            # Qualification filter (R14)
            qualified = [e for e in events if e.get("type") in set(spec.observed_event_types)]

            try:
                # Apply function must only return updates for declared parameters
                updates = apply_fn(qualified, ParameterSet(parameters_version=current.parameters_version, values=dict(candidate_values)))

                # Ensure declared-only (R13)
                for k in updates.keys():
                    if k not in spec.affected_parameters:
                        raise ValueError(f"Learning rule '{rule_id}' touched undeclared parameter '{k}'")

                # Build deltas + min_delta filtering (R5)
                deltas: List[ParameterDelta] = []
                for pname in spec.affected_parameters:
                    old = candidate_values[pname]
                    new = updates.get(pname, old)

                    # normalize numeric types for comparison
                    if isinstance(old, (int, float)) and isinstance(new, (int, float)) and spec.min_delta is not None:
                        if abs(float(new) - float(old)) < float(spec.min_delta):
                            new = old

                    deltas.append(ParameterDelta(name=pname, old=old, new=new))

                # Apply to candidate_values (still subject to atomic validation later)
                for d in deltas:
                    candidate_values[d.name] = d.new

                reason = "observed qualified events" if qualified else "no qualified events"
                explanation = spec.explanation_template.format(reason=reason)

                records.append(
                    LearningRecord(
                        parameters_version=current.parameters_version,
                        learning_rule_id=spec.learning_rule_id,
                        affected_parameters=deltas,
                        triggering_events=list(qualified),
                        correlation_ids=[correlation_id],
                        aggregation_window=dict(spec.aggregation_window),
                        explanation=explanation,
                        status="accepted",
                    )
                )

                # reset rejection counter on success
                self._consecutive_rejections[rule_id] = 0

            except Exception as e:
                # Record rejection, abort entire cycle (R9)
                rej_count = self._consecutive_rejections.get(rule_id, 0) + 1
                self._consecutive_rejections[rule_id] = rej_count

                explanation = f"Rejected learning cycle due to error: {e}"
                records.append(
                    LearningRecord(
                        parameters_version=current.parameters_version,
                        learning_rule_id=rule_id,
                        affected_parameters=[],
                        triggering_events=[],
                        correlation_ids=[correlation_id],
                        aggregation_window={"type": "single_execution"},
                        explanation=explanation,
                        status="rejected",
                    )
                )

                # Optional auto-disable on repeated rejections (R18)
                max_rej = LEARNING_RULES[rule_id]["spec"].max_consecutive_rejections
                if max_rej is not None and rej_count >= max_rej:
                    self._disabled_learning_rule_ids.add(rule_id)

                return LearningCycleResult(status="rejected", dry_run=True, records=records), None

        # Atomic validation + (optional) commit
        try:
            # bounds validation via store commit validation path
            # Build full new set
            if dry_run:
                # do not commit; still validate candidate (reject if invalid)
                self._store._validate_full_set(candidate_values)  # type: ignore[attr-defined]
                return LearningCycleResult(status="accepted", dry_run=True, records=records), None

            self._store.commit(candidate_values)
            return LearningCycleResult(status="accepted", dry_run=False, records=records), self._store.snapshot()

        except Exception as e:
            # Reject entire cycle (R9)
            records.append(
                LearningRecord(
                    parameters_version=current.parameters_version,
                    learning_rule_id="learning_cycle",
                    affected_parameters=[],
                    triggering_events=[],
                    correlation_ids=[correlation_id],
                    aggregation_window={"type": "single_execution"},
                    explanation=f"Rejected learning cycle due to validation error: {e}",
                    status="rejected",
                )
            )
            return LearningCycleResult(status="rejected", dry_run=True, records=records), None

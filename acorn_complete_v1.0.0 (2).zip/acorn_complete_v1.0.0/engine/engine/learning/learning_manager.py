"""Phase 15 Learning Manager — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module implements Phase 15 bounded learning & teaching.                ║
║  Learning modifies RUNTIME STATE ONLY — plates remain immutable.             ║
║                                                                              ║
║  Key invariants:                                                             ║
║  - Learning lives in state.learning (Phase 14 saves)                         ║
║  - Plates define the classroom, saves record the student                     ║
║  - Teaching is EXTERNAL INPUT ONLY                                           ║
║  - All updates are pure functions (deterministic)                            ║
║  - Skills are bounded by envelopes (clamp, not fail)                         ║
║  - History is capped at 100 entries (FIFO eviction)                          ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Set
from copy import deepcopy
import json


# =============================================================================
# CONSTANTS
# =============================================================================

LEARNING_VERSION = "1.0"
HISTORY_MAX_LENGTH = 100  # LOCKED: Not configurable in v1.0


# =============================================================================
# ERROR CLASSES
# =============================================================================

@dataclass(frozen=True)
class LearningError:
    """Structured learning error."""
    error_class: str
    entity_id: Optional[str]
    field_path: Optional[str]
    message: str
    
    def to_json(self) -> str:
        return json.dumps(asdict(self), separators=(',', ':'))


class LearningValidationError(Exception):
    """Base exception for learning validation failures."""
    
    def __init__(self, error: LearningError):
        self.error = error
        super().__init__(error.message)


class LearningSchemaError(LearningValidationError):
    """Learning state schema validation failure."""
    pass


class LearningTeachingError(LearningValidationError):
    """Teaching event validation failure."""
    pass


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class SkillEnvelope:
    """Defines bounds for a skill value.
    
    All skill updates are clamped to [min, max].
    delta_per_event is the standard change per teaching event.
    """
    min: float
    max: float
    delta_per_event: float
    
    def clamp(self, value: float) -> float:
        """Clamp value to envelope bounds."""
        return max(self.min, min(self.max, value))
    
    def to_dict(self) -> Dict[str, float]:
        return {
            "min": self.min,
            "max": self.max,
            "delta_per_event": self.delta_per_event
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SkillEnvelope':
        return cls(
            min=float(data["min"]),
            max=float(data["max"]),
            delta_per_event=float(data["delta_per_event"])
        )


@dataclass
class HistoryEntry:
    """Single learning history entry."""
    tick: int
    event: str
    data: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        result = {"tick": self.tick, "event": self.event}
        if self.data:
            result.update(self.data)
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'HistoryEntry':
        tick = data["tick"]
        event = data["event"]
        extra = {k: v for k, v in data.items() if k not in ("tick", "event")}
        return cls(tick=tick, event=event, data=extra)


@dataclass
class EntityLearning:
    """Learning state for a single entity.
    
    Contains:
    - skills: Numeric values (bounded by envelopes)
    - metrics: Counters and tracking values
    - history: Append-only log (max 100 entries, FIFO eviction)
    """
    skills: Dict[str, float] = field(default_factory=dict)
    metrics: Dict[str, float] = field(default_factory=dict)
    history: List[HistoryEntry] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "skills": dict(self.skills),
            "metrics": dict(self.metrics),
            "history": [h.to_dict() for h in self.history]
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'EntityLearning':
        return cls(
            skills=dict(data.get("skills", {})),
            metrics=dict(data.get("metrics", {})),
            history=[HistoryEntry.from_dict(h) for h in data.get("history", [])]
        )
    
    def append_history(self, entry: HistoryEntry) -> None:
        """Append history entry with FIFO eviction."""
        self.history.append(entry)
        # Enforce max length (FIFO eviction)
        while len(self.history) > HISTORY_MAX_LENGTH:
            self.history.pop(0)


@dataclass
class LearningState:
    """Complete learning state for all entities.
    
    Lives entirely in runtime state (Phase 14 saves).
    MUST NOT reference plates or rules.
    """
    version: str = LEARNING_VERSION
    entities: Dict[str, EntityLearning] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "entities": {eid: el.to_dict() for eid, el in self.entities.items()}
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LearningState':
        return cls(
            version=data.get("version", LEARNING_VERSION),
            entities={
                eid: EntityLearning.from_dict(edata)
                for eid, edata in data.get("entities", {}).items()
            }
        )
    
    def get_entity(self, entity_id: str) -> EntityLearning:
        """Get or create entity learning state."""
        if entity_id not in self.entities:
            self.entities[entity_id] = EntityLearning()
        return self.entities[entity_id]


# =============================================================================
# TEACHING EVENTS
# =============================================================================

@dataclass(frozen=True)
class TeachingEvent:
    """Base teaching event.
    
    Teaching is EXTERNAL INPUT ONLY.
    Valid sources: Scenario scripts, Console commands, Test harnesses.
    NEVER from: Learning state, Rules, Engine heuristics.
    """
    event_type: str
    entity_id: str
    tick: int
    
    def validate(self) -> None:
        """Validate event. Override in subclasses."""
        if not self.entity_id:
            raise LearningTeachingError(LearningError(
                error_class="TEACHING_ERROR",
                entity_id=self.entity_id,
                field_path="entity_id",
                message="entity_id is required"
            ))
        if self.tick < 0:
            raise LearningTeachingError(LearningError(
                error_class="TEACHING_ERROR",
                entity_id=self.entity_id,
                field_path="tick",
                message="tick must be non-negative"
            ))


@dataclass(frozen=True)
class SkillUpdateEvent(TeachingEvent):
    """Update a skill value."""
    skill: str
    delta: float
    
    def __init__(self, entity_id: str, tick: int, skill: str, delta: float):
        object.__setattr__(self, 'event_type', 'skill_update')
        object.__setattr__(self, 'entity_id', entity_id)
        object.__setattr__(self, 'tick', tick)
        object.__setattr__(self, 'skill', skill)
        object.__setattr__(self, 'delta', delta)
    
    def validate(self) -> None:
        super().validate()
        if not self.skill:
            raise LearningTeachingError(LearningError(
                error_class="TEACHING_ERROR",
                entity_id=self.entity_id,
                field_path="skill",
                message="skill name is required"
            ))


@dataclass(frozen=True)
class MetricIncrementEvent(TeachingEvent):
    """Increment a metric counter."""
    metric: str
    amount: float
    
    def __init__(self, entity_id: str, tick: int, metric: str, amount: float = 1.0):
        object.__setattr__(self, 'event_type', 'metric_increment')
        object.__setattr__(self, 'entity_id', entity_id)
        object.__setattr__(self, 'tick', tick)
        object.__setattr__(self, 'metric', metric)
        object.__setattr__(self, 'amount', amount)
    
    def validate(self) -> None:
        super().validate()
        if not self.metric:
            raise LearningTeachingError(LearningError(
                error_class="TEACHING_ERROR",
                entity_id=self.entity_id,
                field_path="metric",
                message="metric name is required"
            ))


@dataclass(frozen=True)
class HistoryAppendEvent(TeachingEvent):
    """Append to learning history."""
    event_name: str
    data: Dict[str, Any] = field(default_factory=dict)
    
    def __init__(self, entity_id: str, tick: int, event_name: str, data: Optional[Dict[str, Any]] = None):
        object.__setattr__(self, 'event_type', 'history_append')
        object.__setattr__(self, 'entity_id', entity_id)
        object.__setattr__(self, 'tick', tick)
        object.__setattr__(self, 'event_name', event_name)
        object.__setattr__(self, 'data', data or {})
    
    def validate(self) -> None:
        super().validate()
        if not self.event_name:
            raise LearningTeachingError(LearningError(
                error_class="TEACHING_ERROR",
                entity_id=self.entity_id,
                field_path="event_name",
                message="event_name is required"
            ))


# =============================================================================
# LEARNING MANAGER
# =============================================================================

class LearningManager:
    """Manages bounded learning state.
    
    Responsibilities:
    - Validate learning state
    - Apply teaching events (pure functions)
    - Enforce skill envelopes (clamp, not fail)
    - Provide read-only access to learning data
    
    Invariants:
    - Learning state lives ONLY in runtime state
    - All updates are deterministic
    - Plates and rules are NEVER referenced or modified
    """
    
    def __init__(self, skill_envelopes: Optional[Dict[str, SkillEnvelope]] = None):
        """Initialize learning manager.
        
        Args:
            skill_envelopes: Optional skill bounds. If not provided,
                           skills are unbounded (no clamping).
        """
        self._envelopes = skill_envelopes or {}
        self._state = LearningState()
    
    @property
    def state(self) -> LearningState:
        """Get current learning state (read-only access)."""
        return self._state
    
    def set_state(self, state: LearningState) -> None:
        """Set learning state (for loading from save)."""
        self._state = state
    
    def get_state_dict(self) -> Dict[str, Any]:
        """Get learning state as dictionary (for saving)."""
        return self._state.to_dict()
    
    def load_state_dict(self, data: Dict[str, Any]) -> None:
        """Load learning state from dictionary (from save)."""
        self._state = LearningState.from_dict(data)
    
    def register_envelope(self, skill: str, envelope: SkillEnvelope) -> None:
        """Register a skill envelope."""
        self._envelopes[skill] = envelope
    
    def get_envelope(self, skill: str) -> Optional[SkillEnvelope]:
        """Get envelope for a skill."""
        return self._envelopes.get(skill)
    
    def get_entity_learning(self, entity_id: str) -> EntityLearning:
        """Get learning state for an entity (creates if not exists)."""
        return self._state.get_entity(entity_id)
    
    def get_skill(self, entity_id: str, skill: str) -> float:
        """Get skill value for an entity (0.0 if not set)."""
        entity = self._state.entities.get(entity_id)
        if entity is None:
            return 0.0
        return entity.skills.get(skill, 0.0)
    
    def get_metric(self, entity_id: str, metric: str) -> float:
        """Get metric value for an entity (0.0 if not set)."""
        entity = self._state.entities.get(entity_id)
        if entity is None:
            return 0.0
        return entity.metrics.get(metric, 0.0)
    
    def get_history(self, entity_id: str) -> List[HistoryEntry]:
        """Get learning history for an entity (empty list if not exists)."""
        entity = self._state.entities.get(entity_id)
        if entity is None:
            return []
        return list(entity.history)
    
    # =========================================================================
    # TEACHING API
    # =========================================================================
    
    def apply_teaching_event(self, event: TeachingEvent) -> None:
        """Apply a teaching event to learning state.
        
        This is the core teaching API. All updates are:
        - Validated before application
        - Deterministic (pure function of old state + event)
        - Bounded by envelopes (clamping, not failure)
        
        Args:
            event: Teaching event to apply
            
        Raises:
            LearningTeachingError: If event validation fails
        """
        # Validate event
        event.validate()
        
        # Dispatch by type
        if isinstance(event, SkillUpdateEvent):
            self._apply_skill_update(event)
        elif isinstance(event, MetricIncrementEvent):
            self._apply_metric_increment(event)
        elif isinstance(event, HistoryAppendEvent):
            self._apply_history_append(event)
        else:
            raise LearningTeachingError(LearningError(
                error_class="TEACHING_ERROR",
                entity_id=event.entity_id,
                field_path="event_type",
                message=f"Unknown event type: {event.event_type}"
            ))
    
    def _apply_skill_update(self, event: SkillUpdateEvent) -> None:
        """Apply skill update with envelope clamping."""
        entity = self._state.get_entity(event.entity_id)
        
        # Get current value
        current = entity.skills.get(event.skill, 0.0)
        
        # Apply delta
        new_value = current + event.delta
        
        # Clamp to envelope if defined
        envelope = self._envelopes.get(event.skill)
        if envelope is not None:
            new_value = envelope.clamp(new_value)
        
        # Update skill
        entity.skills[event.skill] = new_value
    
    def _apply_metric_increment(self, event: MetricIncrementEvent) -> None:
        """Apply metric increment."""
        entity = self._state.get_entity(event.entity_id)
        
        # Get current value
        current = entity.metrics.get(event.metric, 0.0)
        
        # Apply increment
        entity.metrics[event.metric] = current + event.amount
    
    def _apply_history_append(self, event: HistoryAppendEvent) -> None:
        """Append to history with FIFO eviction."""
        entity = self._state.get_entity(event.entity_id)
        
        # Create history entry
        entry = HistoryEntry(
            tick=event.tick,
            event=event.event_name,
            data=dict(event.data)
        )
        
        # Append with eviction
        entity.append_history(entry)
    
    # =========================================================================
    # BATCH OPERATIONS
    # =========================================================================
    
    def apply_teaching_events(self, events: List[TeachingEvent]) -> None:
        """Apply multiple teaching events in order.
        
        Events are applied atomically - if any event fails validation,
        no events are applied.
        
        Args:
            events: List of teaching events
            
        Raises:
            LearningTeachingError: If any event validation fails
        """
        # Validate all events first
        for event in events:
            event.validate()
        
        # Apply all events
        for event in events:
            self.apply_teaching_event(event)
    
    def reset_entity(self, entity_id: str) -> None:
        """Reset learning state for an entity."""
        if entity_id in self._state.entities:
            self._state.entities[entity_id] = EntityLearning()
    
    def reset_all(self) -> None:
        """Reset all learning state."""
        self._state = LearningState()


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def create_learning_state() -> LearningState:
    """Create empty learning state."""
    return LearningState()


def create_skill_envelope(
    min_value: float = 0.0,
    max_value: float = 1.0,
    delta_per_event: float = 0.1
) -> SkillEnvelope:
    """Create a skill envelope with default bounds."""
    return SkillEnvelope(
        min=min_value,
        max=max_value,
        delta_per_event=delta_per_event
    )


def create_default_envelopes() -> Dict[str, SkillEnvelope]:
    """Create default envelopes for common skills."""
    return {
        "navigation": SkillEnvelope(min=0.0, max=1.0, delta_per_event=0.05),
        "coordination": SkillEnvelope(min=0.0, max=1.0, delta_per_event=0.05),
        "perception": SkillEnvelope(min=0.0, max=1.0, delta_per_event=0.05),
        "memory": SkillEnvelope(min=0.0, max=1.0, delta_per_event=0.05),
    }

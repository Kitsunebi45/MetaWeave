"""Phase 15 Learning Module — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module implements Phase 15 bounded learning & teaching.                ║
║                                                                              ║
║  Core Principle:                                                             ║
║  "Learning modifies runtime state only.                                      ║
║   Plates define the classroom. Saves record the student."                    ║
║                                                                              ║
║  Learning is:                                                                ║
║  - Reversible (via save/load)                                                ║
║  - Inspectable (JSON state)                                                  ║
║  - Resettable (reset_entity / reset_all)                                     ║
║  - Bounded (skill envelopes)                                                 ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-24                                                          ║
╚══════════════════════════════════════════════════════════════════════════════╝

Usage:
    from engine.learning import (
        LearningManager,
        SkillUpdateEvent,
        MetricIncrementEvent,
        HistoryAppendEvent,
        create_skill_envelope
    )
    
    # Create manager with skill envelopes
    manager = LearningManager()
    manager.register_envelope("navigation", create_skill_envelope(
        min_value=0.0,
        max_value=1.0,
        delta_per_event=0.05
    ))
    
    # Apply teaching event
    event = SkillUpdateEvent(
        entity_id="e1",
        tick=1000,
        skill="navigation",
        delta=0.05
    )
    manager.apply_teaching_event(event)
    
    # Check skill value
    skill_value = manager.get_skill("e1", "navigation")
    
    # Save learning state (integrate with Phase 14)
    state_dict = manager.get_state_dict()
    # Include in save bundle: state["learning"] = state_dict
    
    # Load learning state
    manager.load_state_dict(state_dict)
"""

from .learning_manager import (
    # Manager
    LearningManager,
    
    # State classes
    LearningState,
    EntityLearning,
    HistoryEntry,
    SkillEnvelope,
    
    # Teaching events
    TeachingEvent,
    SkillUpdateEvent,
    MetricIncrementEvent,
    HistoryAppendEvent,
    
    # Errors
    LearningError,
    LearningValidationError,
    LearningSchemaError,
    LearningTeachingError,
    
    # Convenience functions
    create_learning_state,
    create_skill_envelope,
    create_default_envelopes,
    
    # Constants
    LEARNING_VERSION,
    HISTORY_MAX_LENGTH
)

__all__ = [
    # Manager
    'LearningManager',
    
    # State classes
    'LearningState',
    'EntityLearning',
    'HistoryEntry',
    'SkillEnvelope',
    
    # Teaching events
    'TeachingEvent',
    'SkillUpdateEvent',
    'MetricIncrementEvent',
    'HistoryAppendEvent',
    
    # Errors
    'LearningError',
    'LearningValidationError',
    'LearningSchemaError',
    'LearningTeachingError',
    
    # Convenience functions
    'create_learning_state',
    'create_skill_envelope',
    'create_default_envelopes',
    
    # Constants
    'LEARNING_VERSION',
    'HISTORY_MAX_LENGTH'
]

__version__ = "15.0.0"

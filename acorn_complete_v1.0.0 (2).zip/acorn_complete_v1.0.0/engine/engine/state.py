"""
StateContainer - Explicit, bounded, resettable in-memory state for Phase 4.
Phase 4 introduces a Finite State Machine (FSM) with deterministic state transitions.
"""

import uuid
from dataclasses import dataclass, field
from typing import List, Dict, Any
from collections import deque


@dataclass
class StateContainer:
    """
    In-memory state container for Phase 4 engine.
    
    Rules:
        - RAM only (no persistence)
        - Resettable to defaults
        - No clock/randomness dependency
        - Changes only via approved commands
    
    Attributes:
        schema_version: Protocol version ("4.0")
        boot_id: Unique ID generated at engine init (not persisted)
        counter: Simple integer counter for deterministic state transitions
        history: Last N command summaries (bounded, default N=20)
    """
    schema_version: str = "4.0"
    boot_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    counter: int = 0
    history: deque = field(default_factory=lambda: deque(maxlen=20))
    
    def reset(self) -> 'StateContainer':
        """
        Reset state to defaults.
        
        Returns:
            New StateContainer with default values (same boot_id)
        """
        return StateContainer(
            schema_version=self.schema_version,
            boot_id=self.boot_id,  # Preserve boot_id across resets
            counter=0,
            history=deque(maxlen=20)
        )
    
    def add_to_history(self, command: str, result: str) -> None:
        """
        Add command summary to history.
        
        Args:
            command: Command that was executed
            result: Brief result summary
        """
        self.history.append({
            "command": command,
            "result": result
        })
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert state to dictionary for inspection.
        
        Returns:
            Dict representation of state
        """
        return {
            "schema_version": self.schema_version,
            "boot_id": self.boot_id,
            "counter": self.counter,
            "history_count": len(self.history),
            "history": list(self.history)
        }

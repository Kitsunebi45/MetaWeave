"""
StatefulEngine - Phase 4 FSM engine with command registry and deterministic state transitions.
Replaces NoOpEngine with a proper command vocabulary and bounded state model.
"""

from typing import Dict, Any, Callable, Tuple, List, Optional
from console.schema import Packet, ExecutionContext, ExecutionResult
from .base import BaseEngine, UnknownPacketType
from .state import StateContainer


class StatefulEngine(BaseEngine):
    """
    Phase 4 Finite State Machine engine.
    
    Features:
        - 7 enumerated commands (help, state.get, state.reset, counter.*, echo)
        - StateContainer (in-memory, resettable)
        - Pure state transitions: (state, args) → (new_state, output, events)
        - Deterministic (no randomness, no wall-clock time)
    
    Architecture:
        - Command Registry maps command → handler
        - All handlers are pure functions
        - State changes only through approved commands
        - Executor (Phase 3) still catches all exceptions
    """
    
    def __init__(self):
        """Initialize engine with default state and command registry."""
        self._state = StateContainer()
        self._registry = self._build_command_registry()
    
    def execute(
        self,
        packet: Packet,
        context: ExecutionContext
    ) -> ExecutionResult:
        """
        Execute packet with FSM state transitions.
        
        Args:
            packet: Validated packet
            context: Ephemeral execution context
            
        Returns:
            ExecutionResult with status, output, and optional error
            
        Raises:
            UnknownPacketType: If packet type is not "command"
        """
        # Only handle "command" packet type
        if packet.packet_type != "command":
            raise UnknownPacketType(
                f"StatefulEngine only handles 'command' packets, got '{packet.packet_type}'"
            )
        
        # Extract command from payload
        if "command" not in packet.payload:
            return ExecutionResult(
                status="error",
                packet_id=packet.metadata.packet_id,
                output=None,
                error={
                    "code": "INVALID_COMMAND_PACKET",
                    "message": "Missing 'command' field in payload"
                }
            )
        
        command = packet.payload["command"]
        args = packet.payload.get("args", {})
        
        # Look up command in registry
        if command not in self._registry:
            return ExecutionResult(
                status="error",
                packet_id=packet.metadata.packet_id,
                output=None,
                error={
                    "code": "UNKNOWN_COMMAND",
                    "command": command,
                    "message": f"Unknown command '{command}'. Use 'help' to list available commands."
                }
            )
        
        # Get handler from registry
        handler_info = self._registry[command]
        handler = handler_info["handler"]
        
        # Execute handler (pure function)
        try:
            output = handler(self._state, args, context)
            
            # Add to history
            result_summary = str(output)[:50]  # First 50 chars
            self._state.add_to_history(command, result_summary)
            
            return ExecutionResult(
                status="success",
                packet_id=packet.metadata.packet_id,
                output=output,
                error=None
            )
            
        except ValueError as e:
            # Args validation error
            return ExecutionResult(
                status="error",
                packet_id=packet.metadata.packet_id,
                output=None,
                error={
                    "code": "INVALID_ARGS",
                    "command": command,
                    "message": str(e)
                }
            )
    
    def _build_command_registry(self) -> Dict[str, Dict[str, Any]]:
        """
        Build static command registry.
        
        Returns:
            Registry mapping command name → {handler, help_text, args_schema}
        """
        return {
            "help": {
                "handler": self._cmd_help,
                "help_text": "List available commands",
                "args_schema": {}
            },
            "state.get": {
                "handler": self._cmd_state_get,
                "help_text": "Get current state",
                "args_schema": {}
            },
            "state.reset": {
                "handler": self._cmd_state_reset,
                "help_text": "Reset state to defaults",
                "args_schema": {}
            },
            "counter.inc": {
                "handler": self._cmd_counter_inc,
                "help_text": "Increment counter by 1",
                "args_schema": {}
            },
            "counter.dec": {
                "handler": self._cmd_counter_dec,
                "help_text": "Decrement counter by 1",
                "args_schema": {}
            },
            "counter.set": {
                "handler": self._cmd_counter_set,
                "help_text": "Set counter to exact value",
                "args_schema": {"value": "int"}
            },
            "echo": {
                "handler": self._cmd_echo,
                "help_text": "Echo back the message",
                "args_schema": {"message": "str"}
            }
        }
    
    # Command Handlers (Pure Functions)
    
    def _cmd_help(
        self,
        state: StateContainer,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> str:
        """
        List available commands.
        
        Returns:
            Help text listing all commands
        """
        lines = ["Available commands:"]
        for cmd_name in sorted(self._registry.keys()):
            cmd_info = self._registry[cmd_name]
            lines.append(f"  {cmd_name:15s} - {cmd_info['help_text']}")
        return "\n".join(lines)
    
    def _cmd_state_get(
        self,
        state: StateContainer,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> Dict[str, Any]:
        """
        Get current state.
        
        Returns:
            State as dictionary
        """
        return state.to_dict()
    
    def _cmd_state_reset(
        self,
        state: StateContainer,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> str:
        """
        Reset state to defaults.
        
        Returns:
            Confirmation message
        """
        # Replace state with default
        self._state = state.reset()
        return f"State reset to defaults (boot_id: {self._state.boot_id})"
    
    def _cmd_counter_inc(
        self,
        state: StateContainer,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> str:
        """
        Increment counter by 1.
        
        Returns:
            New counter value
        """
        state.counter += 1
        return f"Counter: {state.counter}"
    
    def _cmd_counter_dec(
        self,
        state: StateContainer,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> str:
        """
        Decrement counter by 1.
        
        Returns:
            New counter value
        """
        state.counter -= 1
        return f"Counter: {state.counter}"
    
    def _cmd_counter_set(
        self,
        state: StateContainer,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> str:
        """
        Set counter to exact value.
        
        Args:
            args["value"]: Integer value to set
            
        Returns:
            New counter value
            
        Raises:
            ValueError: If value is not an integer
        """
        if "value" not in args:
            raise ValueError("Missing required argument 'value'")
        
        value = args["value"]
        if not isinstance(value, int):
            raise ValueError(f"Argument 'value' must be int, got {type(value).__name__}")
        
        state.counter = value
        return f"Counter set to: {state.counter}"
    
    def _cmd_echo(
        self,
        state: StateContainer,
        args: Dict[str, Any],
        context: ExecutionContext
    ) -> str:
        """
        Echo back the message.
        
        Args:
            args["message"]: Message to echo
            
        Returns:
            Echoed message
            
        Raises:
            ValueError: If message is not a string
        """
        if "message" not in args:
            raise ValueError("Missing required argument 'message'")
        
        message = args["message"]
        if not isinstance(message, str):
            raise ValueError(f"Argument 'message' must be str, got {type(message).__name__}")
        
        return f"Echo: {message}"

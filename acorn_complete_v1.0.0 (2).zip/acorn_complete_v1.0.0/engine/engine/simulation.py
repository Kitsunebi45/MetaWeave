"""Acorn Engine Demo Simulation.

A simple simulation world for the Fairy Garden demo.
Handles mode transitions, tick advancement, and state broadcasting.

This is the "go switch" that transitions from observer to active mode.
"""

import threading
import time
import random
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class Entity:
    """A simulated entity (fairy, goblin, etc.)."""
    id: str
    name: str
    entity_type: str
    room: str
    state: str = "idle"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "type": self.entity_type,
            "room": self.room,
            "state": self.state
        }


@dataclass
class Room:
    """A room in the world."""
    id: str
    name: str
    connections: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "connections": self.connections
        }


class SimulationWorld:
    """The simulation world.
    
    Modes:
    - observer: World is initialized but not advancing
    - active: World is ticking, entities are moving
    - paused: World was active but is now paused
    
    Avatar:
    - When avatar mode is active, player controls an entity
    - Movement and speech route through avatar entity
    """
    
    def __init__(self):
        self.mode = "observer"
        self.tick = 0
        self.tick_rate = 1.0  # seconds per tick
        
        # World state
        self.rooms: Dict[str, Room] = {}
        self.entities: Dict[str, Entity] = {}
        self.loaded_origin: str = ""
        
        # Avatar state - persistent player entity
        self.avatar_id: Optional[str] = None  # Entity ID of player avatar
        self.avatar_active: bool = False      # Is avatar mode on?
        
        # Tick thread
        self._tick_thread: Optional[threading.Thread] = None
        self._running = False
        
        # Callback for state changes
        self.on_state_change: Optional[Callable[[Dict[str, Any]], None]] = None
        self.on_event: Optional[Callable[[str, Dict[str, Any]], None]] = None
    
    def load_plate_set(self, origin: str, plates: Dict[str, Any] = None) -> None:
        """Load a plate set into the world.
        
        For demo purposes, creates a simple Fairy Garden world.
        """
        self.loaded_origin = origin
        
        if "fairy_garden" in origin.lower():
            self._create_fairy_garden()
        else:
            self._create_generic_world(origin)
        
        self._broadcast_state()
        print(f"[engine] World loaded: {origin}")
    
    def _create_fairy_garden(self) -> None:
        """Create the Fairy Garden demo world."""
        # Create rooms (simplified - 9 room grid)
        room_names = [
            "entrance", "garden_path", "flower_meadow",
            "mushroom_grove", "central_glade", "crystal_pool",
            "hedge_maze", "fairy_court", "ancient_tree"
        ]
        
        # Set up room connections (simple grid)
        connections = {
            0: [1, 3],      # entrance -> garden_path, mushroom_grove
            1: [0, 2, 4],   # garden_path -> entrance, flower_meadow, central_glade
            2: [1, 5],      # flower_meadow -> garden_path, crystal_pool
            3: [0, 4, 6],   # mushroom_grove -> entrance, central_glade, hedge_maze
            4: [1, 3, 5, 7],# central_glade -> garden_path, mushroom_grove, crystal_pool, fairy_court
            5: [2, 4, 8],   # crystal_pool -> flower_meadow, central_glade, ancient_tree
            6: [3, 7],      # hedge_maze -> mushroom_grove, fairy_court
            7: [4, 6, 8],   # fairy_court -> central_glade, hedge_maze, ancient_tree
            8: [5, 7],      # ancient_tree -> crystal_pool, fairy_court
        }
        
        for i, name in enumerate(room_names):
            room_id = f"room_{i}"
            conn_ids = [f"room_{c}" for c in connections.get(i, [])]
            self.rooms[room_id] = Room(
                id=room_id,
                name=name.replace("_", " ").title(),
                connections=conn_ids
            )
        
        # Create player avatar entity (starts at entrance)
        self.avatar_id = "player_avatar"
        self.entities[self.avatar_id] = Entity(
            id=self.avatar_id,
            name="You",
            entity_type="avatar",
            room="room_0",  # Start at entrance
            state="observing"
        )
        
        # Create fairies
        fairy_names = ["Bella", "Luna", "Pip", "Fern", "Dewdrop", "Thistle"]
        for i, name in enumerate(fairy_names):
            entity_id = f"fairy_{i}"
            room_idx = (i % len(room_names))
            # Don't put fairy in entrance (room_0) - that's where player starts
            if room_idx == 0:
                room_idx = 4  # Put them in central glade instead
            self.entities[entity_id] = Entity(
                id=entity_id,
                name=name,
                entity_type="fairy",
                room=f"room_{room_idx}",
                state="idle"
            )
        
        print(f"[engine] Created Fairy Garden: {len(self.rooms)} rooms, {len(self.entities)} fairies")
    
    def _create_generic_world(self, origin: str) -> None:
        """Create a generic demo world."""
        self.rooms["start"] = Room(id="start", name="Starting Room")
        self.entities["player"] = Entity(
            id="player",
            name="Observer",
            entity_type="observer",
            room="start"
        )
    
    def begin(self) -> bool:
        """Begin the simulation (observer → active).
        
        This is THE SWITCH that starts time advancing.
        """
        if self.mode == "active":
            return False  # Already running
        
        self.mode = "active"
        self._running = True
        
        # Start tick thread
        self._tick_thread = threading.Thread(target=self._tick_loop, daemon=True)
        self._tick_thread.start()
        
        print(f"[engine] Simulation STARTED - mode: active")
        self._broadcast_state()
        self._emit_event("simulation_started", {"tick": self.tick})
        
        return True
    
    def pause(self) -> bool:
        """Pause the simulation."""
        if self.mode != "active":
            return False
        
        self.mode = "paused"
        self._running = False
        
        print(f"[engine] Simulation PAUSED at tick {self.tick}")
        self._broadcast_state()
        
        return True
    
    def step(self) -> None:
        """Advance one tick manually (for debugging)."""
        self._do_tick()
        self._broadcast_state()
    
    def _tick_loop(self) -> None:
        """Background tick loop."""
        while self._running and self.mode == "active":
            self._do_tick()
            self._broadcast_state()
            time.sleep(self.tick_rate)
    
    def _do_tick(self) -> None:
        """Execute one simulation tick."""
        self.tick += 1
        
        # Update entities
        for entity in self.entities.values():
            self._update_entity(entity)
        
        print(f"[engine] Tick {self.tick}")
    
    def _update_entity(self, entity: Entity) -> None:
        """Update a single entity for one tick."""
        if entity.entity_type == "fairy":
            # Fairies have simple behavior
            actions = ["idle", "flying", "gathering", "chatting", "resting"]
            old_state = entity.state
            entity.state = random.choice(actions)
            
            # Sometimes move to a new room
            if random.random() < 0.2 and self.rooms:
                old_room = entity.room
                entity.room = random.choice(list(self.rooms.keys()))
                if entity.room != old_room:
                    self._emit_event("entity_moved", {
                        "entity": entity.id,
                        "name": entity.name,
                        "from": old_room,
                        "to": entity.room
                    })
    
    def _broadcast_state(self) -> None:
        """Broadcast current state to consoles."""
        state = self.get_state()
        if self.on_state_change:
            self.on_state_change(state)
    
    def _emit_event(self, event_type: str, data: Dict[str, Any]) -> None:
        """Emit an event to consoles."""
        if self.on_event:
            self.on_event(event_type, data)
    
    # =========================================================================
    # AVATAR ACTIONS
    # =========================================================================
    
    def _get_avatar(self) -> Optional[Entity]:
        """Get the player avatar entity."""
        if self.avatar_id and self.avatar_id in self.entities:
            return self.entities[self.avatar_id]
        return None
    
    def _avatar_look(self) -> Dict[str, Any]:
        """Look at the current room."""
        avatar = self._get_avatar()
        if not avatar:
            return {"success": False, "message": "No avatar entity"}
        
        room = self.rooms.get(avatar.room)
        if not room:
            return {"success": False, "message": "Avatar not in a valid room"}
        
        # Find entities in same room
        entities_here = [
            e for e in self.entities.values()
            if e.room == avatar.room and e.id != self.avatar_id
        ]
        
        # Build description
        desc_lines = [
            f"📍 {room.name}",
            "",
        ]
        
        if entities_here:
            desc_lines.append("You see:")
            for e in entities_here:
                emoji = "🧚" if e.entity_type == "fairy" else "👤"
                desc_lines.append(f"  {emoji} {e.name} ({e.state})")
        else:
            desc_lines.append("The room is quiet.")
        
        if room.connections:
            exits = []
            for conn in room.connections:
                if conn in self.rooms:
                    exits.append(self.rooms[conn].name)
            if exits:
                desc_lines.append("")
                desc_lines.append(f"Exits: {', '.join(exits)}")
        
        description = "\n".join(desc_lines)
        
        self._emit_event("room_description", {
            "room": room.id,
            "room_name": room.name,
            "description": description,
            "entities": [e.to_dict() for e in entities_here]
        })
        
        return {
            "success": True,
            "room": room.name,
            "description": description
        }
    
    def _avatar_move(self, direction: str) -> Dict[str, Any]:
        """Move the avatar in a direction."""
        if not self.avatar_active:
            return {"success": False, "message": "Avatar mode not active. Type 'avatar true' first."}
        
        avatar = self._get_avatar()
        if not avatar:
            return {"success": False, "message": "No avatar entity"}
        
        current_room = self.rooms.get(avatar.room)
        if not current_room:
            return {"success": False, "message": "Avatar not in a valid room"}
        
        # Find destination
        direction = direction.lower()
        
        # Simple movement - just go to first connected room for now
        # (In full implementation, directions would map to specific rooms)
        if not current_room.connections:
            return {"success": False, "message": "No exits from this room."}
        
        # Pick a connected room (could be smarter with direction mapping)
        new_room_id = None
        if direction in ("n", "north"):
            # Try to go to a room with index less than current
            for conn in current_room.connections:
                if int(conn.split("_")[1]) < int(avatar.room.split("_")[1]):
                    new_room_id = conn
                    break
        elif direction in ("s", "south"):
            for conn in current_room.connections:
                if int(conn.split("_")[1]) > int(avatar.room.split("_")[1]):
                    new_room_id = conn
                    break
        
        # If no specific direction match, just pick first connection
        if not new_room_id:
            new_room_id = current_room.connections[0]
        
        old_room = avatar.room
        avatar.room = new_room_id
        new_room = self.rooms.get(new_room_id)
        
        print(f"[engine] Avatar moved: {current_room.name} → {new_room.name if new_room else new_room_id}")
        
        self._emit_event("avatar_moved", {
            "from": old_room,
            "from_name": current_room.name,
            "to": new_room_id,
            "to_name": new_room.name if new_room else new_room_id
        })
        
        self._broadcast_state()
        
        # Auto-look at new room
        return self._avatar_look()
    
    def _avatar_say(self, text: str) -> Dict[str, Any]:
        """Say something in the current room."""
        if not self.avatar_active:
            return {"success": False, "message": "Avatar mode not active."}
        
        avatar = self._get_avatar()
        if not avatar:
            return {"success": False, "message": "No avatar entity"}
        
        room = self.rooms.get(avatar.room)
        room_name = room.name if room else "unknown"
        
        print(f"[engine] Avatar says: \"{text}\"")
        
        self._emit_event("avatar_speech", {
            "room": avatar.room,
            "room_name": room_name,
            "text": text
        })
        
        # Maybe fairies respond?
        entities_here = [
            e for e in self.entities.values()
            if e.room == avatar.room and e.entity_type == "fairy"
        ]
        
        if entities_here and text:
            # Random fairy might respond
            fairy = random.choice(entities_here)
            responses = [
                f"*{fairy.name} waves happily*",
                f"*{fairy.name} looks at you curiously*",
                f"*{fairy.name} giggles*",
                f"{fairy.name}: \"Hello, friend!\"",
                f"{fairy.name}: \"Welcome to the garden!\"",
            ]
            response = random.choice(responses)
            self._emit_event("npc_response", {
                "speaker": fairy.name,
                "response": response
            })
        
        return {
            "success": True,
            "message": f"You say: \"{text}\""
        }
    
    # =========================================================================
    # STATE
    # =========================================================================
    
    def get_state(self) -> Dict[str, Any]:
        """Get current world state for console display."""
        # Get avatar info
        avatar_room = None
        avatar_room_name = None
        if self.avatar_id and self.avatar_id in self.entities:
            avatar = self.entities[self.avatar_id]
            avatar_room = avatar.room
            if avatar_room in self.rooms:
                avatar_room_name = self.rooms[avatar_room].name
        
        return {
            "type": "state",
            "world": self.loaded_origin or "unloaded",
            "mode": self.mode,
            "tick": self.tick,
            "rooms": len(self.rooms),
            "entities": {
                "total": len(self.entities),
                "fairies": sum(1 for e in self.entities.values() if e.entity_type == "fairy"),
                "goblins": sum(1 for e in self.entities.values() if e.entity_type == "goblin"),
            },
            "avatar": {
                "active": self.avatar_active,
                "id": self.avatar_id,
                "room": avatar_room,
                "room_name": avatar_room_name,
            },
            "entity_list": [e.to_dict() for e in self.entities.values()],
        }
    
    def handle_command(self, command: str, args: Dict[str, Any] = None) -> Dict[str, Any]:
        """Handle a command from the console.
        
        Returns response dict.
        """
        args = args or {}
        
        if command == "begin" or command == "run" or command == "start":
            success = self.begin()
            return {
                "success": success,
                "message": "Simulation started" if success else "Already running"
            }
        
        elif command == "pause" or command == "stop":
            success = self.pause()
            return {
                "success": success,
                "message": "Simulation paused" if success else "Not running"
            }
        
        elif command == "step" or command == "tick":
            self.step()
            return {
                "success": True,
                "message": f"Advanced to tick {self.tick}"
            }
        
        elif command == "status":
            return {
                "success": True,
                "state": self.get_state()
            }
        
        elif command == "avatar":
            # Toggle or set avatar mode
            value = args.get("value", not self.avatar_active)
            if isinstance(value, str):
                value = value.lower() in ("true", "1", "on", "yes")
            self.avatar_active = bool(value)
            
            if self.avatar_active and self.avatar_id:
                avatar = self.entities.get(self.avatar_id)
                if avatar:
                    avatar.state = "active"
                    self._emit_event("avatar_activated", {
                        "room": avatar.room,
                        "room_name": self.rooms[avatar.room].name if avatar.room in self.rooms else "unknown"
                    })
            
            print(f"[engine] Avatar mode: {'ON' if self.avatar_active else 'OFF'}")
            self._broadcast_state()
            return {
                "success": True,
                "message": f"Avatar mode {'activated' if self.avatar_active else 'deactivated'}",
                "avatar_active": self.avatar_active
            }
        
        elif command == "look":
            # Look at current room
            return self._avatar_look()
        
        elif command in ("n", "north", "s", "south", "e", "east", "w", "west",
                         "move", "go"):
            # Movement command
            direction = args.get("direction", command)
            return self._avatar_move(direction)
        
        elif command == "say":
            # Speak in current room
            text = args.get("text", "")
            return self._avatar_say(text)
        
        elif command == "load_plate_set":
            origin = args.get("origin", "unknown")
            self.load_plate_set(origin, args.get("plates"))
            return {
                "success": True,
                "message": f"Loaded plate set: {origin}"
            }
        
        else:
            return {
                "success": False,
                "message": f"Unknown command: {command}"
            }


# Global simulation instance
_simulation: Optional[SimulationWorld] = None


def get_simulation() -> SimulationWorld:
    """Get or create the global simulation instance."""
    global _simulation
    if _simulation is None:
        _simulation = SimulationWorld()
    return _simulation

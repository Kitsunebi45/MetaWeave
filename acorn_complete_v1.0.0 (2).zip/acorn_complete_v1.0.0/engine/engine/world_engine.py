"""engine.world_engine

Phase 5: WorldEngine (multi-entity, deterministic, synchronous).
Phase 7.1: Edge-triggered rules with ephemeral state snapshots.

This engine layers on top of Phase 3 execution boundary and Phase 5 world spec.
It MUST:
- Never raise exceptions for handled errors (return ExecutionResult(error=...))
- Never persist
- Never use randomness or wall-clock time
- Be fully replayable: (world_state, command) -> (new_world_state, outputs, events)
"""

from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import uuid

from console.schema import ExecutionContext, ExecutionResult, Packet

from .base import BaseEngine, UnknownPacketType
from .entity import Entity, EntityValidationError, build_default_state, validate_entity
from .world_state import EntityConfig, WorldState


Event = Dict[str, Any]


class WorldEngine(BaseEngine):
    """Deterministic multi-entity engine (Phase 5.0)."""

    def __init__(self, *, baseline_entities: Optional[Dict[str, EntityConfig]] = None):
        self._boot_id = str(uuid.uuid4())
        # Baseline is immutable by convention; do not mutate after init.
        if baseline_entities is None:
            baseline_entities = {
                "counter_1": EntityConfig(entity_type="counter"),
                "flag_1": EntityConfig(entity_type="flag"),
                "container_1": EntityConfig(entity_type="container"),
            }

        self._baseline_entities = dict(baseline_entities)
        self._world = WorldState(
            schema_version="5.0",
            boot_id=self._boot_id,
            baseline_entities=self._baseline_entities,
            entities={},
            rules_version="5.0",
        )
        self._world.reset_to_baseline()
        # Validate all baseline entities
        for e in self._world.entities.values():
            validate_entity(e)

        self._registry = self._build_command_registry()

    @property
    def world(self) -> WorldState:
        return self._world

    def execute(self, packet: Packet, context: ExecutionContext) -> ExecutionResult:
        if packet.packet_type != "command":
            raise UnknownPacketType(
                f"WorldEngine only handles 'command' packets, got '{packet.packet_type}'"
            )

        if "command" not in packet.payload:
            return self._error(
                packet.metadata.packet_id,
                "INVALID_COMMAND_PACKET",
                "Missing 'command' field in payload",
            )

        command: str = packet.payload.get("command")
        args: Dict[str, Any] = packet.payload.get("args", {})
        target = packet.payload.get("target", None)

        if command not in self._registry:
            return self._error(
                packet.metadata.packet_id,
                "UNKNOWN_COMMAND",
                f"Unknown command '{command}'. Use 'help' to list available commands.",
                extra={"command": command},
            )

        handler_info = self._registry[command]
        scope = handler_info["scope"]  # "world" | "entity" | "typed"
        allowed_types = handler_info.get("entity_types")
        handler = handler_info["handler"]
        
        # Phase 7.1: Capture snapshot of world state BEFORE command execution
        # This enables edge-triggered rules (false→true detection)
        prev_world_state = self._capture_snapshot()

        # Scope validation
        if scope == "world":
            if target is not None:
                return self._error(
                    packet.metadata.packet_id,
                    "INVALID_COMMAND_FOR_ENTITY",
                    f"Command '{command}' is world-scoped and requires target=null.",
                    extra={"command": command, "target": target},
                )
            try:
                result_payload, events, changed_entity = handler(args, context)
            except ValueError as e:
                return self._error(packet.metadata.packet_id, "INVALID_ARGS", str(e), extra={"command": command})

        else:
            # Entity-scoped
            if target is None:
                return self._error(
                    packet.metadata.packet_id,
                    "INVALID_COMMAND_FOR_ENTITY",
                    f"Command '{command}' requires a non-null target.",
                    extra={"command": command},
                )

            if target not in self._world.entities:
                return self._error(
                    packet.metadata.packet_id,
                    "UNKNOWN_ENTITY",
                    f"Unknown entity '{target}'.",
                    extra={"target": target},
                )

            entity = self._world.entities[target]

            if allowed_types is not None and entity.entity_type not in allowed_types:
                return self._error(
                    packet.metadata.packet_id,
                    "INVALID_COMMAND_FOR_ENTITY",
                    f"Command '{command}' not valid for entity type '{entity.entity_type}'.",
                    extra={"command": command, "entity_type": entity.entity_type, "target": target},
                )

            try:
                result_payload, events, changed_entity = handler(target, args, context)
            except EntityValidationError as e:
                return self._error(packet.metadata.packet_id, e.code, str(e), extra={"target": target})
            except ValueError as e:
                return self._error(packet.metadata.packet_id, "INVALID_ARGS", str(e), extra={"command": command, "target": target})

        # World rules (emit events only)
        # Phase 7.1: Pass previous state for edge detection
        if changed_entity is not None:
            events.extend(self._check_world_rules(changed_entity, prev_world_state))

        # Schema validation for all entities after execution
        try:
            for e in self._world.entities.values():
                validate_entity(e)
        except EntityValidationError as e:
            # Corruption or invalid state - request reset
            return self._error(
                packet.metadata.packet_id,
                e.code,
                str(e),
                extra={"action": "WORLD_RESET_REQUIRED"},
            )

        return ExecutionResult(
            status="success",
            packet_id=packet.metadata.packet_id,
            output={"result": result_payload, "events": events},
            error=None,
        )

    # ---------------- Registry / Handlers ----------------

    def _build_command_registry(self) -> Dict[str, Dict[str, Any]]:
        return {
            # World-scoped
            "help": {"scope": "world", "handler": self._cmd_help},
            "world.get": {"scope": "world", "handler": self._cmd_world_get},
            "world.reset": {"scope": "world", "handler": self._cmd_world_reset},
            "echo": {"scope": "world", "handler": self._cmd_echo},

            # Entity-scoped generic
            "entity.get": {"scope": "entity", "handler": self._cmd_entity_get},
            "entity.reset": {"scope": "entity", "handler": self._cmd_entity_reset},

            # Counter
            "counter.inc": {"scope": "entity", "entity_types": {"counter"}, "handler": self._cmd_counter_inc},
            "counter.dec": {"scope": "entity", "entity_types": {"counter"}, "handler": self._cmd_counter_dec},
            "counter.set": {"scope": "entity", "entity_types": {"counter"}, "handler": self._cmd_counter_set},

            # Flag
            "flag.enable": {"scope": "entity", "entity_types": {"flag"}, "handler": self._cmd_flag_enable},
            "flag.disable": {"scope": "entity", "entity_types": {"flag"}, "handler": self._cmd_flag_disable},
            "flag.toggle": {"scope": "entity", "entity_types": {"flag"}, "handler": self._cmd_flag_toggle},

            # Container
            "container.add": {"scope": "entity", "entity_types": {"container"}, "handler": self._cmd_container_add},
            "container.remove": {"scope": "entity", "entity_types": {"container"}, "handler": self._cmd_container_remove},
            "container.clear": {"scope": "entity", "entity_types": {"container"}, "handler": self._cmd_container_clear},
        }

    # ---- World commands ----

    def _cmd_help(self, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        # No args for Phase 5.0
        if args not in (None, {}):
            # tolerate empty
            pass
        lines = [
            "Available commands:",
            "  World: help, world.get, world.reset, echo",
            "  Entity: entity.get, entity.reset",
            "  Counter: counter.inc, counter.dec, counter.set",
            "  Flag: flag.enable, flag.disable, flag.toggle",
            "  Container: container.add, container.remove, container.clear",
        ]
        return ("\n".join(lines), [], None)

    def _cmd_world_get(self, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        return (self._world.to_dict(), [], None)

    def _cmd_world_reset(self, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        self._world.reset_to_baseline()
        return (f"World reset to baseline ({len(self._world.entities)} entities restored)", [], None)

    def _cmd_echo(self, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        msg = args.get("message") if isinstance(args, dict) else None
        if msg is None:
            # Accept legacy arg name
            msg = args.get("text") if isinstance(args, dict) else None
        if msg is None:
            raise ValueError("echo requires 'message: str'")
        if not isinstance(msg, str):
            raise ValueError("echo.message must be str")
        return (msg, [], None)

    # ---- Entity commands ----

    def _cmd_entity_get(self, target: str, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        e = self._world.entities[target]
        return (
            {
                "entity_id": e.entity_id,
                "entity_type": e.entity_type,
                "state": e.state.copy() if isinstance(e.state, dict) else e.state,
            },
            [],
            None,
        )

    def _cmd_entity_reset(self, target: str, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        e = self._world.entities[target]
        e.state = build_default_state(e.entity_type)
        validate_entity(e)
        return (f"Entity '{target}' reset", [], target)

    # ---- Counter ----

    def _cmd_counter_inc(self, target: str, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        e = self._world.entities[target]
        e.state["value"] += 1
        validate_entity(e)
        return (f"Counter incremented: value = {e.state['value']}", [], target)

    def _cmd_counter_dec(self, target: str, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        e = self._world.entities[target]
        e.state["value"] -= 1
        validate_entity(e)
        return (f"Counter decremented: value = {e.state['value']}", [], target)

    def _cmd_counter_set(self, target: str, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        if "value" not in args:
            raise ValueError("counter.set requires 'value: int'")
        value = args["value"]
        if not isinstance(value, int):
            raise ValueError("counter.set value must be int")
        e = self._world.entities[target]
        e.state["value"] = value
        validate_entity(e)
        return (f"Counter set: value = {e.state['value']}", [], target)

    # ---- Flag ----

    def _cmd_flag_enable(self, target: str, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        e = self._world.entities[target]
        e.state["enabled"] = True
        validate_entity(e)
        return (f"Flag enabled: {target}", [], target)

    def _cmd_flag_disable(self, target: str, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        e = self._world.entities[target]
        e.state["enabled"] = False
        validate_entity(e)
        return (f"Flag disabled: {target}", [], target)

    def _cmd_flag_toggle(self, target: str, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        e = self._world.entities[target]
        e.state["enabled"] = not bool(e.state["enabled"])
        validate_entity(e)
        return (f"Flag toggled: enabled = {e.state['enabled']}", [], target)

    # ---- Container ----

    def _cmd_container_add(self, target: str, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        if "item" not in args:
            raise ValueError("container.add requires 'item: str'")
        item = args["item"]
        if not isinstance(item, str):
            raise ValueError("container.add item must be str")
        e = self._world.entities[target]
        items = e.state["items"]
        if len(items) >= 100:
            raise EntityValidationError(
                "RULE_VIOLATION",
                "Container full (100/100)",
                entity_id=target,
            )
        items.append(item)
        validate_entity(e)
        return (f"Item added: {item}", [], target)

    def _cmd_container_remove(self, target: str, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        if "item" not in args:
            raise ValueError("container.remove requires 'item: str'")
        item = args["item"]
        if not isinstance(item, str):
            raise ValueError("container.remove item must be str")
        e = self._world.entities[target]
        items = e.state["items"]
        if item in items:
            items.remove(item)
        validate_entity(e)
        return (f"Item removed: {item}", [], target)

    def _cmd_container_clear(self, target: str, args: Dict[str, Any], context: ExecutionContext) -> Tuple[Any, List[Event], Optional[str]]:
        e = self._world.entities[target]
        e.state["items"] = []
        validate_entity(e)
        return (f"Container cleared: {target}", [], target)

    # ---------------- Rules ----------------

    def _capture_snapshot(self) -> 'WorldState':
        """Capture ephemeral snapshot of current world state.
        
        Phase 7.1: Creates a deep copy of the current world state for
        edge detection. Snapshot lifetime is one command only.
        
        Returns:
            Deep copy of current WorldState
        """
        return copy.deepcopy(self._world)

    def _check_world_rules(self, changed_entity: str, prev_world_state: Optional['WorldState'] = None) -> List[Event]:
        """Hardcoded rule evaluation - emits events only (no mutation).
        
        Phase 7.1: Accepts optional previous world state for edge detection.
        
        Args:
            changed_entity: Entity ID that was modified
            prev_world_state: Previous state snapshot (for edge rules)
            
        Returns:
            List of events emitted by rules
        """
        events: List[Event] = []
        entity = self._world.entities.get(changed_entity)
        if not entity:
            return events

        if entity.entity_type == "counter":
            value = entity.state.get("value")
            if isinstance(value, int) and value > 3:
                events.append(
                    {
                        "type": "COUNTER_THRESHOLD_EXCEEDED",
                        "entity": changed_entity,
                        "value": value,
                    }
                )
        return events

    # ---------------- Helpers ----------------

    def _error(self, packet_id: str, code: str, message: str, *, extra: Optional[Dict[str, Any]] = None) -> ExecutionResult:
        err: Dict[str, Any] = {"code": code, "message": message}
        if extra:
            err.update(extra)
        return ExecutionResult(status="error", packet_id=packet_id, output=None, error=err)

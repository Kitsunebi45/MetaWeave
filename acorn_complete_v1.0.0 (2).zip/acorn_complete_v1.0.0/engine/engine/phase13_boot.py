"""Phase 13.1 Boot Integration — Production Implementation.

╔══════════════════════════════════════════════════════════════════════════════╗
║  ⚠️  LOCKED MODULE — DO NOT MODIFY WITHOUT ARCHITECT APPROVAL                ║
║                                                                              ║
║  This module implements the Phase 13 boot path for Spore Engine v12.         ║
║  ADDITIVE ONLY — existing boot paths remain unchanged.                       ║
║                                                                              ║
║  Status: PRODUCTION                                                          ║
║  Locked: 2026-01-23                                                          ║
║  Spec: Phase13_Final_Locked_Complete.zip                                     ║
╚══════════════════════════════════════════════════════════════════════════════╝

Provides plate-based boot path for Spore Engine v12.
ADDITIVE ONLY — does not modify existing boot paths.

Entry point:
    boot_engine_with_plate_stack(plate_paths) -> (EngineIdentity, ResolvedConfig)

Behavior:
1. Load plates (schema validation)
2. Validate plates (engine_compat, checksums)
3. Resolve stack (semantic validation)
4. Pass ResolvedConfig into normal engine initialization

On any error:
- Emit structured JSON error to stderr
- Exit non-zero
- Do NOT partially boot
"""

import sys
import json
from pathlib import Path
from typing import List, Optional, Set, Tuple

# Engine version constant
ENGINE_VERSION = "12.0.0"

# Import v12 identity boot (unchanged)
from identity.engine_identity import EngineIdentity
from .boot import boot_engine

# Import v12 rule registry (read-only)
from .rules import RULE_REGISTRY

# Import Phase 13 plates module
from .plates import (
    PlateLoader,
    PlateResolver,
    ResolvedConfig,
    PlateValidationError,
    SchemaError,
    SemanticError,
    CompatError,
    ConflictError,
    IntegrityError
)


def get_rule_registry_ids() -> Set[str]:
    """Get set of valid rule IDs from v12 registry.
    
    Read-only access to engine registry.
    This is the authoritative source for rule ID validation.
    """
    return set(RULE_REGISTRY.keys())


def boot_engine_with_plate_stack(
    plate_paths: List[Path],
    identity_dir: Optional[Path] = None
) -> Tuple[EngineIdentity, ResolvedConfig]:
    """Boot engine with plate-based configuration.
    
    This is the Phase 13.1 boot entry point.
    
    Sequence:
    1. Verify identity (existing Phase 1 logic, unchanged)
    2. Load and validate plates
    3. Resolve plate stack
    4. Return identity + resolved config for engine initialization
    
    Args:
        plate_paths: Ordered list of plate file paths
        identity_dir: Directory for identity storage (uses default if None)
        
    Returns:
        Tuple of (EngineIdentity, ResolvedConfig)
        
    Raises:
        SystemExit: On any validation failure
        - Structured JSON error emitted to stderr
        - Exit code 1
        - Engine does NOT partially boot
    """
    # PHASE 1: Identity verification (unchanged - delegates to existing boot)
    identity = boot_engine(identity_dir)
    
    # PHASE 13: Plate loading and resolution
    try:
        # Create loader with real engine version
        loader = PlateLoader(engine_version=ENGINE_VERSION)
        
        # Create resolver with real rule registry
        resolver = PlateResolver(rule_registry=get_rule_registry_ids())
        
        # Load all plates (schema validation)
        plates = loader.load_all(plate_paths)
        
        # Resolve stack (semantic validation)
        config = resolver.resolve(plates)
        
        return identity, config
        
    except PlateValidationError as e:
        # Structured error output to stderr
        print(e.error.to_json(), file=sys.stderr)
        print("PLATE VALIDATION FAILED. Engine boot aborted.", file=sys.stderr)
        sys.exit(1)
        
    except FileNotFoundError as e:
        # File not found error
        error_json = json.dumps({
            "error_class": "SCHEMA_ERROR",
            "plate_id": None,
            "field_path": None,
            "message": str(e)
        }, separators=(',', ':'))
        print(error_json, file=sys.stderr)
        print("PLATE LOADING FAILED. Engine boot aborted.", file=sys.stderr)
        sys.exit(1)
        
    except Exception as e:
        # Unexpected error
        error_json = json.dumps({
            "error_class": "SCHEMA_ERROR",
            "plate_id": None,
            "field_path": None,
            "message": f"Unexpected error: {type(e).__name__}: {e}"
        }, separators=(',', ':'))
        print(error_json, file=sys.stderr)
        print("PLATE LOADING FAILED. Engine boot aborted.", file=sys.stderr)
        sys.exit(1)


def boot_engine_with_plate_dicts(
    plates_data: List[dict],
    identity_dir: Optional[Path] = None
) -> Tuple[EngineIdentity, ResolvedConfig]:
    """Boot engine with plate dictionaries (for testing).
    
    Same as boot_engine_with_plate_stack but accepts dict data instead of files.
    Useful for unit tests that don't need filesystem.
    
    Args:
        plates_data: Ordered list of plate dictionaries
        identity_dir: Directory for identity storage
        
    Returns:
        Tuple of (EngineIdentity, ResolvedConfig)
    """
    # PHASE 1: Identity
    identity = boot_engine(identity_dir)
    
    # PHASE 13: Plate loading and resolution
    try:
        loader = PlateLoader(engine_version=ENGINE_VERSION)
        resolver = PlateResolver(rule_registry=get_rule_registry_ids())
        
        plates = loader.load_all_from_dicts(plates_data)
        config = resolver.resolve(plates)
        
        return identity, config
        
    except PlateValidationError as e:
        print(e.error.to_json(), file=sys.stderr)
        print("PLATE VALIDATION FAILED. Engine boot aborted.", file=sys.stderr)
        sys.exit(1)


def validate_plate_stack(plates_data: List[dict]) -> ResolvedConfig:
    """Validate and resolve a plate stack without identity boot.
    
    Useful for testing and preflight validation.
    Does NOT boot the engine.
    
    Args:
        plates_data: Ordered list of plate dictionaries
        
    Returns:
        ResolvedConfig if valid
        
    Raises:
        SchemaError, SemanticError, CompatError, ConflictError, IntegrityError
    """
    loader = PlateLoader(engine_version=ENGINE_VERSION)
    resolver = PlateResolver(rule_registry=get_rule_registry_ids())
    
    plates = loader.load_all_from_dicts(plates_data)
    return resolver.resolve(plates)


def generate_rules_manifest(output_path: Optional[Path] = None) -> dict:
    """Generate machine-readable manifest of valid rule IDs.
    
    Source of truth: v12 rule registry (RULE_REGISTRY)
    
    Args:
        output_path: If provided, write manifest to this file
        
    Returns:
        Manifest dictionary
    """
    from datetime import datetime, timezone
    
    manifest = {
        "manifest_version": "1.0.0",
        "engine_version": ENGINE_VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "rules": [
            {
                "rule_id": rule_id,
                "description": rule.description,
                "trigger": rule.trigger.value
            }
            for rule_id, rule in sorted(RULE_REGISTRY.items())
        ]
    }
    
    if output_path:
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, indent=2)
    
    return manifest


# =============================================================================
# MODULE CONSTANTS
# =============================================================================

# Expose engine version for external use
__engine_version__ = ENGINE_VERSION

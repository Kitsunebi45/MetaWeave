"""engine.scenario

Phase 6: Scenario and Condition structures for deterministic progression.

Conservative / deterministic constraints:
- No persistence
- No randomness
- No wall-clock time
- Scenarios are hardcoded in engine
- Conditions are declarative and type-safe
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Literal

# Type alias for operator literals
Operator = Literal["==", "!=", "<", ">", "<=", ">="]


@dataclass(frozen=True)
class Condition:
    """Declarative condition for scenario triggers and exits.
    
    Conditions are immutable and evaluated deterministically.
    """
    
    entity_id: str
    field: str
    operator: Operator
    value: Any
    
    def evaluate(self, world_state: Any) -> bool:
        """Evaluate condition against current world state.
        
        Args:
            world_state: WorldState object to evaluate against
            
        Returns:
            True if condition is satisfied, False otherwise
            
        Raises:
            KeyError: If entity or field doesn't exist
            TypeError: If comparison types don't match
        """
        # Get entity from world
        if self.entity_id not in world_state.entities:
            return False
        
        entity = world_state.entities[self.entity_id]
        
        # Get field value
        if self.field not in entity.state:
            return False
        
        actual_value = entity.state[self.field]
        
        # Type checking
        if type(actual_value) != type(self.value):
            return False
        
        # Evaluate operator
        if self.operator == "==":
            return actual_value == self.value
        elif self.operator == "!=":
            return actual_value != self.value
        elif self.operator == "<":
            return actual_value < self.value
        elif self.operator == ">":
            return actual_value > self.value
        elif self.operator == "<=":
            return actual_value <= self.value
        elif self.operator == ">=":
            return actual_value >= self.value
        else:
            # Should never reach here due to Literal type
            return False


@dataclass
class Scenario:
    """Phase 6 scenario definition (hardcoded in engine).
    
    Scenarios orchestrate multi-step progression through:
    - Initial world constraints (must be met to activate)
    - Active rule selection (enables/disables Phase 5 rules)
    - Exit conditions (must be met to advance)
    - Next scenario options (explicit transitions)
    
    All behavior is deterministic and human-commanded.
    """
    
    scenario_id: str
    description: str
    initial_world_constraints: List[Condition]
    active_rule_ids: List[str]  # References Phase 5 hardcoded rules
    exit_conditions: List[Condition]
    next_scenarios: List[str]
    
    def check_initial_constraints(self, world_state: Any) -> tuple[bool, List[str]]:
        """Check if world state satisfies initial constraints.
        
        Args:
            world_state: WorldState to validate
            
        Returns:
            Tuple of (all_satisfied, list_of_violations)
        """
        violations = []
        
        for condition in self.initial_world_constraints:
            try:
                if not condition.evaluate(world_state):
                    violations.append(
                        f"{condition.entity_id}.{condition.field} {condition.operator} {condition.value}"
                    )
            except (KeyError, TypeError) as e:
                violations.append(f"Invalid condition: {e}")
        
        return (len(violations) == 0, violations)
    
    def check_exit_conditions(self, world_state: Any) -> tuple[bool, List[str]]:
        """Check if world state satisfies ALL exit conditions.
        
        Args:
            world_state: WorldState to validate
            
        Returns:
            Tuple of (all_satisfied, list_of_unsatisfied)
        """
        unsatisfied = []
        
        for condition in self.exit_conditions:
            try:
                if not condition.evaluate(world_state):
                    # Get current value for reporting
                    entity = world_state.entities.get(condition.entity_id)
                    current = entity.state.get(condition.field) if entity else "N/A"
                    unsatisfied.append(
                        f"{condition.entity_id}.{condition.field} {condition.operator} {condition.value} [CURRENT: {current}]"
                    )
            except (KeyError, TypeError) as e:
                unsatisfied.append(f"Invalid condition: {e}")
        
        return (len(unsatisfied) == 0, unsatisfied)


class ScenarioValidationError(ValueError):
    """Raised when scenario validation fails."""
    
    def __init__(self, code: str, message: str, **extra):
        super().__init__(message)
        self.code = code
        self.extra = extra

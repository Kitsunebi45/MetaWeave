# 🌸 Acorn Engine Complete Bundle v1.0.0 🌸

## YOU ARE IN THE FAIRY GARDEN

This is a working tech demo. You can walk through the garden, talk to fairies, and watch them live.

---

## 🚀 QUICK START (5 minutes)

### 1. Extract
```bash
unzip engine.zip -d engine
unzip console.zip -d console
unzip demo.zip -d demo
```

### 2. Start Engine (Terminal 1)
```bash
cd engine
python socket_server.py
```

### 3. Start Console (Terminal 2)
```bash
cd console
python run_console.py
```

### 4. In Console UI
```
Click [Connect]
Click [📁 Load Plate Set] → select demo/plates/
Type: init
Type: begin
Type: avatar true
Type: look
Type: n
Type: say Hello fairies!
```

---

## 🎭 Avatar Commands

| Command | What It Does |
|---------|--------------|
| `avatar true` | Step into the world |
| `avatar false` | Return to observer mode |
| `look` | See your surroundings |
| `n` / `s` / `e` / `w` | Move between rooms |
| `say <text>` | Speak (fairies may respond!) |

## 🧭 World Commands

| Command | What It Does |
|---------|--------------|
| `init` | Initialize the world |
| `begin` | Start the simulation |
| `pause` | Pause time |
| `step` | Advance one tick |

---

## ✅ What You'll See

**Engine window:**
```
[engine] Avatar mode: ON
[engine] Avatar moved: Entrance → Garden Path
[engine] Avatar says: "Hello fairies!"
[engine] Tick 7
```

**Console output:**
```
📍 Entrance

The room is quiet.

Exits: Garden Path, Mushroom Grove
```

**Diagnostics panel:**
```
mode: active
tick: 7
avatar_active: True
avatar_room: Garden Path
fairies: 6
```

---

## 🗺️ The Fairy Garden Map

```
entrance ←→ garden_path ←→ flower_meadow
    ↕           ↕              ↕
mushroom_grove ←→ central_glade ←→ crystal_pool
    ↕           ↕              ↕
hedge_maze ←→ fairy_court ←→ ancient_tree
```

9 rooms. 6 fairies. Connected paths. Explore freely.

---

## What's Happening

- **Simulation ticks** every second
- **Fairies move** between rooms, change activities
- **You can explore** as an avatar
- **Fairies respond** when you speak

---

## Files

| Package | Contents |
|---------|----------|
| `engine.zip` | Acorn Engine v12.19.0 with simulation |
| `console.zip` | Console v0.1.0 with avatar display |
| `demo.zip` | Fairy Garden plates + avatar plate |

---

*Type `avatar true` and step into the garden.* 🌸
